cd [file dirname [file normalize [info script]]]
set status [open build.exit w]; puts $status 1; close $status
if {[catch {
prj_project open bk0010.ldf
prj_run Synthesis -impl impl1
prj_run Translate -impl impl1
prj_run Map -impl impl1
prj_run PAR -impl impl1
prj_run PAR -impl impl1 -task PARTrace
prj_project close
exec python3 tools/diamond_report.py phase-preferences .
exec trce -v 10 -c -u 0 -sethld -sp 4 -sphld m -o phase.twr impl1/bk0010_impl1.ncd phase.prf > phase.log 2>@1
set status [open build.exit w]; puts $status 0; close $status
puts [exec python3 tools/diamond_report.py check .]
} message]} {
set status [open build.exit w]; puts $status 1; close $status
puts stderr $message; exit 1
}
exit 0
