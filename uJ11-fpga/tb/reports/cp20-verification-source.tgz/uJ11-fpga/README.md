# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес 16 bits.

**CP20 выполнен:** добавлены HALT в restart-профиле нашего DCJ11 emulator и
RESET с отдельным выходом для периферии. Полный console ODT настоящего J-11
не реализован. Один kernel register set, CM=PM=RS=0, NZVC/IPL/T.
Работают word/byte integer ISA, все восемь addressing modes, branches,
JMP/JSR/RTS/SOB, SWAB/SXT/MARK, software/reserved/memory traps, RTI/RTT,
IRQ/WAIT/SPL, CC/NOP/MFPT, MFPS/MTPS. EIS и запуск ОС пока не заявлены.
Память — **SPI FRAM**, с instruction-stream prefetch и KW11/KL11 IRQ adapter.

| Измеренный scope | LUT4 | FF | EBR | Constraint | TRACE Fmax |
|---|---:|---:|---:|---|---:|
| Core + probe | **836** | 299 | 4 | **35 MHz PASS** | **36.647 MHz** |
| Core + FRAM/prefetch + IRQ adapter + probe | **1085** | 416 | 4 | **29.56 MHz PASS** | **30.593 MHz** |

Реальные Diamond MAP/PAR/TRACE для HC1200. Полные UART/timer/panel/SD/RK
и внешние pin delays в fit не входят; 50 MHz остаётся целью.
До желательных 1100 LUT осталось 15; до физических 1280 — 195.
[Отчёты synthesis](docs/synthesis.md).

Микрокод: **521/1024 ×36 bits**, encoding **v11**. Все прежние 507 words/labels
сохранены. RESET использует свободный bit0 JUMP; RF16×16/Q/ALU сохранены.
FF+2 к CP19: один регистр выхода RESET
для asynchronous reset входов периферии и один observer этого выхода.

Проверены **176281 completed DCJ11 cases** на каждом RAM/FRAM×portable/vendor
ROM сочетании, **33788 fault frames**, 64 directed HALT fault cases и RESET с
настоящей peripheral RTL из lsi11-fpga. Новая группа 6144 cases без exclusions;
прежние exclusions сохранены явно. **794 benchmark runs** на ROM-модель;
все 786 прежних counts неизменны. RR с ideal FETCH — 2 CPI; прежние FRAM RR loops
сохранили 39.078125 CPI. RESET — 4 clocks с ideal FETCH, HALT restart — 12.
Это functional simulation; FPGA не программировалась.

```
make verify-cp20                  # portable + vendor, snapshots, evidence recorder
make test                        # full portable regression and lint
make benchmark benchmark-fram benchmark-ea benchmark-cp9 benchmark-byte benchmark-control benchmark-extra benchmark-trap benchmark-irq benchmark-illegal benchmark-trace benchmark-system-flags benchmark-psw-transfer benchmark-system-control
make all                         # ROM, listing, labels, occupancy, DP8KC lanes
make synthesis                   # CP20c, 35 MHz
make synthesis-fram              # CP20d, 29.56 MHz
```

Нужны Python 3, Icarus Verilog, Verilator и C compiler. Oracle собирается из
существующего `../core/` с `ENABLE_MMU=0`; проект находится внутри k1801vm1.
Diamond 3.14.0.75.2 настроен на `sash@192.168.1.108`, default path
`$HOME/.local/lscc/diamond/3.14`. `DIAMOND_HOME` и `LATTICE_SIM_DIR` можно
переопределить; локальные vendor tests используют `LATTICE_SIM_DIR=build/vendor`.
Команды synthesis запускаются на Linux-сервере с Diamond; тесты — локально.
Каждый synthesis gate требует свежего implementation directory.

Следующий gate — EIS; дальнейшие system operations требуют отдельных измерений.
J-11 banking и полный board top ещё предстоят. Неподдержанная ISA получает
vector010; это не её реализация. MMU в эти этапы не входит. FPGA не программировалась.

* [HALT/RESET: профиль, периферия, ошибки и измерения](docs/system-control.md)
* [MFPS/MTPS: microcode, FRAM, flags/IRQ и fault tests](docs/psw-transfer.md)
* [CC/NOP/MFPT: microcode, три fit-варианта и проверки](docs/system-flags.md)
* [Trace/RTT: архитектура, проверки и ограничения](docs/trace-rtt.md)
* [Текущий статус](docs/implementation-status.md), [benchmarks](docs/benchmarks.md)
* [Предыдущие эксперименты](docs/previous_experiments.md)
* [Архитектура](docs/architecture.md), [микроархитектура](docs/microarchitecture.md), [microcode format](docs/microcode-format.md)
* [FRAM и периферия lsi11-fpga](docs/fram-peripherals.md)
* [Memory faults](docs/memory-faults.md), [reserved traps](docs/reserved-traps.md), [IRQ/WAIT/SPL](docs/interrupts.md)
* [Software traps/RTI](docs/software-traps.md), [control flow](docs/control-flow.md), [byte ISA](docs/byte-instructions.md)
