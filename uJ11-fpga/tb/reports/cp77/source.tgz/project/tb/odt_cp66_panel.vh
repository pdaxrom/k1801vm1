// CP65 navigation remains above, including held 9 on the new unbounded T.
// Drive the physical matrix, never inject a command into ODT internals.
while(upper(O_KLAST)!=65535)@(negedge clk);repeat(10000)@(negedge clk);
keypress(16);while(upper(O_MENU)!=8)keypress(18);keypress(19);
eq(upper(O_PANEDI),5,"menu selects breakpoint address editor");
segment="";keypress(3);keypress(0);keypress(0);keypress(0);keypress(4);keypress(19);
contains("[PANEL] P 030004");contains("BP 030004");
eq(upper(O_BPTAB),16'o30004,"panel breakpoint definition");
eq(memory['o30004/2],16'o5200,"panel SET leaves opcode restored");
keypress(16);while(upper(O_MENU)!=10)keypress(18);segment="";keypress(19);
contains("[PANEL] P");contains("BP 030004");
keypress(16);while(upper(O_MENU)!=9)keypress(17);keypress(19);
eq(upper(O_PANEDI),6,"menu selects individual CLEAR editor");
segment="";keypress(3);keypress(0);keypress(0);keypress(0);keypress(4);keypress(19);
contains("[PANEL] Z 030004");eq(upper(O_BPTAB+4),0,"panel clears selected point");
command("P 30004");
keypress(16);while(upper(O_MENU)!=11)keypress(18);segment="";keypress(19);
contains("[PANEL] Z");eq(upper(O_BPTAB+4),0,"panel clears all points");
command("R 7 30004");command("R 0 0");
keypress(16);while(upper(O_MENU)!=12)keypress(18);keypress(19);
eq(upper(O_PANEDI),7,"menu selects RUN TO editor");
segment="";keypress(3);keypress(0);keypress(0);keypress(0);keypress(6);keypress(19);
contains("[PANEL] U 030006");contains("RUN TO ADDRESS");
eq(upper(O_REGS),1,"panel RUN TO executes original once");
eq(upper(O_REGS+14),16'o30006,"panel RUN TO stops before target");
eq(upper(O_BPTEMP+4),0,"panel temporary point removed");
keypress(16);keypress(18);eq(upper(O_MENU),0,"extended menu NEXT wraps");
keypress(17);eq(upper(O_MENU),12,"extended menu PREV wraps");
$display("PASS CP66: %0d checks %0d windows %0d clocks",checks,scroll_windows,cycles);$finish;
