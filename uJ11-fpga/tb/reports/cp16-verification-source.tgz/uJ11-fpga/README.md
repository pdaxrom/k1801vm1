# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес 16 bits.

**CP16 выполнен:** ошибки памяти и odd-word вызывают микрокодный vector004;
autoincrement восстанавливается, повторная ошибка внутри frame останавливает core.
Сохранены integer ISA, IRQ/WAIT/SPL, KW11/KL11 adapter, software/reserved traps и RTI.
Профиль: один kernel register set, CM=PM=RS=T=0; сохраняются NZVC и IPL.
Сохранены семь word и пять byte double-operand classes, 12 word и 12 byte
unary classes, все восемь addressing modes, все 15 branch classes, SPI FRAM
и instruction-stream prefetch. Базовый subset Stage 1 работает; полный J-11 ещё не реализован.

| Измеренный scope | LUT4 | FF | EBR | Constraint | TRACE Fmax |
|---|---:|---:|---:|---|---:|
| Core + probe | **809** | 296 | 4 | **35 MHz PASS** | **36.552 MHz** |
| Core + FRAM/prefetch + IRQ adapter + probe | **1042** | 413 | 4 | **29.56 MHz PASS** | **31.117 MHz** |

Реальные Diamond MAP/PAR/TRACE для HC1200. Измеренный FRAM scope включает
IRQ resolver BR4/BR6.
Полные UART/timer/panel/SD/RK и внешние pin delays сюда не входят.
Для текущего core подтверждены 35 MHz; начальная цель 50 MHz остаётся
открытой. [Synthesis](docs/synthesis.md).

Микрокод: **452/1024 × 36 bits**, encoding **v9**. Byte/word используют общие
routines, RF16×16 и один adder. MOVB в регистр знаково расширяет byte;
остальные byte writes сохраняют старшую половину регистра. Указатели и
адресная арифметика остаются word. Пересобирать microassembler, microcode и RTL вместе.

RR и 12 word/12 byte unary classes: **одна execution microinstruction**, с FETCH —
**2 CPI** при ideal RAM. Прежние word RR loops с FRAM сохранили **39.078125 CPI**
при nominal CPU/SPI 29.56/14.78 MHz. Это RTL simulation, не измерение на плате.

Проверены **124969 завершённых DCJ11 cases** на каждой RAM/FRAM × portable/vendor ROM,
включая registers/PSW/PC и точные bus traces. Дополнительно **32780 memory-fault
frames** сравнены на границе входа в handler; восемь I/O candidates исключены явно. Byte ALU — **2097152** checks;
RF merge/sign extension — **16384**. **726 benchmark runs** на ROM-модель,
все 726 прежних без изменения counts.
[Memory faults](docs/memory-faults.md) · [Reserved traps](docs/reserved-traps.md) · [IRQ/WAIT/SPL](docs/interrupts.md) · [Software traps / RTI](docs/software-traps.md) · [SWAB/SXT/MARK](docs/extra-instructions.md) · [Control flow](docs/control-flow.md) · [Byte ISA](docs/byte-instructions.md) · [Benchmarks](docs/benchmarks.md).

```
make verify-cp16                  # portable + vendor, snapshots, evidence recorder
make test                         # portable regression, RAM + SPI FRAM, lint
make benchmark benchmark-fram benchmark-ea benchmark-cp9 benchmark-byte benchmark-control benchmark-extra benchmark-trap benchmark-irq benchmark-illegal
make all                          # ROM, listing, labels, occupancy, DP8KC lanes
make vendor-test vendor-engine vendor-memory-engine vendor-core
make vendor-fram vendor-ea vendor-single vendor-branch vendor-byte vendor-single-byte
make vendor-control vendor-control-faults vendor-extra vendor-extra-faults vendor-trap vendor-trap-faults vendor-irq vendor-irq-faults vendor-irq-lsi11 vendor-illegal vendor-illegal-faults
make vendor-benchmark vendor-fram-benchmark vendor-ea-benchmark vendor-cp9-benchmark vendor-byte-benchmark vendor-control-benchmark vendor-extra-benchmark vendor-trap-benchmark vendor-irq-benchmark vendor-illegal-benchmark
make synthesis-fram               # CP16f, 29.56 MHz PASS
make synthesis                    # CP16e, 35 MHz PASS
```

Нужны Python 3, Icarus Verilog, Verilator и C compiler. Oracle собирается
из существующего `../core/` с `ENABLE_MMU=0`; проект расположен внутри
k1801vm1. Diamond 3.14.0.75.2 работает на `sash@192.168.1.108`, default path
`$HOME/.local/lscc/diamond/3.14`. `DIAMOND_HOME` и `LATTICE_SIM_DIR` можно
переопределить; локальные vendor tests используют `LATTICE_SIM_DIR=build/vendor`.
Каждый synthesis gate требует свежего implementation directory.

Следующие gates — trace/RTT и HALT/RESET/остальные PSW operations.
EIS, J-11 banking и полная периферия ещё предстоят. Неподдержанная ISA
получает vector010; HALT/RTT этим не считаются реализованными. MMU в эти этапы не входит.
FPGA в рамках CP16 не программировалась.

* [Предыдущие эксперименты](docs/previous_experiments.md)
* [Архитектура](docs/architecture.md) и [микроархитектура](docs/microarchitecture.md)
* [36-bit microcode format](docs/microcode-format.md)
* [FRAM и периферия lsi11-fpga](docs/fram-peripherals.md)
* [Текущий статус](docs/implementation-status.md)
