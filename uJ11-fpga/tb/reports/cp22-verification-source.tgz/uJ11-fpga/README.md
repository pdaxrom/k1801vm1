# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес 16 bits.

**CP22 завершён:** полная portable/vendor регрессия прошла. Добавлена ASHC через существующие
ALU/Q, исправлены порядок EA в ASH/ASHC и 32-bit N/Z в C-эталоне.
Работают word/byte integer ISA, addressing modes, branches, JMP/JSR/RTS/SOB,
SWAB/SXT/MARK, traps/RTI/RTT, IRQ/WAIT/SPL, CC/NOP/MFPT, MFPS/MTPS,
HALT restart и peripheral RESET. Один kernel register set, CM=PM=RS=0, NZVC/IPL/T.
Память — **MR45V100A SPI FRAM**, instruction-stream prefetch и KW11/KL11 IRQ adapter.
MUL/DIV/XOR, banking, native ODT и запуск ОС ещё не реализованы.

| Измеренный scope | LUT4 | FF | EBR | Constraint | TRACE Fmax |
|---|---:|---:|---:|---|---:|
| Core + probe, CP22c | **856** | 299 | 4 | **35 MHz PASS** | **37.258 MHz** |
| Core + FRAM/prefetch + IRQ adapter + probe, CP22d | **1098** | 416 | 4 | **29.56 MHz PASS** | **30.457 MHz** |

Реальные Diamond MAP/PAR/TRACE для HC1200. До желательных 1100 осталось 2 LUT;
до физических 1280 — 182. Полные UART/timer/panel/SD/RK и внешние pin delays
в fit не входят; 50 MHz остаётся целью. FPGA не программировалась.
[Отчёты synthesis](docs/synthesis.md).

Микрокод: **592/1024×36**, encoding **v11**. ASHC добавляет 41 word;
2 прежних ASH words исправляют порядок чтения. RF 16×16, ALU, Q, sequencer,
FRAM transport и число FF/EBR сохранены. Общий ASH/ASHC predecode.

ASHC с ideal FETCH: count0 —21 clocks; left n —24+5n, right n —25+5n.
Это serial microcode, без аппаратного счётчика или barrel shifter.
[Исправления, первичные источники и verification](docs/eis-ashc.md).
Исправлены найденные ошибки ASH/ASHC в прежнем C oracle. Ожидаемые результаты
не переписываются: 231105 instruction cases и 35836 fault frames проходят
на каждом сочетании RAM/FRAM × portable/vendor ROM. Ещё 256 ASHC alias cases
проверены независимой моделью и тем же RTL. Все 986 benchmarks на ROM-модель
прошли; из 890 прежних результатов 871 сохранён, а 19 ASH/prefetch workloads
изменили время и SPI activity после исправления порядка EA.
[Manifest и hashes](docs/verification-cp22.json), [benchmarks](docs/benchmarks-cp22.json).

```
make verify-cp22                  # full portable/vendor tests, benchmarks, evidence
make test                        # full portable regression and lint
make test-eis-ashc test-eis-ashc-fault
make test-ashc-alias              # independent reference + actual C fixtures
make test-reference-core          # existing C core regression
make benchmark-eis-ashc           # 24 workloads x4 memory modes
make all                         # ROM, listing, labels, occupancy, DP8KC lanes
make synthesis                   # CP22c, 35 MHz
make synthesis-fram              # CP22d, 29.56 MHz
```

Нужны Python 3, Icarus Verilog, Verilator и C compiler. Oracle собирается из
существующего `../core/` с `ENABLE_MMU=0`; проект находится внутри k1801vm1.
Diamond 3.14.0.75.2 настроен на `sash@192.168.1.108`, default path
`$HOME/.local/lscc/diamond/3.14`. `DIAMOND_HOME` и `LATTICE_SIM_DIR` можно
переопределить; локальные vendor tests используют `LATTICE_SIM_DIR=build/vendor`.
Команды synthesis запускаются на Linux-сервере с Diamond; тесты — локально.
Каждый synthesis gate требует свежего implementation directory.

Следующий gate — экономия LUT перед дальнейшим EIS; до желательных 1100 LUT
осталось 2. Каждое расширение требует отдельного HC1200 fit.
J-11 banking и полный board top ещё предстоят. Неподдержанная ISA получает
vector010; это не её реализация. MMU в эти этапы не входит. FPGA не программировалась.

* [ASHC и исправления ASH/эталона](docs/eis-ashc.md)
* [ASH: алгоритм, alias/flags/fault проверки и измерения](docs/eis-ash.md)
* [HALT/RESET: профиль, периферия, ошибки и измерения](docs/system-control.md)
* [MFPS/MTPS: microcode, FRAM, flags/IRQ и fault tests](docs/psw-transfer.md)
* [CC/NOP/MFPT: microcode, три fit-варианта и проверки](docs/system-flags.md)
* [Trace/RTT: архитектура, проверки и ограничения](docs/trace-rtt.md)
* [Текущий статус](docs/implementation-status.md), [benchmarks](docs/benchmarks.md)
* [Предыдущие эксперименты](docs/previous_experiments.md)
* [Архитектура](docs/architecture.md), [микроархитектура](docs/microarchitecture.md), [microcode format](docs/microcode-format.md)
* [FRAM и периферия lsi11-fpga](docs/fram-peripherals.md)
* [Memory faults](docs/memory-faults.md), [reserved traps](docs/reserved-traps.md), [IRQ/WAIT/SPL](docs/interrupts.md)
* [Software traps/RTI](docs/software-traps.md), [control flow](docs/control-flow.md), [byte ISA](docs/byte-instructions.md)
