# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес 16 bits.

**CP23 завершён:** общий target микросеквенсора уменьшил площадь FRAM scope
на **11 LUT**. ISA, микрокод **592/1024×36 v11**, RF 16×16, ALU/Q, decoder,
PSW и FRAM protocol сохранены. Формальная проверка и полная регрессия прошли.

| Измеренный scope | LUT4 | FF | EBR | Constraint | TRACE Fmax |
|---|---:|---:|---:|---|---:|
| Core + probe, CP23c | **850** | 299 | 4 | **35 MHz PASS** | **36.302 MHz** |
| Core + FRAM/prefetch + IRQ adapter + probe, CP23d | **1087** | 416 | 4 | **29.56 MHz PASS** | **30.193 MHz** |

Это реальные Diamond MAP/PAR/TRACE для HC1200. До желательных 1100 осталось
**13 LUT**, до физических 1280 — 193. Полные UART/timer/panel/SD/RK и внешние
pin delays в fit не входят; 50 MHz остаётся целью. FPGA не программировалась.
Из трёх вариантов выбран наименьший FRAM fit; [сравнение и причины](docs/area-sequencer.md).

Прошли **231105 instruction cases и 35836 fault frames** на каждом сочетании
RAM/FRAM × portable/vendor ROM, **986 benchmarks на ROM-модель**. Все 104
cycle/benchmark result files побайтно равны CP22. Микросеквенсор эквивалентен
CP22 по 74 formal equivalence points; намеренно изменённый fault vector
проверка отвергает. [Manifest](docs/verification-cp23.json),
[benchmarks](docs/benchmarks-cp23.json).

Работают word/byte integer ISA, все addressing modes, branches, JMP/JSR/RTS/SOB,
SWAB/SXT/MARK, traps/RTI/RTT, trace, IRQ/WAIT/SPL, CC/NOP/MFPT, MFPS/MTPS,
HALT restart, peripheral RESET, ASH/ASHC. Один kernel register set,
CM=PM=RS=0, NZVC/IPL/T. Память — **MR45V100A SPI FRAM**, instruction-stream
prefetch и KW11/KL11 IRQ adapter. Исправления ASH/ASHC из CP22 сохранены.
MUL/DIV/XOR, banking, native ODT и запуск ОС ещё не реализованы.

```
make all                         # ROM, listing, labels, occupancy, DP8KC lanes
make test                        # full portable regression and lint
make test-seq-equivalence YOSYS=/path/to/yosys
make verify-cp23 YOSYS=/path/to/yosys
make test-reference-core          # existing C core regression
make benchmark-eis-ashc           # 24 workloads x4 memory modes
make synthesis                   # CP23c, 35 MHz; Linux host with Diamond
make synthesis-fram              # CP23d, 29.56 MHz; same host
```

Нужны Python 3, Icarus Verilog, Verilator, C compiler и Yosys для equivalence.
Вместо native Yosys можно использовать YoWASP; [воспроизводимая установка](docs/area-sequencer.md).
Oracle собирается из существующего `../core/` с `ENABLE_MMU=0`; проект находится
внутри k1801vm1. Diamond 3.14.0.75.2 настроен на `sash@192.168.1.108`, default
path `$HOME/.local/lscc/diamond/3.14`. `DIAMOND_HOME` и `LATTICE_SIM_DIR` можно
переопределить; локальные vendor tests используют `LATTICE_SIM_DIR=build/vendor`.
Каждый synthesis gate требует свежего implementation directory.

Запас 13 LUT остаётся небольшим: следующая EIS инструкция требует отдельного
HC1200 fit. Предпочтительная площадь 900–1000 LUT ещё не достигнута. MMU в эти
этапы не входит и ресурсы под него не резервируются.

* [CP23: площадь микросеквенсора](docs/area-sequencer.md)
* [ASHC и исправления ASH/эталона](docs/eis-ashc.md)
* [ASH: алгоритм, alias/flags/fault проверки и измерения](docs/eis-ash.md)
* [HALT/RESET: профиль, периферия, ошибки и измерения](docs/system-control.md)
* [MFPS/MTPS: microcode, FRAM, flags/IRQ и fault tests](docs/psw-transfer.md)
* [CC/NOP/MFPT: microcode, три fit-варианта и проверки](docs/system-flags.md)
* [Trace/RTT: архитектура, проверки и ограничения](docs/trace-rtt.md)
* [Текущий статус](docs/implementation-status.md), [benchmarks](docs/benchmarks.md)
* [Предыдущие эксперименты](docs/previous_experiments.md)
* [Архитектура](docs/architecture.md), [микроархитектура](docs/microarchitecture.md), [microcode format](docs/microcode-format.md)
* [FRAM и периферия lsi11-fpga](docs/fram-peripherals.md)
* [Memory faults](docs/memory-faults.md), [reserved traps](docs/reserved-traps.md), [IRQ/WAIT/SPL](docs/interrupts.md)
* [Software traps/RTI](docs/software-traps.md), [control flow](docs/control-flow.md), [byte ISA](docs/byte-instructions.md)
