# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес 16 bits.

**CP24 завершён: XOR во всех восьми addressing modes.** Добавлены пять
микрокоманд и небольшой opcode dispatch. RF 16×16, ALU/Q, sequencer, PSW
и FRAM protocol сохранены. Микрокод **597/1024×36 v11**; все 592 прежних
слова и 242 метки CP23 остались на своих местах.

| Измеренный scope | LUT4 | FF | EBR | Constraint | TRACE Fmax |
|---|---:|---:|---:|---|---:|
| Core + probe, CP24a | **854** | 299 | 4 | **35 MHz PASS** | **36.059 MHz** |
| Core + FRAM/prefetch + IRQ adapter + probe, CP24b | **1089** | 416 | 4 | **29.56 MHz PASS** | **30.273 MHz** |

Реальные Diamond MAP/PAR/TRACE для HC1200: +4/+2 LUT к CP23, без новых FF/EBR.
До желательных 1100 осталось **11 LUT**, до физических 1280 — 191. Полные
UART/timer/panel/SD/RK и внешние pin delays в fit не входят. 50 MHz и
предпочтительные 900–1000 LUT ещё не достигнуты. FPGA не программировалась.

Прошли **242133 instruction cases и 41596 fault frames** на каждом сочетании
RAM/FRAM × portable/vendor ROM, **1018 benchmarks на ROM-модель**. Совпали
112 result files; все 104 прежних cycle/benchmark files побайтно равны CP23.
Независимая модель проверила 4698 XOR cases, восемь намеренных ошибок
отвергнуты тестами. [Manifest](docs/verification-cp24.json),
[benchmarks](docs/benchmarks-cp24.json).

Работают word/byte integer ISA, все addressing modes, branches, JMP/JSR/RTS/SOB,
SWAB/SXT/MARK, traps/RTI/RTT, trace, IRQ/WAIT/SPL, CC/NOP/MFPT, MFPS/MTPS,
HALT restart, peripheral RESET, ASH/ASHC/XOR. Один kernel register set,
CM=PM=RS=0, NZVC/IPL/T. Память — **MR45V100A SPI FRAM**, instruction-stream
prefetch и KW11/KL11 IRQ adapter. MUL/DIV, banking, native ODT и запуск ОС
ещё не реализованы. Ограничения совместимости описаны в документации.

```
make all                         # ROM, listing, labels, occupancy, DP8KC lanes
make test                        # full portable regression and lint
make test-xor-oracle test-xor-negative
make verify-cp24                 # full portable/vendor regression and archive
make test-reference-core         # existing C core regression
make benchmark-eis-xor           # 8 destination modes x4 memory modes
make synthesis                   # CP24a, 35 MHz; Linux host with Diamond
make synthesis-fram              # CP24b, 29.56 MHz; same host
```

Нужны Python 3, Icarus Verilog, Verilator, C compiler и Lattice simulation
models для vendor tests. Yosys нужен только для отдельной прежней проверки
микросеквенсора; [CP23 proof и установка](docs/area-sequencer.md).
Oracle собирается из существующего `../core/` с `ENABLE_MMU=0`; проект находится
внутри k1801vm1. Diamond 3.14.0.75.2 настроен на `sash@192.168.1.108`, default
path `$HOME/.local/lscc/diamond/3.14`. `DIAMOND_HOME` и `LATTICE_SIM_DIR` можно
переопределить; локальные vendor tests используют `LATTICE_SIM_DIR=build/vendor`.
Каждый synthesis gate требует свежего implementation directory.

Следующие MUL/DIV требуют отдельных HC1200 checkpoints с проверкой площади.
MMU в эти этапы не входит; ресурсы под него не резервируются.

* [CP24: XOR, проверки и измерения](docs/eis-xor.md)
* [CP23: площадь микросеквенсора](docs/area-sequencer.md)
* [ASHC и исправления ASH/эталона](docs/eis-ashc.md)
* [ASH: алгоритм, alias/flags/fault проверки и измерения](docs/eis-ash.md)
* [HALT/RESET: профиль, периферия, ошибки и измерения](docs/system-control.md)
* [MFPS/MTPS: microcode, FRAM, flags/IRQ и fault tests](docs/psw-transfer.md)
* [CC/NOP/MFPT: microcode, три fit-варианта и проверки](docs/system-flags.md)
* [Trace/RTT: архитектура, проверки и ограничения](docs/trace-rtt.md)
* [Текущий статус](docs/implementation-status.md), [benchmarks](docs/benchmarks.md)
* [Предыдущие эксперименты](docs/previous_experiments.md)
* [Архитектура](docs/architecture.md), [микроархитектура](docs/microarchitecture.md), [microcode format](docs/microcode-format.md)
* [FRAM и периферия lsi11-fpga](docs/fram-peripherals.md)
* [Memory faults](docs/memory-faults.md), [reserved traps](docs/reserved-traps.md), [IRQ/WAIT/SPL](docs/interrupts.md)
* [Software traps/RTI](docs/software-traps.md), [control flow](docs/control-flow.md), [byte ISA](docs/byte-instructions.md)
