# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес16 bits.

**CP21 выполнен:** добавлена ASH во всех8 addressing modes через существующие
RF/ALU, без нового RTL state. Один kernel register set, CM=PM=RS=0, NZVC/IPL/T.
Работают word/byte integer ISA, branches, JMP/JSR/RTS/SOB, SWAB/SXT/MARK,
software/reserved/memory traps, RTI/RTT, IRQ/WAIT/SPL, CC/NOP/MFPT, MFPS/MTPS,
HALT в restart-профиле нашего DCJ11 emulator и peripheral RESET.
MUL/DIV/ASHC/XOR, полный native ODT и запуск ОС пока не заявлены.
Память — **SPI FRAM**, instruction-stream prefetch и KW11/KL11 IRQ adapter.

| Измеренный scope | LUT4 | FF | EBR | Constraint | TRACE Fmax |
|---|---:|---:|---:|---|---:|
| Core + probe | **849** | 299 | 4 | **35 MHz PASS** | **36.876 MHz** |
| Core + FRAM/prefetch + IRQ adapter + probe | **1094** | 416 | 4 | **29.56 MHz PASS** | **31.309 MHz** |

Реальные Diamond MAP/PAR/TRACE для HC1200. Полные UART/timer/panel/SD/RK
и внешние pin delays в fit не входят;50 MHz остаётся целью.
До желательных1100 LUT осталось6; до физических1280 —186.
[Отчёты synthesis](docs/synthesis.md).

Микрокод: **551/1024 ×36 bits**, encoding **v11**. Все521 прежних words/labels
сохранены. ASH использует T0/T4/T6 и прежние shifts/CJUMP; +9 LUT в FRAM scope,
те же FF/EBR. Отдельный аппаратный counter не добавлялся.

Проверены **202597 completed DCJ11 cases** на каждом RAM/FRAM×portable/vendor
ROM сочетании и **34812 fault frames**. Новая ASH группа:26316 completed,
888 явно исключённых candidates; отдельно1024 fault frames без exclusions.
**890 benchmark runs** на ROM-модель; все794 прежних counts сохранены.
96 result files обеих ROM совпали побайтно. ASH +1/−1 с ideal FETCH —20/16 clocks;
FRAM register loops count0/+1/−1 —40.15625 CPI смеси ASH/BR.
Это functional simulation; FPGA не программировалась.

```
make verify-cp21                  # full portable/vendor tests, benchmarks, evidence
make test                        # full portable regression and lint
make test-eis-ash test-eis-ash-fault
make benchmark-eis-ash            # 24 workloads x4 memory modes
make all                         # ROM, listing, labels, occupancy, DP8KC lanes
make synthesis                   # CP21a, 35 MHz
make synthesis-fram              # CP21b, 29.56 MHz
```

Нужны Python 3, Icarus Verilog, Verilator и C compiler. Oracle собирается из
существующего `../core/` с `ENABLE_MMU=0`; проект находится внутри k1801vm1.
Diamond 3.14.0.75.2 настроен на `sash@192.168.1.108`, default path
`$HOME/.local/lscc/diamond/3.14`. `DIAMOND_HOME` и `LATTICE_SIM_DIR` можно
переопределить; локальные vendor tests используют `LATTICE_SIM_DIR=build/vendor`.
Команды synthesis запускаются на Linux-сервере с Diamond; тесты — локально.
Каждый synthesis gate требует свежего implementation directory.

Следующие gates — оставшиеся EIS и контроль площади; до желательных1100 LUT
осталось6. Каждое расширение требует отдельного HC1200 fit.
J-11 banking и полный board top ещё предстоят. Неподдержанная ISA получает
vector010; это не её реализация. MMU в эти этапы не входит. FPGA не программировалась.

* [ASH: алгоритм, alias/flags/fault проверки и измерения](docs/eis-ash.md)
* [HALT/RESET: профиль, периферия, ошибки и измерения](docs/system-control.md)
* [MFPS/MTPS: microcode, FRAM, flags/IRQ и fault tests](docs/psw-transfer.md)
* [CC/NOP/MFPT: microcode, три fit-варианта и проверки](docs/system-flags.md)
* [Trace/RTT: архитектура, проверки и ограничения](docs/trace-rtt.md)
* [Текущий статус](docs/implementation-status.md), [benchmarks](docs/benchmarks.md)
* [Предыдущие эксперименты](docs/previous_experiments.md)
* [Архитектура](docs/architecture.md), [микроархитектура](docs/microarchitecture.md), [microcode format](docs/microcode-format.md)
* [FRAM и периферия lsi11-fpga](docs/fram-peripherals.md)
* [Memory faults](docs/memory-faults.md), [reserved traps](docs/reserved-traps.md), [IRQ/WAIT/SPL](docs/interrupts.md)
* [Software traps/RTI](docs/software-traps.md), [control flow](docs/control-flow.md), [byte ISA](docs/byte-instructions.md)
