# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес 16 bits.

**CP26 завершён: микрокодный DIV**, RF 16×16/ALU/Q и FRAM transport сохранены.
Microstore **700/1024×36 v11**. Все 642 слова CP25 остались на своих адресах.

| Измеренный scope | LUT4 | FF | EBR | Constraint | TRACE Fmax |
|---|---:|---:|---:|---|---:|
| Core + probe, CP26a | **867** | 299 | 4 | **35 MHz PASS** | **37.151 MHz** |
| Core + FRAM/prefetch + IRQ adapter + probe, CP26b | **1099** | 416 | 4 | **29.56 MHz PASS** | **31.771 MHz** |

До желательных 1100 остался **1 LUT**, до физических 1280 — 181. Полные
UART/timer/panel/SD/RK и external pin timing в fit не входят. Следующая
задача — снижение площади. 50 MHz и 900–1000 LUT ещё не достигнуты.

Прошли **268907 instruction cases + 49596 fault frames** на каждом
RAM/FRAM × portable/vendor сочетании, **1146 benchmarks/ROM**. Все 128
result files равны, все 120 прежних results/24 C fixtures побайтно сохранены.
DIV дополнительно проверен на 861968 arithmetic pairs, 7322 independent
ordinary records, 15 rejected mutations и 2048 CSR cases/ROM.
[DIV, документы и C correction](docs/eis-div.md),
[manifest](docs/verification-cp26.json), [benchmarks](docs/benchmarks-cp26.json).

Работают word/byte integer ISA, все addressing modes, branches, JMP/JSR/RTS/SOB,
SWAB/SXT/MARK, traps/RTI/RTT, trace, IRQ/WAIT/SPL, CC/NOP/MFPT, MFPS/MTPS,
HALT restart, peripheral RESET, ASH/ASHC/XOR/MUL/DIV. Один kernel register set,
CM=PM=RS=0, NZVC/IPL/T. Память — **MR45V100A SPI FRAM**. Для DIV DEC требует
even R; odd R — отдельное программное расширение. Banking, native ODT и
запуск ОС ещё предстоят. MMU отсутствует; FPGA не программировалась.

```
make all                         # ROM, listing, labels, occupancy, DP8KC lanes
make test                        # full portable regression and lint
make test-div-oracle test-div-negative
make verify-cp26                 # full portable/vendor regression and archive
make test-reference-core         # existing C core regression
make benchmark-eis-div           # 16 workloads x4 memory modes
make synthesis                   # CP26a, 35 MHz; Linux host with Diamond
make synthesis-fram              # CP26b, 29.56 MHz; same host
```

Нужны Python 3, Icarus Verilog, Verilator, C compiler и Lattice simulation
models для vendor tests. Yosys нужен только для отдельной прежней проверки
микросеквенсора; [CP23 proof и установка](docs/area-sequencer.md).
Oracle собирается из существующего `../core/` с `ENABLE_MMU=0`; проект находится
внутри k1801vm1. Diamond 3.14.0.75.2 настроен на `sash@192.168.1.108`, default
path `$HOME/.local/lscc/diamond/3.14`. `DIAMOND_HOME` и `LATTICE_SIM_DIR` можно
переопределить; локальные vendor tests используют `LATTICE_SIM_DIR=build/vendor`.
Каждый synthesis gate требует свежего implementation directory.

Следующий этап — снижение площади перед полным board top.
MMU в эти этапы не входит; ресурсы под него не резервируются.

* [CP26: DIV, документы, проверки и измерения](docs/eis-div.md)
* [CP25: MUL, исправление эталона и измерения](docs/eis-mul.md)
* [CP24: XOR, проверки и измерения](docs/eis-xor.md)
* [CP23: площадь микросеквенсора](docs/area-sequencer.md)
* [ASHC и исправления ASH/эталона](docs/eis-ashc.md)
* [ASH: алгоритм, alias/flags/fault проверки и измерения](docs/eis-ash.md)
* [HALT/RESET: профиль, периферия, ошибки и измерения](docs/system-control.md)
* [MFPS/MTPS: microcode, FRAM, flags/IRQ и fault tests](docs/psw-transfer.md)
* [CC/NOP/MFPT: microcode, три fit-варианта и проверки](docs/system-flags.md)
* [Trace/RTT: архитектура, проверки и ограничения](docs/trace-rtt.md)
* [Текущий статус](docs/implementation-status.md), [benchmarks](docs/benchmarks.md)
* [Предыдущие эксперименты](docs/previous_experiments.md)
* [Архитектура](docs/architecture.md), [микроархитектура](docs/microarchitecture.md), [microcode format](docs/microcode-format.md)
* [FRAM и периферия lsi11-fpga](docs/fram-peripherals.md)
* [Memory faults](docs/memory-faults.md), [reserved traps](docs/reserved-traps.md), [IRQ/WAIT/SPL](docs/interrupts.md)
* [Software traps/RTI](docs/software-traps.md), [control flow](docs/control-flow.md), [byte ISA](docs/byte-instructions.md)
