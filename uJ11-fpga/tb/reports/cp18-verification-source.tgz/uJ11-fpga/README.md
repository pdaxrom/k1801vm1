# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес 16 bits.

**CP18 выполнен:** добавлены все CC/NOP encodings и MFPT. Поддерживаются один kernel register
set, CM=PM=RS=0, NZVC/IPL/T; переключение banks/modes ещё не реализовано.
Работают семь word и пять byte double-operand classes, 12 word и 12 byte unary
classes, все восемь addressing modes, 15 branch classes, JMP/JSR/RTS/SOB,
SWAB/SXT/MARK, software/reserved/memory traps, RTI/RTT, IRQ/WAIT/SPL, CC/NOP/MFPT.
Память — **SPI FRAM**, с instruction-stream prefetch и KW11/KL11 IRQ adapter.
Полный J-11 instruction set и запуск ОС пока не заявлены.

| Измеренный scope | LUT4 | FF | EBR | Constraint | TRACE Fmax |
|---|---:|---:|---:|---|---:|
| Core + probe | **843** | 297 | 4 | **35 MHz PASS** | **35.674 MHz** |
| Core + FRAM/prefetch + IRQ adapter + probe | **1062** | 414 | 4 | **29.56 MHz PASS** | **30.409 MHz** |

Реальные Diamond MAP/PAR/TRACE для HC1200. FRAM scope включает IRQ resolver
BR4/BR6. Полные UART/timer/panel/SD/RK и внешние pin delays сюда не входят.
Начальная цель 50 MHz остаётся открытой. [Synthesis](docs/synthesis.md).

Микрокод: **493/1024 × 36 bits**, encoding **v10**. CP18 сохраняет все прежние
452 words и labels; меняется только opcode dispatch и добавляется microcode.
RF16×16, Q и один ALU adder сохранены. MOVB в регистр знаково расширяет byte;
остальные byte writes сохраняют старшую половину регистра.
Пересобирать microassembler, microcode и RTL вместе.

При T=0 RR и 12 word/12 byte unary classes имеют одну execution
microinstruction: с FETCH — **2 CPI** при ideal RAM. Прежние word RR loops
с FRAM сохранили **39.078125 CPI** при nominal CPU/SPI 29.56/14.78 MHz.
Trace добавляет 16 clocks frame при ideal RAM. Это RTL simulation.

Проверены **157285 completed DCJ11 cases** на каждой RAM/FRAM × portable/vendor
ROM: 136165 прежних и 21120 CC/NOP/MFPT cases без новых exclusions. Ещё **32780 memory-fault frames**
сравниваются на границе входа в handler. Exclusions и ограничения oracle
перечислены в отчётах. Byte ALU — 2097152 checks; RF merge — 16384.
**766 benchmark runs** на ROM-модель; все 746 прежних counts сохранены.
CC/NOP — 4 CPI ideal RAM, MFPT — 2.

```
make verify-cp18                  # portable + vendor, snapshots, evidence recorder
make test                        # full portable regression and lint
make benchmark benchmark-fram benchmark-ea benchmark-cp9 benchmark-byte benchmark-control benchmark-extra benchmark-trap benchmark-irq benchmark-illegal benchmark-trace benchmark-system-flags
make all                         # ROM, listing, labels, occupancy, DP8KC lanes
make synthesis                   # CP18e, 35 MHz
make synthesis-fram              # CP18f, 29.56 MHz
```

Нужны Python 3, Icarus Verilog, Verilator и C compiler. Oracle собирается из
существующего `../core/` с `ENABLE_MMU=0`; проект находится внутри k1801vm1.
Diamond 3.14.0.75.2 настроен на `sash@192.168.1.108`, default path
`$HOME/.local/lscc/diamond/3.14`. `DIAMOND_HOME` и `LATTICE_SIM_DIR` можно
переопределить; локальные vendor tests используют `LATTICE_SIM_DIR=build/vendor`.
Каждый synthesis gate требует свежего implementation directory.

Следующие gates — MFPS/MTPS, HALT/RESET и оставшиеся system operations, затем EIS.
J-11 banking и полный board top ещё предстоят. Неподдержанная ISA получает
vector010; это не её реализация. MMU в эти этапы не входит. FPGA не программировалась.

* [CC/NOP/MFPT: microcode, три fit-варианта и проверки](docs/system-flags.md)
* [Trace/RTT: архитектура, проверки и ограничения](docs/trace-rtt.md)
* [Текущий статус](docs/implementation-status.md), [benchmarks](docs/benchmarks.md)
* [Предыдущие эксперименты](docs/previous_experiments.md)
* [Архитектура](docs/architecture.md), [микроархитектура](docs/microarchitecture.md), [microcode format](docs/microcode-format.md)
* [FRAM и периферия lsi11-fpga](docs/fram-peripherals.md)
* [Memory faults](docs/memory-faults.md), [reserved traps](docs/reserved-traps.md), [IRQ/WAIT/SPL](docs/interrupts.md)
* [Software traps/RTI](docs/software-traps.md), [control flow](docs/control-flow.md), [byte ISA](docs/byte-instructions.md)
