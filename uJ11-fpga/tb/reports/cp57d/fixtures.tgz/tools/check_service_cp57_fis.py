#!/usr/bin/env python3
"""Unchanged exact FIS oracle on the service-bank CPU, with both ready bits off."""
import hashlib
import json
from board_common import ROOT
from build_service_cp57 import adapt, OUT
from run_fis_tests import compile_test, execute, CORE


def main():
    adapt()
    tb=(ROOT/'tb/tb_fis.v').read_text().replace('ROM_DECODE=0','ROM_DECODE=1')
    tb=tb.replace('.mem_addr(addr)', '.mem_bank(),.mem_physical(),.mem_addr(addr)')
    (OUT/'tb_fis.v').write_text(tb)
    joined=OUT/'core-with-decode.v'
    joined.write_text('\n'.join((OUT/'src'/p).read_text() for p in
        ['rtl/uj11_core.v','rtl/uj11_decode_rom.v','microcode/generated/uj11_decode_table.v']))
    replacements={p:str(OUT/'src'/p) for p in CORE}
    replacements.update({'rtl/uj11_core.v':str(joined),'tb/tb_fis.v':str(OUT/'tb_fis.v'),
        'microcode/generated/uj11_m0_ebr.v':str(OUT/'uj11_m0_ebr.v')})
    vectors='build/fis-vectors.txt'
    for vendor in (False,True):
        tag='cp57-fis-'+('vendor' if vendor else 'portable')
        cmd=compile_test(-1,'iverilog' if vendor else 'verilator',vendor,candidate=False,tag=tag,replacements=replacements)
        execute(cmd,tag,vectors,jobs=4)
        log=(ROOT/f'build/{tag}.log').read_text();print(log.splitlines()[-1])
    files=['tools/check_service_cp57_fis.py','tools/run_fis_tests.py',vectors,'tb/tb_fis.v',
        'build/cp57-service/inputs.json','build/cp57-service/core-with-decode.v','build/cp57-service/tb_fis.v',
        'build/cp57-fis-portable.log','build/cp57-fis-portable.csv','build/cp57-fis-vendor.log','build/cp57-fis-vendor.csv']
    (OUT/'fis-inputs.json').write_text(json.dumps({p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')

if __name__=='__main__':main()
