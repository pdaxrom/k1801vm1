    // CP57 single frozen context. Cold reset clears readiness, not FRAM.
    reg service_mode;
    reg [1:0] service_ready;
    reg [15:0] service_pc, service_psw;
    wire [2:0] service_space=(reading || writing) ? uword[9:7] : 3'd0;
    wire service_internal=service_space[2];
    wire service_enter=control && command==0 && uword[2:1]==1;
    wire service_leave=control && command==0 && uword[2:1]==2;
    wire [15:0] service_rdata=
        ({16{service_space==4}} & service_pc) |
        ({16{service_space==5}} & service_psw) |
        ({16{service_space==6}} & {8'b0,!service_ready[1],5'b0,service_ready});
    // ACTIVE selects current CPU space. GUEST is logical bank zero;
    // UPPER/LOWER bypass every CPU ROM/CSR overlay for raw physical RAM.
    assign mem_bank=service_space==0 ? service_mode : service_space==2;
    assign mem_physical=service_space==2 || service_space==3;
    always @(posedge clk) begin
        if(reset)begin
            service_mode<=0;
            service_ready<=0;
            service_pc<=0;
            service_psw<=0;
        end else if(step)begin
            if(service_enter)service_mode<=1;
            if(service_leave)service_mode<=0;
            if(writing)case(service_space)
                4: service_pc<=read_b;
                5: service_psw<=read_b;
                6: service_ready<=read_b[1:0];
                default: begin end
            endcase
        end
    end
    // Use the opcode prefix instead of comparing ten microcode entry addresses.
    // Logic decode consumes incoming data; EBR decode has already captured IR.
    wire [15:0] service_ir=ROM_DECODE!=0 ? ir : dispatch_ir;
    wire service_privileged=service_ir[15:6]==0 &&
        (service_ir[5] ? service_ir[4:1]==2 : |service_ir[4:3]);
    wire [9:0] service_dispatch=
        service_ir[15:12]==4'hf ? (service_mode ? 10'h3ff : service_ready[1] ? S_FP : 10'h042) :
        service_ir==0 ? (service_mode ? 10'h3ff : service_ready[0] ? S_ODT : 10'h018) :
        (!service_mode && service_privileged) ? 10'h042 : dispatch_address;
