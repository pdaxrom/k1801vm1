# Микроархитектура: CP1 и предложенный M0

## Реализовано в CP1

`uj11_microseq` содержит uPC10, link10 и link_valid. Входы predicates и
dispatch поступают снаружи. Synchronous ROM выдаёт uword36. На каждом
разрешённом фронте выполняются две операции: uPC←next_address и
uword←ROM[next_address]. Они используют один enable, поэтому uPC всегда
соответствует адресу текущей микрокоманды. При reset адрес принудительно 0,
ROM enable=1, остальные side effects будущего datapath заблокированы.

```
current uword ──► next-address logic ──► ROM address
      ▲                                 │
      └───────── next clock ─────────────┘
```

NEXT — 10-bit increment; PAGE — high2 от uPC плюс low8 из microinstruction;
JUMP/CALL — полный 10-bit target. OR-dispatch объединяет base с IR bits,
не содержит adder. CALL использует link depth1. CJUMP читает PSW/Q/counter/
error inputs через 8:1 predicate mux и inversion bit. Memory wait реализуется
общим enable снаружи, а не отдельной state machine внутри sequencer.

Microstore image формируется assembler, не пишется вручную. Portable ROM
нужен только для Icarus/Verilator. Diamond input заменяет его четырьмя
DP8KC, generated из тех же слов; компилировать оба ROM modules нельзя.
Физические INITVAL содержат пары 9-bit words в 20-bit slots; bits18/19
каждого slot нулевые. ADA12..3=address9..0, ADA2..0=001, NOREG.
NOREG не означает asynchronous ROM: чтение остаётся по фронту CLKA.

CP1 probe имеет 40-bit serial stimulus и 1-bit registered XOR observer.
Stimulus постоянно сдвигается, output включает все uword bits и оба
микроадреса. Это удерживает ROM/selector/control cones при синтезе на SG32
с четырьмя внешними pins. FF41 и XOR относятся к harness. Фактические
LUT/FF после оптимизации не следует вычислять простым вычитанием из MAP:
нужно отдельно читать Synplify hierarchy и проверять, что не удалено.

## M0: ещё не написанный datapath

RF два asynchronous reads, одна synchronous запись. B одновременно является
write address. Dynamic selectors преобразуют literal/RS/RD в четыре bits
до RF, поэтому ADD R1,R2 сможет выполнить оба чтения, ALU, запись R2 и NZVC
одной execution microinstruction. Dedicated hardwired ADD_RR engine не нужен.

Сначала два resource probes RF: distributed dual-read и FF/mux fallback;
сравнивать whole MAP и RF hierarchy. Не выбирать EBR RF автоматически:
два synchronous reads плюс write часто потребуют репликации или phases,
что нарушит ожидаемый один ALU execution cycle. Не сбрасывать RF массив
reset-циклом RTL, мешающим inference: его очистит короткий reset microcode.

PC read для memory необходимо получить без третьего variable RF port.
Сравнить mirror16 FF, записываемый по B=7, с вынесенным R7 и A/B bypass.
Оба варианта должны сохранять единственную architectural PC value и
отражать запись R7 любым opcode; implicit PC+2 также проходит writeback.

IR фиксируется при FETCH completion. Decode входящего bus word допускается
подавать прямо на dispatch input, чтобы execution microinstruction стала
доступна сразу после того же фронта. Пока memory не подтверждает запрос,
RF/PSW/IR/Q и uword удерживаются. Address/data должны быть стабильны.

Пример **предлагаемого**, пока не измеренного цикла для always-ack RAM:
FETCH (memory read + PC+2 + IR/decode) → EXECUTE (RF/ALU/flags) → FETCH.
Ожидаемые два microclocks нельзя записывать как measurement до integrated
testbench; зарегистрированный memory request или response добавит clocks.
Без speculative memory чтения overlap не является проверенным prefetch.

## Decision gate

Первый ожидаемый critical path: DP8KC output → condition/OR/next mux → DP8KC
address. Надо изучить `.twr`, не только synthesis Fmax. Если feedback path
не достигает 50 MHz, измерить более узкий seq decode, factoring condition
и page organization до добавления pipeline bubble. Если новый stage
ухудшает LUT или timing, сохранять оба reports/source manifests.

RF/Q/ALU, core memory unit, opcode decoder, PSW update и prefetch RTL ещё
отсутствуют. Их encoding в документе не означает реализацию или проверку.
