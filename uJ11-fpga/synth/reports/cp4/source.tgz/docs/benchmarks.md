# Benchmarks: методика и текущие результаты

PDP-11 instructions пока не исполняются. **Нет измеренного CPI, memory CPI,
Fmax или instructions/sec uJ11.** CP1 image 45 words проверяет только
microstore/sequencer; 17 transitions — не benchmark guest ISA.

| Workload | LUT/FF/EBR | Fmax | Microclocks/instruction | Memory cycles/instruction | PDP-11 instr/s |
|---|---|---|---|---|---|
| CP1 sequencer diagnostics | unknown | unknown | N/A | N/A | N/A |
| MOV R,R | pending M0 | pending | pending | pending | pending |
| ADD R,R / CMP R,R / mixed | pending M0 | pending | pending | pending | pending |
| BR loop | pending M0 | pending | pending | pending | pending |

Для M0 bench считать clocks между retire boundaries после reset/warmup,
retired instructions и accepted bus transactions (`request && ack`).
Отдельно фиксировать CPU stalls, instruction-stream fetches и data cycles.
Zero-wait, deterministic N-wait и random-ack memory — разные результаты.
На trace указывать instruction sequence, initial registers/PSW и memory
latency. Counts не смешивать с reset/host-side checks.

Throughput при выбранном operating clock: clock_hz / measured CPI. Частота
50 MHz — goal, пока timing не подтверждён; TRACE Fmax — расчётная граница,
не физически проверенный operating clock. 1–2 clocks/PDP-11 instruction
остаются целью после memory/prefetch integration.

Differential oracle: существующий `../../core/core.c` в модели DCJ11 с
`ENABLE_MMU=0`, один `core_step` на fixture. Нужны сравнения R0–R7/PSW,
memory delta и trap state после retirement. Начальные edge fixtures:
zero, 0x7fff, 0x8000, 0xffff, carry/borrow, same Rs=Rd, все 64 пары
register selectors, включая PC и SP. CMP считает Rs−Rd, MOV сохраняет C.
PC как source читается после fetch increment; запись PC меняет следующий
fetch. Нечётный fetch должен быть отдельно проверен, без bus request.

Дальше расширить matrix: byte sign-extension/MOVB, ADC/SBC, shifts,
все EA modes и PC/SP step, trap stack/RTI, EIS boundary/random loops.
У J-11 register source при memory destination может читаться **после**
destination EA side effects; existing C/reference tests должны сохранить
этот порядок. Обычный учебный PDP-11 emulator не всегда достаточен как oracle.

Полный набор workload после соответствующих ISA stages: memory→register,
register→memory, memory→memory, conditional branch loop, JSR/RTS,
stack-intensive program, MUL/DIV/ASH/ASHC и небольшой реальный program.

Исторические workload counts доступны в [previous_experiments.md](previous_experiments.md).
Сравнение времени с AM4/Stable возможно только на общей RAM model и том же
binary; SPI FRAM full-board clocks не сравниваются с zero-wait RAM CPI.
