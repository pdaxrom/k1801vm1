# Implementation status, 2026-09-08

**M0 не завершён. Активный gate: CP1, ожидается реальный синтез HC1200.**

| Требование первого milestone | Состояние |
|---|---|
| Анализ microcpu/microasm/AM4/emulator/tests | выполнен; historical reports индексированы |
| previous_experiments.md с цифрами | выполнен; 22 raw MAP reports, paths и SHA-256 в JSON |
| Конкретное microarchitecture proposal | выполнено, ещё не утверждено измерениями |
| 36-bit format v1 | зафиксирован, parser/encoder проверены |
| microsequencer | реализован NEXT/PAGE/JUMP/CJUMP/CALL/RETURN/OR dispatch |
| 1024×36 microstore | portable RTL + generator четырёх DP8KC |
| microasm backend | ROM/listing/labels/stats, overlap/range/conflict diagnostics |
| Local CP1 testbench | проходит |
| Vendor DP8KC simulation | не запускалась: model недоступна локально |
| Реальный synthesis/MAP/PAR/TRACE HC1200 | **не выполнен**, Diamond-хост недоступен |
| RF16×16, Q, ALU, IR, PSW, MDR, core memory | следующий gate, RTL не добавлен |
| FETCH, MOV/ADD/CMP R,R, BR | не реализованы |
| Differential ISA testing | reference выбран, сравнение с uJ11 ещё невозможно |
| PDP-11 CPI / throughput | не измерены |
| Prefetch / general EA / traps / EIS | последующие gates |
| MMU | отсутствует, включая заготовки и резервирование ресурсов |

Локальная проверка: `make test` с Python 3, Icarus Verilog и Verilator 5.050.

* 6 Python test methods: format, error cases, physical lane packing всех
  1024 случайных 36-bit слов, 4 lanes / 128 INITVAL.
* 4323 sequencer checks: predicates и inversion, все source/destination
  modes, OR_RR/BT/R67, все 1024 opcode dispatch targets, NEXT/PAGE/wrap,
  single-link CALL/RETURN, stalls, overflow/underflow и reset.
* 1024 portable ROM reads и 1024 enable holds.
* 17 ожидаемых ROM/sequencer transitions со stalls перед каждым переходом;
  uPC/uword остаются согласованными, нет дополнительного sequencing bubble.
* Verilator `--lint-only --Wall` без предупреждений.

CP1 diagnostic image: **45/1024 words, 4.39%**, это не PDP-11 instruction
microcode. Большинство ROM rows заполнены безопасным STOP. ALU words в
probe служат проверке encoding/sequencing, их datapath side effects пока
не исполняются. Тест не должен выдаваться за проверку MOV/ADD/CMP.

Следующее действие: доступный Linux Diamond host → `make vendor-test` →
fresh `make synthesis` → зафиксировать MAP/PAR/TRACE и выяснить actual
critical path → RF/Q/ALU gate. Останавливаться на этом порядке требует
исходное условие пользователя «не создавать большую реализацию до первого
минимального synthesis checkpoint»; не дополнительный approval workflow.
