`timescale 1ns/1ps
// M0 only. IR opcode bits directly form the RR microaddress.
// Unsupported modes/opcodes go to diagnostic STOP, never a partial operation.
module uj11_decode(input wire [15:0] ir,output wire [9:0] entry);
    wire rr = {ir[11:9],ir[5:3]}==6'b0;
    wire supported_rr = rr && (ir[15:12]==4'h1 || ir[15:12]==4'h2 || ir[15:12]==4'h6);
    assign entry = supported_rr ? {2'b01,ir[15:12],4'b0} :
                   ir[15:8]==8'h01 ? 10'h180 : 10'h3ff;
    wire unused_register_bits = ^{ir[7:6],ir[2:0]};
endmodule
