# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес 16 bits.

Текущий результат: проанализированы microcpu/microasm/AM4 и прошлые измерения;
подготовлен и локально проверен **CP1: microsequencer + 1024×36 microstore**.
Реальный Diamond MAP/PAR/TRACE пока не выполнен: существующий Linux-хост
недоступен. Это ещё не исполняющий PDP-11 core и не завершённый milestone M0.
Расширение RTL остановлено на первом synthesis gate согласно порядку проекта.

```
make test       # Python assembler/packing + Icarus RTL tests + Verilator lint
make audit      # индекс и SHA-256 найденных исторических MAP/TRACE reports
make microcode  # MEM + listing + labels + stats + четыре DP8KC lanes
```

Для Diamond 3.14 на Linux:

```
make vendor-test DIAMOND_HOME=/home/sash/.local/lscc/diamond/3.14
make synthesis DIAMOND_HOME=/home/sash/.local/lscc/diamond/3.14
```

`make synthesis` использует **LCMXO2-1200HC-4SG32C**, 50 MHz,
`synth/machxo2/uj11-seq.ldf`. Выполняет synthesis/translate/map/PAR/TRACE,
сохраняет raw reports и JSON. Требует свежую `impl1`, не принимает
инкрементальный no-op за новый результат. Программирования FPGA нет.
SG32 probe использует четыре пина; его вспомогательные FF/logic должны
учитываться отдельно от измеряемого блока. Это не pinout рабочей платы.

После успешного CP1: измерить RF16×16/Q/ALU, затем минимальный datapath,
decoder и только FETCH, word MOV/ADD/CMP R,R, BR. Тесты с C reference и
PDP-11 CPI относятся к этому следующему результату. Prefetch — отдельный
измеряемый checkpoint после baseline; MMU отсутствует во всех stages v1.

Документы:

* [Предыдущие эксперименты и конкретные цифры](docs/previous_experiments.md)
* [Архитектурное предложение](docs/architecture.md)
* [Микроархитектура и следующий gate](docs/microarchitecture.md)
* [36-bit format v1](docs/microcode-format.md)
* [Точный implementation status](docs/implementation-status.md)
* [Synthesis и блокирующая зависимость](docs/synthesis.md)
* [Benchmark methodology](docs/benchmarks.md)

Assembler backend `microasm/uj11asm.py` сохраняет labels, `.org`, `$hex`,
readable operations, listing и диагностику, знакомые по microasm; это новый
backend с отдельным encoding, не замена существующим microasm/microasm11.
Ни AM4 RTL, ни его control store в uJ11 не скопированы. Физическая схема
упаковки DP8KC проверена по существующему AM4 generator; vendor test для
нового ROM ещё должен пройти на Diamond-хосте.
