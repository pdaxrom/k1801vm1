`timescale 1ns/1ps
module tb_decode;
    reg [15:0] ir;
    wire [9:0] entry;
    reg [9:0] expected;
    integer i,accepted=0;
    uj11_decode dut(.*);
    initial begin
        for(i=0;i<65536;i=i+1) begin
            ir=i[15:0];
            expected=10'h3ff;
            // Independent octal masks for the exact PDP-11 encodings.
            if((i & 'o177400)=='o000400) expected='h180;
            if((i & 'o177070)=='o010000) expected='h110;
            if((i & 'o177070)=='o020000) expected='h120;
            if((i & 'o177070)=='o060000) expected='h160;
            #1;
            if(entry!==expected) $fatal(1,"decoder opcode%06o got%h expected%h",i,entry,expected);
            if(entry!=10'h3ff) accepted=accepted+1;
        end
        if(accepted!=448) $fatal(1,"accepted opcode count %0d",accepted);
        $display("PASS decoder: all 65536 opcodes, exactly 448 supported encodings");
        $finish;
    end
endmodule
