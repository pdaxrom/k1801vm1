# 36-bit microinstruction, encoding version 2

Version 2 сохраняет ALU encoding v1, но выравнивает control A/B с ALU A/B.
Это убрало mux перед динамическим выбором RF. CP3r1 → CP3r2:
625 → 610 LUT4, 38.389 → 39.228 MHz при constraint 50 MHz (оба timing fail).
Старые v1 images несовместимы с текущим control decoder; пересобирать
microcode и RTL вместе. Исходные варианты сохранены в synthesis archives.

Слово 36 bits; bit35 выбирает ALU (0) или control (1). У каждого слова
одна строка source; labels, `.org`, `$hex`, `0xhex`, decimal и `; comments`
сохраняют знакомый подход microasm. Backend отдельный: native microcpu
16-bit opcodes с этим форматом бинарно несовместимы.

## ALU word

| Bits | Width | Поле |
|---|---:|---|
| 35 | 1 | 0 |
| 34:31 | 4 | ALU operation |
| 30:26 | 5 | A selector |
| 25:21 | 5 | B selector, также RF write address |
| 20:18 | 3 | operand pair |
| 17:15 | 3 | destination / Q shift |
| 14:13 | 2 | PSW update |
| 12:10 | 3 | D input |
| 9:8 | 2 | sequencing |
| 7:0 | 8 | page next или unsigned immediate8 |

ALU op 0..15: PASSA, PASSB, ADD, ADC, SUB, SBC, AND, OR, XOR, BIC,
NOTA, LSL, LSR, ASR, ROL, ROR. SUB/SBC вычисляют A−B[−C], C=borrow.
Flags 0 KEEP, 1 NZV (preserve C), 2 NZVC, 3 LOAD (PSW←result).
Для word MOV используется PASSA/NZV, для CMP SUB/NZVC без записи.

A/B: 0..7 R0..R7, 8..15 T0..T7, 16 RS, 17 RD, 18 RS1, 19 RD1;
20..31 запрещены. RS1/RD1 означают IR register index **OR 1**, не +1.
Pairs 0 AB, 1 AQ, 2 AD, 3 DB, 4 ZB, 5 ZQ, 6 DA, 7 DZ.
D 0 ZERO, 1 ONE, 2 TWO, 3 STEP, 4 MDR, 5 DISP, 6 IMM, 7 PSW.
DISP=`sign_extend(IR[7:0])<<1`; STEP=1 для byte R0–R5, иначе 2.
STEP пока encoding для следующего EA gate, не аппаратный EA engine.
В M0 `byte_instruction=0`, поэтому STEP фактически равен 2. Наличие byte
транзакций в memory primitive не означает поддержку byte ISA.

Destination 0 NONE, 1 RF, 2 Q, 3 RFQ_L, 4 RFQ_R; 5..7 reserved.
RFQ_L: RF[B]←{result[14:0],Q[15]}, Q←{Q[14:0],0}.
RFQ_R: RF[B]←{result[15],result[15:1]}, Q←{result[0],Q[15:1]}.
Это encoding кандидата; EIS/byte flags не объявляются реализованными M0.
NZVC формируются из ALU result **до** RFQ_L/RFQ_R writeback shift;
совместный shift сам не обновляет flags. NOTA устанавливает ALU C=1;
PASS/AND/OR/XOR/BIC дают V=C=0; NZV update сохраняет архитектурный C.
Shifts/rotates дают V=N XOR shifted-out bit, C=shifted-out bit.

Sequencing 0 NEXT (uPC+1), 1 PAGE (`{uPC[9:8],low8}`),
2 FETCH (0x020, одновременно retirement), 3 reserved.
IMM использует low8 только с NEXT/FETCH. PAGE+IMM — ошибка assembler.
Без IMM/PAGE low8 должен быть нулём. Dsel != IMM с заданным literal запрещён.

Пример ровно одной execution microinstruction:

```
.org $160
ADD_RR:
    alu ADD, a=RS, b=RD, pair=AB, dst=RF, flags=NZVC, seq=FETCH
```

## Control word

| Bits | Width | Поле |
|---|---:|---|
| 35 | 1 | 1 |
| 34:31 | 4 | command |
| 30:26 | 5 | A selector, совпадает с ALU |
| 25:21 | 5 | B selector, совпадает с ALU |
| 20:11 | 10 | full target |
| 10:7 | 4 | condition |
| 6 | 1 | byte transaction |
| 5:0 | 6 | reserved, zero |

Command 0 JUMP, 1 CJUMP, 2 CALL, 3 RETURN, 4 DISPATCH,
5 OR_MS, 6 OR_MD, 7 OR_RR, 8 OR_BT, 9 OR_R67,
10 FETCH, 11 READ, 12 WRITE, 13 STOP; 14..15 reserved.
READ/WRITE продолжают на полный target после completion. FETCH — на
opcode entry из слова, принимаемого вместе с IR. Sequencer не декодирует
memory handshake: общий `enable` предотвращает повторение side effects.

Conditions 0 ALWAYS, 1 C, 2 V, 3 Z, 4 N, 5 Q0, 6 LOOPZ, 7 ERROR;
8..15 инвертируют соответствующий predicate. Условие читает старые flags.
Q0/LOOPZ/ERROR — входы sequencer primitive; loop counter не включён в M0 ISA.

OR masks: MS/MD 0x007, RR/BT 0x003, R67 0x001. Base должен быть выровнен
по mask+1; получаемые адреса должны принадлежать заполненным source words.
RR=`{dst_mode==0,src_mode==0}`; BT=`{address_odd,byte_instruction}`;
R67=`~(selected_A[2]&selected_A[1])`. Никакого hidden addition.

CALL записывает uPC+1 в единственный link register, RETURN его читает.
Аппаратного stack depth>1 в первом gate нет. Nested CALL и RETURN без CALL
направляют sequencer на 0x3ff; link_valid защищает сохранённый return address.
Оба случая проверяются unit tests. Ассемблер проверяет статические targets
и return continuation, но пока не доказывает максимальную динамическую
глубину вызовов через opcode dispatch.

Все неиспользуемые ROM locations заполняются STOP. Occupancy считается по
явно собранным словам, включая intentional dispatch stubs, отдельно от
1024 физических строк. `listing`, JSON labels/stats и EBR INITVAL генерируются
из одного assembled image. Hand-written hex ROM не используется.
