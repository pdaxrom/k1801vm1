# uJ11: архитектурное предложение M0

uJ11 — специализированный микрокодный PDP-11/J-11 integer execution engine
для LCMXO2-1200HC. Все адреса 16-битные, logical == physical. MMU отсутствует.
M0 намеренно не является полным J-11: только word MOV/ADD/CMP register-register
и BR. Запуск ОС, привилегии и полный instruction set пока не заявлены.

Ограничения: целевой полный core ~900–1000 LUT, желательно <1100 из 1280;
7 EBR всего, начальное ограничение clock 50 MHz. Это цели, не измерения.
Первый gate — ROM + sequencer. Затем RF/Q/ALU, integrated datapath, decoder,
минимальная ISA. Расширение после реального MAP/PAR/TRACE.

## Datapath

* Один 16-bit ALU, asynchronous dual-read RF 16×16, write port по B.
  R0–R7 архитектурные, T0–T7 временные. Q16 отдельно.
* Selectors 0–15 literal; RS/RD и RS|1/RD|1 динамические из IR.
* Один writeback; ALU operation и source selection независимы.
* Отдельный PSW16, IR16, MDR16; ALU flags N/Z/V/C, C при subtraction — borrow.
* FETCH читает слово по R7, ALU увеличивает R7 на 2, IR принимает opcode.
  Decode входящего слова выбирает execution microinstruction на том же
  фронте synchronous microstore. Дополнительного state decode не нужно.
* В M0 PC хранится только в RF[R7]. FETCH использует обычный A read port
  с A=B=R7. Третий RF port и PC mirror не нужны и не реализованы.

АЛУ MVP: PASS A/B, ADD/ADC, SUB/SBC (A−B), AND/OR/XOR/BIC, NOT A,
one-bit LSL/LSR/ASR/ROL/ROR. INC/DEC/NEG/reverse SUB выражаются source
selection и тем же adder. Q load и совместные RF/Q shifts — отдельные
destination controls. Не добавляются multiplier, divider и barrel shifter.
Byte datapath и flags — следующий gate, не скрытая часть word baseline.

## Microstore и sequencing

1024×36, четыре явных 1024×9 DP8KC, один фронт на микрокоманду.
Регистр выхода ROM служит uIR. Sequencer вычисляет **следующий** адрес
из текущего слова; при stall и ROM, и архитектурные side effects заморожены.
Reset принудительно читает entry 0, затем microcode инициализирует RF.

ALU word содержит common operation/enables и 8-bit next within page;
control word перекрывает datapath fields для полного 10-bit target,
condition и OR dispatch. Это не сохранение hardwired state enum в ROM.
CALL/RETURN M0: один return register (не рекурсивный стек). Для initial
EA routines можно использовать tail jumps; вложенные вызовы потребуют
отдельного измеренного изменения. В M0 ISA CALL не нужен, но primitive
проверяется первым sequencer unit test.

Fixed FETCH entry 0x020, reset page 0x000, RR execution entries
0x110 MOV, 0x120 CMP, 0x160 ADD, 0x180 BR, diagnostic STOP 0x3ff.
Остальные страницы пока свободны; они не резервируются под MMU.
Control dispatch OR_MS/MD/RR/BT/R67 задаёт entry OR IR predicates.
Assembler проверяет, что entry не маскирует выбираемые dispatch bits.

Initial decoder — несколько сравнений: opcode high nibble 1/2/6 и оба
mode==0; BR high byte 0x01. RR entry использует high nibble непосредственно.
Остальное ведёт в diagnostic STOP, без side effects неподдерживаемой ISA.
STOP — microengine fault, **не реализация PDP-11 HALT или trap vector 010**.
PLM/distributed-ROM сравниваются позже, когда decoder имеет содержательный
набор классов; полноразмерная decoder ROM для четырёх классов не нужна.

## Memory и prefetch

Одна транзакция: `addr[15:0], request, write, byte, write_data[15:0]`,
ответ `ack, read_data[15:0], error`. Read обозначается `request && !write`.
Completion происходит на фронте `request && ack`; error значим при ack.
Всю транзакцию address/control/data стабильны. Байт имеет точный byte
address и payload в write_data[7:0]. Word по нечётному адресу завершится
diagnostic fault до внешнего request в M0; архитектурный trap — Stage 2.
Память может отвечать с нулём или несколькими wait clocks. Wishbone отдельно.

Prefetch — отдельный checkpoint **после** минимального measured baseline.
Он представляет слово instruction stream, а не только opcode: immediate,
absolute и indexed extension потребляют тот же буфер. Самый простой
инвариант: PF_VALID означает слово по текущему PC; при любом PC redirect
буфер сбрасывается, outstanding response получает kill bit. Не нужно
16-bit PF_ADDR comparator, если этот инвариант доказан тестами; альтернативу
с адресом надо измерить. Autoincrement PC по consumption, не по speculative
request. Внешние I/O чтения не должны спекулироваться без контракта memory.
Арбитраж и invalidation для data write/self-modifying code требуют тестов.
Пока prefetch не реализован, цель 1–2 clocks/instruction не заявляется.

## J-11 banking и этапы

J-11 имеет alternate R0–R5, K/S/U stack pointers, PSW mode и register-set
bits независимо от memory translation. Их нельзя считать реализованными
только потому, что PSW физически 16-битный. M0 поддерживает один активный
набор и только NZVC; остальные PSW bits не используются в ISA.
Перед полноценными trap/RTI и privileged programs нужен microcoded обмен
активного набора с backing storage. Не увеличивать быстрый RF ради него.

После M0: Stage 1 — basic ISA и все EA modes, Stage 2 — traps/IRQ/PSW,
Stage 3 — EIS через Q/ALU/small counter, Stage 4 — нужные system instructions,
Stage 5 — измеренная оптимизация. MMU не входит ни в один из этих этапов.

Точные ограничения и текущий gate — [implementation-status.md](implementation-status.md).
