import importlib.util
import random
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


asm = module('asm', ROOT/'microasm/uj11asm.py')
ebr = module('ebr', ROOT/'tools/make_ebr.py')


class AssemblerTests(unittest.TestCase):
    def fail_source(self, source, error):
        with self.assertRaisesRegex(asm.AssemblyError, error):
            asm.assemble(source)

    def test_actual_program(self):
        image, listing, labels, stats = asm.assemble((ROOT/'microcode/checkpoint_seq.uasm').read_text())
        self.assertEqual(len(image), 1024)
        self.assertEqual(labels['CALLSITE'], 0x12)
        self.assertIn('110 ', listing)
        self.assertEqual(image[0x3ff], asm.STOP_WORD)
        self.assertEqual(image[0x333], asm.STOP_WORD)
        self.assertEqual(stats['used_words'], len(listing.splitlines()))

    def test_rr_encoding(self):
        word, edges = asm.encode('alu ADD, a=RS, b=RD, dst=RF, flags=NZVC, seq=FETCH', 0x160, {})
        self.assertEqual(word >> 35, 0)
        self.assertEqual(word >> 31 & 15, 2)
        self.assertEqual(word >> 26 & 31, 16)
        self.assertEqual(word >> 21 & 31, 17)
        self.assertEqual(word >> 15 & 7, 1)
        self.assertEqual(word >> 13 & 3, 2)
        self.assertEqual(word & 0x3ff, 0x200)
        self.assertEqual(edges, [0x20])

    def test_conflicts(self):
        for source, message in [
            (', a=R0', 'missing instruction'),
            ('alu ADD, a=R0, a=R1', 'duplicate/conflicting'),
            ('STOP, nonsense=1', 'unknown field'),
            ('STOP, target=0', 'unknown field'),
            ('FETCH, byte=1', 'unknown field'),
            ('alu ADD, a=R8', 'invalid value'),
            ('alu ADD, pair=DZ', 'invalid value'),
            ('alu ADD, seq=PAGE, next=0, d=IMM, imm=1', 'conflicts'),
            ('alu ADD, d=ZERO, imm=1', 'requires d=IMM'),
            ('alu ADD, d=IMM, imm=256', '8-bit range'),
            ('alu ADD, d=IMM, imm=-1', '8-bit range'),
            ('READ, target=0, byte=2', '1-bit range'),
            ('READ, target=0, a=R0, stream=1', 'requires a=R7'),
            ('READ, target=0, a=R7, stream=1, byte=1', 'requires a=R7'),
            ('READ, target=0, a=R7, stream=2', '1-bit range'),
            ('WRITE, target=0, a=R7, stream=1', 'unknown field'),
            ('READ, target=0, prefetch=2', '1-bit range'),
            ('alu ADD, prefetch=0', 'unknown field'),
            ('CJUMP, target=0', 'requires cond'),
            ('JUMP, target=1024', '10-bit range'),
            ('JUMP, target=MISSING', 'unknown symbol'),
            ('STOP\n.org 0\nSTOP', 'overlap'),
            ('a: STOP\na: STOP', 'duplicate label'),
            ('.org 1024\nSTOP', '10-bit range'),
            ('JUMP, target=1', 'unassembled'),
            ('alu ADD, seq=PAGE, next=$100', 'crosses page'),
            ('OR_MS, target=1', 'overlaps OR'),
            ('OR_MD, target=8', 'unassembled'),
            ('', 'empty'),
            ('.org $3ff\nSTOP\nSTOP', '10-bit range'),
        ]:
            with self.subTest(source=source):
                self.fail_source(source, message)

    def test_control_selectors_are_aligned(self):
        word, edges = asm.encode('READ, a=RS, b=RD1, target=$2a5, byte=1',0,{})
        self.assertEqual(word >> 26 & 31,16)
        self.assertEqual(word >> 21 & 31,19)
        self.assertEqual(word >> 11 & 1023,0x2a5)
        self.assertEqual(word >> 6 & 1,1)
        self.assertEqual(edges,[0x2a5])
        word, _ = asm.encode('CJUMP, cond=NOT_C, target=$3ff',0,{})
        self.assertEqual(word >> 7 & 15,9)
        self.assertEqual(word >> 11 & 1023,1023)
        word, _ = asm.encode('FETCH',0,{})
        self.assertEqual(word >> 26 & 31,7)
        self.assertEqual(word >> 21 & 31,7)
        self.assertEqual(word >> 31 & 15,asm.OPS['ADD'])
        self.assertEqual(word >> 18 & 7,asm.PAIRS['AD'])
        self.assertEqual(word >> 15 & 7,asm.DESTS['RF'])
        self.assertEqual(word >> 13 & 3,asm.FLAGS['KEEP'])
        self.assertEqual(word >> 10 & 7,asm.DINPUT['TWO'])

    def test_page_and_immediate(self):
        w, _ = asm.encode('alu PASSB, d=IMM, imm=$ff, seq=NEXT', 0, {})
        self.assertEqual(w & 255, 255)
        w, edges = asm.encode('alu ADD, seq=PAGE, next=$1fe', 0x1a0, {})
        self.assertEqual(w & 0x3ff, 0x1fe)
        self.assertEqual(edges, [0x1fe])

    def test_stream_extension(self):
        word, edges=asm.encode('READ, a=R7, stream=1, target=$31',0,{})
        self.assertEqual(word >> 5 & 1,1)
        self.assertEqual(word >> 6 & 1,0)
        self.assertEqual(word >> 26 & 31,7)
        self.assertEqual(word >> 31 & 15,11)
        self.assertEqual(edges,[0x31])
        for sel in ['RS','RD']:
            word,_=asm.encode(f'READ, a={sel}, stream=1, target=$31',0,{})
            self.assertEqual(word >> 5 & 1,1)

    def test_prefetch_policy(self):
        a,edges=asm.encode('CALL, target=$200, prefetch=0',0,{})
        b,other=asm.encode('CALL, target=$200',0,{})
        self.assertEqual(a^b,1<<4)
        self.assertEqual(edges,other)
        image,_,_,stats=asm.assemble((ROOT/'microcode/m0.uasm').read_text())
        self.assertEqual(stats['used_words'],214)
        self.assertEqual(stats['encoding_version'],4)
        self.assertEqual(image[0x118]>>4&1,1) # EA entry suppresses speculation
        self.assertEqual(image[0x288]>>4&1,0) # register destination resumes it

    def test_reverse_operands(self):
        word,_=asm.encode('alu SUB, a=RS, b=RD, pair=BA, dst=RF, flags=NZVC, seq=FETCH',0,{})
        self.assertEqual(word>>18&7,7)
        self.assertEqual(word>>21&31,17)
        self.assertEqual(word>>26&31,16)

    def test_physical_packing_roundtrip(self):
        rng = random.Random(0x1801)
        words = [rng.getrandbits(36) for _ in range(1024)]
        packed = [ebr.lane_initvals(words, lane) for lane in range(4)]
        # Independent address decomposition, including all 9-bit lane boundaries.
        for addr, expected in enumerate(words):
            actual = 0
            for lane in range(4):
                block = packed[lane][addr >> 5]
                slot = (block >> ((addr >> 1 & 15)*20)) & ((1 << 20)-1)
                self.assertEqual(slot >> 18, 0)
                actual |= ((slot >> ((addr & 1)*9)) & 511) << (lane*9)
            self.assertEqual(actual, expected)
        generated = ebr.generate(words)
        self.assertEqual(generated.count('DP8KC #('), 4)
        self.assertEqual(generated.count('.INITVAL_'), 128)
        self.assertIn('.ADA12(address[9])', generated)
        self.assertIn('.ADA0(1\'b1)', generated)
        self.assertIn('.DOA8(data[35])', generated)

    def test_invalid_physical_image(self):
        for words in [[0]*1023, [1 << 36]*1024, [-1]*1024]:
            with self.assertRaises(ValueError):
                ebr.generate(words)


if __name__ == '__main__':
    unittest.main()
