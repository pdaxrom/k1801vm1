/* CP8 oracle: actual DCJ11 core_step with bus callbacks, no copied ISA logic.
 * stdout: variable-length hex records (init patches, final registers, bus trace).
 * Non-completing/trapping cases are counted separately, not called compatible.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "core/core.h"
#include "core/hardware.h"
#if ENABLE_MMU
#error "CP8 is strictly without MMU"
#endif
static byte memory[65536];
static struct {word wr,addr,data;} trace[32];
static unsigned nt,count,skipped;
static unsigned completed_by_op[16],excluded_by_op[16],excluded_reason[4];
static word base_word(word a) {return 0x8000u|((a^(a>>3)^0x3456u)&0x1ffeu);}
static void poke(word a,word v) {memory[a]=(byte)v;memory[(word)(a+1)]=(byte)(v>>8);}
static word peek(word a) {return memory[a]|((word)memory[(word)(a+1)]<<8);}
static void record(word wr,word a,word v) {
    if(nt>=32) {fprintf(stderr,"oracle trace overflow\n");exit(2);}
    trace[nt].wr=wr;trace[nt].addr=a;trace[nt].data=v;nt++;
}
static word load(regs *r,word a) {(void)r;word v=peek(a);record(0,a,v);return v;}
static void save(regs *r,word a,word v) {(void)r;record(1,a,v);poke(a,v);}
static byte loadb(regs *r,word a) {(void)r;(void)a;fprintf(stderr,"unexpected byte load\n");exit(2);}
static void saveb(regs *r,word a,byte v) {(void)r;(void)a;(void)v;fprintf(stderr,"unexpected byte store\n");exit(2);}
static void fixture(word op,word flags,word initial[8],unsigned np,word patches[][2]) {
    regs r;memset(&r,0,sizeof r);r.model=DCJ11;
    if(hwstub_set_memory(memory,sizeof memory)) exit(2);
    hwstub_connect(&r);if(core_init(&r))exit(2);core_reset(&r);
    for(unsigned a=0;a<65536;a+=2)poke((word)a,base_word((word)a));
    for(unsigned p=0;p<np;p++)poke(patches[p][0],patches[p][1]);
    poke(initial[7],op);
    memcpy(r.r,initial,sizeof r.r);r.psw=flags;
    r.ram_fast=NULL;r.load_word=load;r.store_word=save;r.load_byte=loadb;r.store_byte=saveb;
    nt=0;(void)core_step(&r);
    unsigned bad=(!!r.fAbort)|((!!r.fTrap)<<1);
    for(unsigned t=0;t<nt;t++) {
        if(trace[t].addr>=0160000)bad|=4;
        if(trace[t].addr&1)bad|=8;
    }
    if(bad){skipped++;excluded_by_op[op>>12]++;
        for(unsigned reason=0;reason<4;reason++)if(bad&(1u<<reason))excluded_reason[reason]++;
        core_fini(&r);hwstub_clear_memory_binding();return;}
    completed_by_op[op>>12]++;
    printf("%x %04x %04x",count++,op,flags);
    for(unsigned k=0;k<8;k++)printf(" %04x",initial[k]);
    printf(" %x\n%04x %04x\n",np+1,initial[7],op);
    for(unsigned p=0;p<np;p++)printf("%04x %04x\n",patches[p][0],patches[p][1]);
    printf("%04x",r.psw);for(unsigned k=0;k<8;k++)printf(" %04x",r.r[k]);
    printf(" %x\n",nt);
    for(unsigned t=0;t<nt;t++)printf("%x %04x %04x\n",trace[t].wr,trace[t].addr,trace[t].data);
    core_fini(&r);hwstub_clear_memory_binding();
}
int main(void) {
    const word ops[]={0010000,0020000,0060000,0030000,0040000,0050000,0160000};
    const unsigned nops=sizeof ops/sizeof ops[0];
    const word edges[]={0,1,2,0x7ffe,0x7fff,0x8000,0x8001,0xfffe,0xffff};
    word r[8],p[4][2];
    for(unsigned op=0;op<nops;op++)for(unsigned sm=0;sm<8;sm++)for(unsigned dm=0;dm<8;dm++)
    for(unsigned sr=0;sr<8;sr++)for(unsigned dr=0;dr<8;dr++) {
        for(unsigned k=0;k<7;k++)r[k]=(word)(0x2000+k*0x100);
        r[7]=0x1000;
        fixture((word)(ops[op]|(sm<<9)|(sr<<6)|(dm<<3)|dr),(sm+dm+sr+dr)&15,r,0,p);
    }
    // Memory/immediate data edges are independent of pointer values.
    for(unsigned op=0;op<nops;op++)for(unsigned kind=0;kind<3;kind++)
    for(unsigned a=0;a<9;a++)for(unsigned b=0;b<9;b++)for(unsigned carry=0;carry<2;carry++) {
        for(unsigned k=0;k<7;k++)r[k]=(word)(0x2000+k*0x100);
        r[1]=0x4000;r[7]=0x1000;
        p[0][0]=kind==2 ? 0x1002 : 0x2000;p[0][1]=edges[a];
        p[1][0]=0x4000;p[1][1]=edges[b];
        unsigned source=kind==2 ? 027 : 010,destination=kind==1 ? 1 : 011;
        if(kind==1)r[1]=edges[b];
        fixture((word)(ops[op]|(source<<6)|destination),carry,r,2,p);
    }
    // Indexed arithmetic wraps to 16 bits; both signs and PC-relative forms.
    for(unsigned op=0;op<nops;op++)for(unsigned sr=0;sr<8;sr++)for(unsigned disp=0;disp<4;disp++) {
        for(unsigned k=0;k<7;k++)r[k]=disp<2 ? 0xfffc : 4;
        r[6]=0x6000;r[7]=0x1000;
        p[0][0]=0x1002;p[0][1]=disp==0 ? 6 : disp==1 ? 8 : disp==2 ? 0xfffc : 0xfffe;
        fixture((word)(ops[op]|(6<<9)|(sr<<6)|1),disp,r,1,p);
    }
    fprintf(stderr,"EA DCJ11 ENABLE_MMU=0: %u completed cases; %u trapping/I-O cases excluded (Stage 2).\n",count,skipped);
    for(unsigned op=0;op<nops;op++)fprintf(stderr,"  opcode class %02o: %u complete, %u excluded\n",
        ops[op]>>12,completed_by_op[ops[op]>>12],excluded_by_op[ops[op]>>12]);
    fprintf(stderr,"  exclusion reasons (may overlap): abort=%u trap=%u I/O=%u odd=%u\n",
        excluded_reason[0],excluded_reason[1],excluded_reason[2],excluded_reason[3]);
    return 0;
}
