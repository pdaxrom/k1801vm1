`timescale 1ns/1ps
// Seven word double-operand classes use direct bits; mode zero bypasses EA.
module uj11_decode(input wire [15:0] ir,output wire [9:0] entry);
    wire rr = {ir[11:9],ir[5:3]}==6'b0;
    wire supported = (!ir[15] && ir[14:12]!=3'd0 && ir[14:12]!=3'd7) ||
                     ir[15:12]==4'he;
    assign entry = supported ? {2'b01,ir[15:12],!rr,3'b0} :
                   ir[15:8]==8'h01 ? 10'h180 : 10'h3ff;
    wire unused_register_bits = ^{ir[7:6],ir[2:0]};
endmodule
