# Synthesis checkpoints

Target **LCMXO2-1200HC-4SG32C**, Diamond 3.14/Synplify, area strategy,
no retiming, 50 MHz. Budget full integer core ~900–1000 LUT, желательно
<1100. До физического fit цифры EBR capacity не являются resource result.

| Revision | Features | LUT4 | FF | EBR | Fmax MHz | Microcode words | Notes |
|---|---|---:|---:|---:|---:|---:|---|
| cp1-format-v1 / `b7d860d0a264`, 2026-09-08 | synchronous ROM + microseq, four-pin harness | — | — | — | — | 45 | local tests PASS; vendor build blocked before synthesis |

Не заполненные результаты — **unknown**, а не 0. В RTL generator четыре
DP8KC instances, но measured EBR=4 появится только после MAP. FF41 harness
— число объявленных stimulus/observer bits, не measured FF total.

## Доступ к toolchain

На Mac доступны Icarus и Verilator; `diamondc`, Synplify и DP8KC vendor
simulation model не найдены в `/Applications`, `~/.local`, `/opt/homebrew`.
`make synthesis` остановился на проверке наличия Diamond executable.
LUT и Fmax из другого FPGA backend не подменяют HC1200 результаты.

Документированный ранее хост: `sashz-ubuntu`, резервный `192.168.1.108`.
Попытки 2026-09-08:

* `ssh sashz-ubuntu`: hostname не разрешается;
* `ssh sashz-ubuntu.local`: mDNS hostname не разрешается;
* `ssh sash@192.168.1.108`: после разрешённого сетевого доступа timeout.

Это ошибка доступности хоста, не результат синтеза и не отказ инструмента
автоматического согласования. У пользователя запрошен актуальный SSH endpoint.
До его получения RF/datapath/ISA RTL не расширяется за CP1.

## Воспроизводимый запуск

Из каталога `uJ11-fpga` на Linux с Diamond:

```
make test
make vendor-test DIAMOND_HOME=/home/sash/.local/lscc/diamond/3.14
make synthesis DIAMOND_HOME=/home/sash/.local/lscc/diamond/3.14
```

`synth/machxo2/build.tcl` отказывается использовать существующую `impl1`.
Сохранить предыдущую implementation отдельно; для каждого нового решения
использовать свежую копию source или новый output directory. Makefile не
содержит Programmer, не экспортирует/прошивает новый рабочий board image.

Для CP1 топ `uj11_probe_seq`: 40 stimulus FF + 1 registered XOR observation,
clock/reset/serial input/output. Harness удерживает все ROM lanes и
sequencer inputs от pruning; его ресурсы входят в MAP. Это scope, который
нужно указывать при сравнении. Source list содержит generated EBR ROM,
не portable ROM. Проверить `.srr` hierarchy, `.mrp` (LUT/FF/EBR), `.par`
(полная routing), `.twr` (setup/hold, Fmax, critical path и coverage).
Внешние timing paths probe не специфицированы; 50 MHz — internal constraint.

`tools/report_synthesis.py` извлекает numbers и hashes из actual reports,
останавливается при отсутствующих полях, незавершённом PAR, ненулевом
negative slack или EBR count !=4. JSON: `build/cp1-synthesis.json`.
Сохранять также source/ROM hashes и точную tool version из synthesis log.
`make manifest` формирует `build/cp1-inputs.json` со SHA-256 всех CP1 RTL,
microcode/EBR и project inputs. `make synthesis` выполняет это автоматически
до запуска toolchain и включает manifest в итоговый JSON. Локальная
проверенная версия сохранена отдельно в `docs/cp1-inputs.json`.

## Порядок следующих gates

1. CP1 ROM + sequencer — текущий.
2. RF16×16 + Q + ALU; compare RF inference и current PC access.
3. Минимальный datapath, IR/PSW/MDR и stall-safe memory port.
4. Узкий opcode decoder; измерить direct-bit/hybrid mapping.
5. FETCH, word MOV/ADD/CMP R,R, BR; differential и CPI.
6. Instruction-stream prefetch; затем addressing modes, basic ISA, traps,
   interrupts и EIS отдельными resource checkpoints.

До CP5 нельзя утверждать, что RF/ALU/format/dispatch оптимальны для HC1200.
Историческое AM4 direct measurement 902 LUT включает другую обвязку и
полную 56-bit MicROM; его нельзя непосредственно вычитать из CP1.
