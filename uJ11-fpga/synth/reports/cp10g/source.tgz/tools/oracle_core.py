#!/usr/bin/env python3
"""Add read-only address auditing to a build copy of the existing DCJ11 core.

Internal CPU CSRs bypass the public bus callbacks. Record every memory API
address before this dispatch, so out-of-scope I/O fixtures are excluded too.
No ISA, memory value, flags, or control-flow semantics are replaced.
"""
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'../core/core.c').read_text()
pattern=r'(static INLINE (?:byte|word|void) core_(?:load|store)_(?:byte|word)_ex\([^{}]+?\)\n\{)'
addition='\n    extern void uj11_oracle_access(unsigned address);\n    uj11_oracle_access(offset);'
output,count=re.subn(pattern,lambda m:m[0]+addition,source)
if count!=4:raise SystemExit(f'Expected exactly four access entry points, found {count}')
assert output.replace(addition,'')==source
(ROOT/'build/oracle_core.c').write_text(output)
print('Audited DCJ11 build copy: four read-only address hooks; original source unchanged')
