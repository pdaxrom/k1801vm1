#ifndef UJ11_TRACE_ORACLE_H
#define UJ11_TRACE_ORACLE_H
/* Shared oracle: actual DCJ11 core_step with bus callbacks, no copied ISA logic.
 * stdout: variable-length hex records (init patches, final registers, bus trace).
 * Non-completing/trapping cases are counted separately, not called compatible.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "core/core.h"
#include "core/hardware.h"
#if ENABLE_MMU
#error "uJ11 v1 is strictly without MMU"
#endif
static byte memory[65536];
static struct {word wr,addr,data;} trace[32];
static unsigned nt,count,skipped;
static unsigned completed_by_op[16],excluded_by_op[16],excluded_reason[4];
#ifdef ORACLE_ACCESS_AUDIT
static unsigned attempted_io;
void uj11_oracle_access(unsigned address) {if(address>=0160000)attempted_io=1;}
#endif
static word base_word(word a) {return 0x8000u|((a^(a>>3)^0x3456u)&0x1ffeu);}
static void poke(word a,word v) {memory[a]=(byte)v;memory[(word)(a+1)]=(byte)(v>>8);}
static word peek(word a) {return memory[a]|((word)memory[(word)(a+1)]<<8);}
static void record(word wr,word a,word v) {
    if(nt>=32) {fprintf(stderr,"oracle trace overflow\n");exit(2);}
    trace[nt].wr=wr;trace[nt].addr=a;trace[nt].data=v;nt++;
}
static word load(regs *r,word a) {(void)r;word v=peek(a);record(0,a,v);return v;}
static void save(regs *r,word a,word v) {(void)r;record(1,a,v);poke(a,v);}
static byte loadb(regs *r,word a) {(void)r;byte v=memory[a];record(2,a,v);return v;}
static void saveb(regs *r,word a,byte v) {(void)r;record(3,a,v);memory[a]=v;}
static void fixture(word op,word flags,word initial[8],unsigned np,word patches[][2]) {
    regs r;memset(&r,0,sizeof r);r.model=DCJ11;
    if(hwstub_set_memory(memory,sizeof memory)) exit(2);
    hwstub_connect(&r);if(core_init(&r))exit(2);core_reset(&r);
    for(unsigned a=0;a<65536;a+=2)poke((word)a,base_word((word)a));
    for(unsigned p=0;p<np;p++)poke(patches[p][0],patches[p][1]);
    poke(initial[7],op);
    memcpy(r.r,initial,sizeof r.r);r.psw=flags;
    r.ram_fast=NULL;r.load_word=load;r.store_word=save;r.load_byte=loadb;r.store_byte=saveb;
    nt=0;
#ifdef ORACLE_ACCESS_AUDIT
    attempted_io=0;
#endif
    (void)core_step(&r);
    unsigned bad=(!!r.fAbort)|((!!r.fTrap)<<1);
    for(unsigned t=0;t<nt;t++) {
        if(trace[t].addr>=0160000)bad|=4;
        if((trace[t].addr&1) && !(trace[t].wr&2))bad|=8;
    }
#ifdef ORACLE_ACCESS_AUDIT
    if(attempted_io)bad|=4;
#endif
    if(bad){skipped++;excluded_by_op[op>>12]++;
        for(unsigned reason=0;reason<4;reason++)if(bad&(1u<<reason))excluded_reason[reason]++;
        core_fini(&r);hwstub_clear_memory_binding();return;}
    completed_by_op[op>>12]++;
    printf("%x %04x %04x",count++,op,flags);
    for(unsigned k=0;k<8;k++)printf(" %04x",initial[k]);
    printf(" %x\n%04x %04x\n",np+1,initial[7],op);
    for(unsigned p=0;p<np;p++)printf("%04x %04x\n",patches[p][0],patches[p][1]);
    printf("%04x",r.psw);for(unsigned k=0;k<8;k++)printf(" %04x",r.r[k]);
    printf(" %x\n",nt);
    for(unsigned t=0;t<nt;t++)printf("%x %04x %04x\n",trace[t].wr,trace[t].addr,trace[t].data);
    core_fini(&r);hwstub_clear_memory_binding();
}

#endif
