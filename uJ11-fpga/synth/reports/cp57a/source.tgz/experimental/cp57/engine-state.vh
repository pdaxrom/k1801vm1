    // CP57 single frozen context. Cold reset clears readiness, not FRAM.
    reg service_mode;
    reg [1:0] service_ready;
    reg [15:0] service_pc, service_psw;
    wire [2:0] service_space=(reading || writing) ? uword[9:7] : 3'd0;
    wire service_internal=service_space[2];
    wire service_enter=control && command==0 && uword[2:1]==1;
    wire service_leave=control && command==0 && uword[2:1]==2;
    wire [15:0] service_rdata=
        ({16{service_space==4}} & service_pc) |
        ({16{service_space==5}} & service_psw) |
        ({16{service_space==6}} & {8'b0,!service_ready[1],5'b0,service_ready});
    // ACTIVE selects current CPU space. GUEST is logical bank zero;
    // UPPER/LOWER bypass every CPU ROM/CSR overlay for raw physical RAM.
    assign mem_bank=service_space==0 ? service_mode : service_space==2;
    assign mem_physical=service_space==2 || service_space==3;
    always @(posedge clk) begin
        if(reset)begin
            service_mode<=0;
            service_ready<=0;
            service_pc<=0;
            service_psw<=0;
        end else if(step)begin
            if(service_enter)begin
                service_pc<=read_a;
                service_psw<=psw;
                service_mode<=1;
            end
            if(service_leave)service_mode<=0;
            if(writing)case(service_space)
                4: service_pc<=read_b;
                5: service_psw<=read_b;
                6: service_ready<=read_b[1:0];
                default: begin end
            endcase
        end
    end
    // Tables remain synchronous and 9-bit. Privilege/ready qualification is
    // applied only at the tiny set of service entry points, not to every opcode.
    wire [9:0] service_dispatch=
        dispatch_address==S_FP ? (service_mode ? 10'h3ff : service_ready[1] ? S_FP : 10'h042) :
        dispatch_address==S_ODT ? (service_mode ? 10'h3ff : service_ready[0] ? S_ODT : 10'h018) :
        (!service_mode && service_privileged) ? 10'h042 : dispatch_address;
