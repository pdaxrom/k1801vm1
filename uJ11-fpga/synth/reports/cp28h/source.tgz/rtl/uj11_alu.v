// Four shared output paths: carry chain, Boolean truth table, left, right.
// Bit-exact with CP27 for all operands, all 16 operations, carry and width.
`timescale 1ns/1ps
module uj11_alu (
    input wire [15:0] a,b,input wire [3:0] operation,
    input wire carry,byte_mode,output wire [15:0] result,output wire [3:0] nzvc);
    wire subtract=operation[2];
    wire carry_in=(operation[0]&carry)^subtract;
    wire [15:0] arithmetic_b=b^{16{subtract}};
    wire [16:0] sum={1'b0,a}+{1'b0,arithmetic_b}+{16'b0,carry_in};
    wire carry8=sum[8]^a[8]^arithmetic_b[8];
    wire arithmetic=(operation[3:1]==1 || operation[3:1]==2);
    wire left=(operation==11 || operation==14);
    wire right=(operation==12 || operation==13 || operation==15);
    wire logic_op=!arithmetic && !left && !right;
    reg [3:0] truth;
    always @*case(operation)
        0:truth=4'b1100;
        1:truth=4'b1010;
        6:truth=4'b1000;
        7:truth=4'b1110;
        8:truth=4'b0110;
        9:truth=4'b0100;
        10:truth=4'b0011;
        default:truth=0;
    endcase
    wire [15:0] logic_value=(a & ((b&{16{truth[3]}})|(~b&{16{truth[2]}}))) |
                            (~a & ((b&{16{truth[1]}})|(~b&{16{truth[0]}})));
    wire [15:0] left_value={a[14:0],carry && operation==14};
    wire right_sign=(operation==13 && a[15]) || (operation==15 && carry);
    wire right_byte=(operation==13 && a[7]) || (operation==15 && carry);
    wire [15:0] right_value={right_sign,a[15:9],byte_mode?right_byte:a[8],a[7:1]};
    assign result=(sum[15:0]&{16{arithmetic}})|(logic_value&{16{logic_op}})|
                  (left_value&{16{left}})|(right_value&{16{right}});
    wire sa=byte_mode?a[7]:a[15];
    wire sb=byte_mode?arithmetic_b[7]:arithmetic_b[15];
    wire ss=byte_mode?sum[7]:sum[15];
    wire n=byte_mode?result[7]:result[15];
    wire c=(arithmetic && ((byte_mode?carry8:sum[16])^subtract)) ||
           (left && sa) || (right && a[0]) || operation==10;
    wire v=(left||right)?n^c:(arithmetic && !(sa^sb) && (sa^ss));
    assign nzvc={n,(result[7:0]==0 && (byte_mode || result[15:8]==0)),v,c};
endmodule
