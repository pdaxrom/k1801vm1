// uJ11 encoding v10: synchronous microstore next-address sequencer.
// All side effects, including link writes, obey the same enable as the ROM.
`timescale 1ns/1ps
module uj11_microseq (
    input wire clk, reset, enable,
    input wire [35:0] uword,
    input wire [15:0] ir,
    input wire [3:0] nzvc,
    input wire [9:0] dispatch_address,
    input wire address_odd, byte_instruction,
    input wire [3:0] selected_a,
    input wire q0, loop_zero, bus_error, a_one, irq_pending, trace_pending, fault_redirect, fault_repair,
    output reg [9:0] upc,
    output reg [9:0] next_address
);
    localparam [9:0] FETCH = 10'h020, IRQ = 10'h013, STOP = 10'h3ff;
    wire [9:0] fetch_address = trace_pending ? 10'h024 : irq_pending ? IRQ : FETCH;
    reg [9:0] link;
    reg link_valid;
    wire [9:0] sequential = upc + 10'd1;
    wire [3:0] command = uword[34:31];
    wire [9:0] target = uword[20:11];
    wire [7:0] predicates = {bus_error, loop_zero, q0,
                            nzvc[3], nzvc[2], nzvc[1], nzvc[0], 1'b1};
    wire condition = predicates[uword[9:7]] ^ uword[10];
    // These fields belong to datapath/decode; the sequencer deliberately
    // does not interpret them. Keep lint strict for all other signals.
    wire unused_fields = ^{uword[30:21], ir[15:12], ir[8:6], ir[2:0],
                           selected_a[3], selected_a[0]};
    // Select disjoint address sources once. OR-dispatch only modifies bits
    // 2:0 of the common target bus; faults reuse that bus without a wide mux.
    wire control = uword[35];
    wire cmd_jump = command==4'd0 || command==4'd15;
    wire cmd_cond = command==4'd1;
    wire cmd_call = command==4'd10;
    wire cmd_return = command==4'd3;
    wire cmd_dispatch = command==4'd2 || command==4'd4;
    wire cmd_ms = command==4'd5, cmd_md = command==4'd6;
    wire cmd_rr = command==4'd7, cmd_bt = command==4'd8, cmd_r67 = command==4'd9;
    wire cmd_memory = command==4'd11 || command==4'd12;
    wire cmd_stop = command==4'd13, cmd_wait = command==4'd14;
    wire pending = trace_pending || irq_pending;
    wire alu_fetch = uword[9:8]==2'd2 || (uword[9:8]==2'd3 && a_one);
    wire normal = !reset && !fault_redirect && !fault_repair;
    wire to_target = !reset && !fault_repair &&
        ((fault_redirect && uword[2]) || (!fault_redirect && control &&
         (cmd_jump || cmd_memory || cmd_ms || cmd_md || cmd_rr || cmd_bt || cmd_r67 ||
          (cmd_cond && condition) || (cmd_call && !link_valid))));
    wire to_sequential = normal && ((control && cmd_cond && !condition) ||
        (!control && (uword[9:8]==2'd0 || (uword[9:8]==2'd3 && !a_one))));
    wire to_page = normal && !control && uword[9:8]==2'd1;
    wire to_dispatch = normal && control && cmd_dispatch;
    wire to_link = normal && control && cmd_return && link_valid;
    wire to_stop = normal && control && ((cmd_return && !link_valid) || (cmd_call && link_valid));
    wire to_hold = normal && control && (cmd_stop || (cmd_wait && !pending));
    wire to_fetch = normal && ((control && cmd_wait && pending) || (!control && alu_fetch));
    wire to_fault = !reset && (fault_repair || (fault_redirect && !uword[2]));
    wire [2:0] dispatch_bits =
        (ir[11:9] & {3{cmd_ms}}) | (ir[5:3] & {3{cmd_md}}) |
        ({1'b0,ir[5:3]==3'b0,ir[11:9]==3'b0} & {3{cmd_rr}}) |
        ({1'b0,address_odd,byte_instruction} & {3{cmd_bt}}) |
        ({2'b0,~(selected_a[2] & selected_a[1])} & {3{cmd_r67}});
    always @* begin
        next_address = (sequential & {10{to_sequential}}) |
            (target & {10{to_target}}) |
            ({upc[9:8],uword[7:0]} & {10{to_page}}) |
            (dispatch_address & {10{to_dispatch}}) |
            (link & {10{to_link}}) | (STOP & {10{to_stop}}) |
            (upc & {10{to_hold}}) | (fetch_address & {10{to_fetch}}) |
            (10'h015 & {10{to_fault}}) |
            {7'b0,(dispatch_bits & {3{normal && control}})};
    end
    always @(posedge clk) begin
        if (reset) begin
            upc <= 0;
            link <= 0;
            link_valid <= 0;
        end else if (enable) begin
            upc <= next_address;
            if (fault_redirect) link_valid <= 0;
            else if (uword[35] && command == 4'd10 && !link_valid) begin
                link <= sequential;
                link_valid <= 1;
            end else if (uword[35] && command == 4'd3)
                link_valid <= 0;
        end
    end
endmodule
