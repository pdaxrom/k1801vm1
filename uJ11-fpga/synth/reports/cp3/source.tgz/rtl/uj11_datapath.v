`timescale 1ns/1ps
// Shared Am2901-like operand pair, RF writeback and Q. No opcode decode.
module uj11_datapath (
    input wire clk, reset, enable,
    input wire [3:0] a, b, operation,
    input wire [2:0] pair, destination,
    input wire [15:0] d,
    input wire carry,
    output wire [15:0] read_a, read_b, result,
    output reg [15:0] q,
    output wire [3:0] nzvc,
    output wire rf_write,
    output wire [15:0] writeback
);
    reg [15:0] lhs, rhs;
    always @* begin
        case (pair)
            3'd0: begin lhs=read_a; rhs=read_b; end
            3'd1: begin lhs=read_a; rhs=q; end
            3'd2: begin lhs=read_a; rhs=d; end
            3'd3: begin lhs=d; rhs=read_b; end
            3'd4: begin lhs=0; rhs=read_b; end
            3'd5: begin lhs=0; rhs=q; end
            3'd6: begin lhs=d; rhs=read_a; end
            3'd7: begin lhs=d; rhs=0; end
        endcase
    end
    uj11_alu alu(.a(lhs),.b(rhs),.operation(operation),.carry(carry),
                 .result(result),.nzvc(nzvc));
    assign writeback = destination==3'd3 ? {result[14:0],q[15]} :
                      destination==3'd4 ? {result[15],result[15:1]} : result;
    assign rf_write = enable && !reset &&
                      (destination==3'd1 || destination==3'd3 || destination==3'd4);
    uj11_regfile rf(.clk(clk),.write_enable(rf_write),.a(a),.b(b),
                    .write_data(writeback),.read_a(read_a),.read_b(read_b));
    always @(posedge clk) begin
        if (reset) q <= 0;
        else if (enable) begin
            case (destination)
                3'd2: q <= result;
                3'd3: q <= {q[14:0],1'b0};
                3'd4: q <= {result[0],q[15:1]};
                default: q <= q;
            endcase
        end
    end
endmodule
