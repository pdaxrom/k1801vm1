// uJ11 encoding v10: synchronous microstore next-address sequencer.
// All side effects, including link writes, obey the same enable as the ROM.
`timescale 1ns/1ps
module uj11_microseq (
    input wire clk, reset, enable,
    input wire [35:0] uword,
    input wire [15:0] ir,
    input wire [3:0] nzvc,
    input wire [9:0] dispatch_address,
    input wire address_odd, byte_instruction,
    input wire [3:0] selected_a,
    input wire q0, loop_zero, bus_error, a_one, irq_pending, trace_pending, fault_redirect, fault_repair,
    output reg [9:0] upc,
    output reg [9:0] next_address
);
    localparam [9:0] FETCH = 10'h020, IRQ = 10'h013, STOP = 10'h3ff;
    wire [9:0] fetch_address = trace_pending ? 10'h024 : irq_pending ? IRQ : FETCH;
    reg [9:0] link;
    reg link_valid;
    wire [9:0] sequential = upc + 10'd1;
    wire [3:0] command = uword[34:31];
    wire [9:0] target = uword[20:11];
    wire [7:0] predicates = {bus_error, loop_zero, q0,
                            nzvc[3], nzvc[2], nzvc[1], nzvc[0], 1'b1};
    wire condition = predicates[uword[9:7]] ^ uword[10];
    // These fields belong to datapath/decode; the sequencer deliberately
    // does not interpret them. Keep lint strict for all other signals.
    wire unused_fields = ^{uword[30:21], ir[15:12], ir[8:6], ir[2:0],
                           selected_a[3], selected_a[0]};
    // All OR-dispatches share the same target. Only its low three bits
    // vary; other control operations override this common address below.
    wire [2:0] dispatch_bits =
        (ir[11:9] & {3{command==4'd5}}) |
        (ir[5:3] & {3{command==4'd6}}) |
        ({1'b0,ir[5:3]==3'b0,ir[11:9]==3'b0} & {3{command==4'd7}}) |
        ({1'b0,address_odd,byte_instruction} & {3{command==4'd8}}) |
        ({2'b0,~(selected_a[2] & selected_a[1])} & {3{command==4'd9}});
    // Shared address mux: target, sequential, link, dispatch, hold, fetch,
    // page-local jump, or invalid-call/return STOP.
    reg [7:0] select_address;
    always @* begin
        select_address=8'h01;
        if(uword[35])begin
            case(command)
                1:if(!condition)select_address=8'h02;
                10:if(link_valid)select_address=8'h80;
                3:select_address=link_valid?8'h04:8'h80;
                4,2:select_address=8'h08;
                13:select_address=8'h10;
                14:select_address=(trace_pending||irq_pending)?8'h20:8'h10;
                default:begin end
            endcase
        end else case(uword[9:8])
            0:select_address=8'h02;
            1:select_address=8'h40;
            2:select_address=8'h20;
            3:select_address=a_one?8'h20:8'h02;
        endcase
    end
    wire normal=!reset && !fault_redirect && !fault_repair;
    wire choose_target=!reset && !fault_repair &&
                       (fault_redirect ? uword[2] : select_address[0]);
    wire choose_fault=!reset && (fault_repair || (fault_redirect && !uword[2]));
    always @* begin
        next_address=({target[9:3],target[2:0] | (dispatch_bits & {3{!fault_redirect}})} & {10{choose_target}}) |
            (sequential & {10{normal && select_address[1]}}) |
            (link & {10{normal && select_address[2]}}) |
            (dispatch_address & {10{normal && select_address[3]}}) |
            (upc & {10{normal && select_address[4]}}) |
            (fetch_address & {10{normal && select_address[5]}}) |
            ({upc[9:8],uword[7:0]} & {10{normal && select_address[6]}}) |
            (STOP & {10{normal && select_address[7]}}) |
            (10'h015 & {10{choose_fault}});
    end
    always @(posedge clk) begin
        if (reset) begin
            upc <= 0;
            link <= 0;
            link_valid <= 0;
        end else if (enable) begin
            upc <= next_address;
            if (fault_redirect) link_valid <= 0;
            else if (uword[35] && command == 4'd10 && !link_valid) begin
                link <= sequential;
                link_valid <= 1;
            end else if (uword[35] && command == 4'd3)
                link_valid <= 0;
        end
    end
endmodule
