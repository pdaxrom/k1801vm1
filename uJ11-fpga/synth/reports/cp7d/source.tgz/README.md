# uJ11 FPGA

Специализированный микрокодный PDP-11/J-11 integer engine для
**Lattice LCMXO2-1200HC**, строго **без MMU**, адрес 16 bits.

**Первый milestone M0 выполнен:** FETCH, word MOV/ADD/CMP R,R и BR,
16×16 dual-read RF, Q, ALU16, IR/PSW/MDR, synchronous 1024×36 microstore,
маленький microsequencer и независимый от Wishbone memory port.
Это ограниченный ISA subset, а не полный J-11.

**CP6: подключена SPI FRAM как в HC1200, последовательный READ и однословный
instruction-stream prefetch.** Финальный `cp6c-final`: **843 LUT4, 392 FF,
4 EBR**, **29,56 MHz PASS**, TRACE Fmax **30,292 MHz**. Это M0 + FRAM transport
и измерительная обвязка, без полного набора периферии платы.
На MOV/ADD/CMP loops модель FRAM дала **39,078125 такта/инструкцию** вместо
107 с прежним контроллером: расчётно **756 тыс. инструкций/с** при номинальных
29,56 MHz CPU / 14,78 MHz SPI. На плате скорость ещё не измерена.
`BR` на себя остаётся на 107 тактах. [FRAM и периферия](docs/fram-peripherals.md).

Отдельный core-only checkpoint `cp5v3-40`: **582 LUT4, 277 FF, 4 EBR**, полный
MAP/PAR/TRACE на **LCMXO2-1200HC-4SG32C**, **40 MHz PASS**, TRACE Fmax
**41.195 MHz**. Цель 50 MHz пока не достигнута. В ресурсы входит четырёхпиновая
измерительная обвязка; это не bare-core count и не pinout рабочей платы.
Микрокод: **23/1024 words**. Без ожидания памяти: **2 microclocks/instruction**,
**1 memory cycle/instruction**. Расчётная производительность при 40 MHz и
такой памяти — **20 млн инструкций/с**; на плате она ещё не измерена.

```
make test       # assembler, RTL, all opcode decode, 6272 DCJ11 differential cases, lint
make benchmark  # 15 workloads/latencies; build/benchmarks.json
make benchmark-fram  # same M0 loops: legacy / sequential / prefetch SPI FRAM
make all        # CP1 diagnostic + M0 ROM, listing, labels, stats, DP8KC lanes
```

Нужны Python 3, Icarus Verilog, Verilator и C compiler. Differential oracle
собирается из существующего `../core/` с `ENABLE_MMU=0`; поэтому этот тест
рассчитан на расположение проекта внутри исходного репозитория k1801vm1.
ROM backend находится в `microasm/uj11asm.py`: знакомые labels/`.org`/`$hex`,
но собственный semi-horizontal encoding **v3**, несовместимый с native
16-bit microcpu opcodes. ROM вручную не редактируется.

На Linux с Diamond 3.14:

```
make vendor-test vendor-engine vendor-memory-engine vendor-core
make vendor-benchmark
make vendor-fram vendor-fram-benchmark
make synthesis-fram            # CPU + FRAM/prefetch, nominal board clock 29.56 MHz
make synthesis                 # M0, 40 MHz, fresh build/cp5 required
# В отдельной свежей копии для сравнения:
make synthesis SYNTH_MHZ=50     # текущий M0 не проходит 50 MHz
```

Путь по умолчанию: `$HOME/.local/lscc/diamond/3.14`; переопределяется
`DIAMOND_HOME`. Проверенный хост: `sash@192.168.1.108`, Diamond 3.14.0.75.2.
Скрипт запускает synthesis/translate/MAP/PAR/TRACE и проверяет завершение,
EBR count, фактический clock constraint и setup/hold. FPGA не программируется.
`make synthesis-seq` оставлен для отдельного CP1 probe; historical CP1 v1
воспроизводится из его source archive, а не из изменившегося текущего RTL.

Следующий checkpoint — микрокодные addressing modes и расширение ISA с
повторным измерением HC1200. Byte ISA, traps/interrupts,
EIS и J-11 register banking пока не реализованы. MMU отсутствует полностью;
ни RTL-заготовок, ни memory-management stages, ни резервирования EBR под него нет.

* [Предыдущие эксперименты с конкретными цифрами](docs/previous_experiments.md)
* [Архитектура](docs/architecture.md) и [микроархитектура](docs/microarchitecture.md)
* [36-bit format v3](docs/microcode-format.md)
* [Реализовано и проверено](docs/implementation-status.md)
* [Все synthesis checkpoints и выводы](docs/synthesis.md)
* [Benchmarks и сравнение](docs/benchmarks.md)
