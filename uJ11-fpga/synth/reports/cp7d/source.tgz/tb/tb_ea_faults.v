`timescale 1ns/1ps
module tb_ea_faults;
    reg clk=0,reset=1,inject_error=0;
    reg [15:0] opcode=0,source_value=0,destination_value=0,csr=0;
    wire [15:0] addr,wdata,ir,mdr,psw,q,rf_data;
    wire request,reading,writing,byte_access,stopped,retire,rf_write;
    wire [1:0] fault;wire [3:0] rf_address;wire [9:0] upc;wire [35:0] uword;
    wire ack=request;
    wire error=inject_error && writing && addr==16'h4000;
    wire io_page=&addr[15:13];
    wire [15:0] rdata=addr==0 ? opcode : addr==16'h2000 ? source_value :
                     addr==16'h4000 ? destination_value : io_page ? csr : 16'b0;
    integer c,cycles,reads=0,writes=0,io_reads=0,io_writes=0,attempts=0;
    reg [15:0] last_write;
    uj11_core dut(.clk(clk),.reset(reset),.mem_addr(addr),.mem_write_data(wdata),.mem_request(request),
        .mem_read(reading),.mem_write(writing),.mem_byte(byte_access),.mem_ack(ack),.mem_error(error),
        .mem_read_data(rdata),.stopped(stopped),.fault_code(fault),.retire(retire),.debug_upc(upc),
        .debug_uword(uword),.ir(ir),.mdr(mdr),.psw(psw),.q(q),.debug_rf_write(rf_write),
        .debug_rf_address(rf_address),.debug_rf_data(rf_data));
`ifdef VENDOR_ROM
    GSR GSR_INST(.GSR(1'b1));PUR PUR_INST(.PUR(1'b1));
`endif
    always #5 clk=~clk;
    always @(posedge clk)begin
        if(reset)begin reads=0;writes=0;io_reads=0;io_writes=0;attempts=0;last_write=0;end
        else if(request && ack)begin
            attempts=attempts+1;
            if(addr[0] || byte_access)$fatal(1,"odd/byte word escaped core");
            if(!error)begin
                if(writing)begin
                    writes=writes+1;last_write=wdata;
                    if(io_page)io_writes=io_writes+1;
                    if(addr==16'h4000)destination_value<=wdata;
                end else begin reads=reads+1;if(io_page)io_reads=io_reads+1;end
            end
        end
    end
    task tick;begin @(posedge clk);#1;end endtask
    initial begin
        #100;
        for(c=0;c<7;c=c+1)begin
            @(negedge clk);reset=1;tick;@(negedge clk);reset=0;repeat(17)tick;
            @(negedge clk);
            dut.engine.dp.rf.words[0]=16'ha5a5;dut.engine.dp.rf.words[1]=16'o177562;
            dut.engine.status.psw=3;inject_error=0;source_value=0;destination_value=1;csr=16'h2222;
            case(c)
                0:opcode=16'o010011; // MOV R0,(R1): no destination read
                1:begin opcode=16'o020011;dut.engine.dp.rf.words[0]=16'h1111;end
                2:begin opcode=16'o060011;dut.engine.dp.rf.words[0]=16'h7fff;csr=1;end
                3:begin opcode=16'o011001;dut.engine.dp.rf.words[0]=16'h2001;end
                4:begin opcode=16'o013001;dut.engine.dp.rf.words[0]=16'h2000;source_value=16'h4001;end
                5,6:begin opcode=c==5?16'o010011:16'o060011;
                    dut.engine.dp.rf.words[0]=16'h7fff;dut.engine.dp.rf.words[1]=16'h4000;inject_error=1;end
            endcase
            cycles=0;while(!retire && !stopped && cycles<100)begin tick;cycles=cycles+1;end
            if(c<3)begin
                if(!retire || stopped || io_reads!=(c==0?0:1) || io_writes!=(c==1?0:1))
                    $fatal(1,"EA I/O side effects case%0d",c);
                if(c==0 && (last_write!==16'ha5a5 || psw!==9))$fatal(1,"MOV I/O result");
                if(c==1 && psw!==9)$fatal(1,"CMP I/O flags");
                if(c==2 && (last_write!==16'h8000 || psw!==10))$fatal(1,"ADD I/O result");
            end else begin
                if(!stopped || retire || fault!==(c<5?2'd1:2'd2) || psw!==3 || writes!=0)
                    $fatal(1,"EA fault commit case%0d psw%h fault%h",c,psw,fault);
                if(c==3 && attempts!=1)$fatal(1,"odd source bus activity");
                if(c==4 && (attempts!=2 || dut.engine.dp.rf.words[0]!==16'h2002))$fatal(1,"odd deferred source");
                if(c>=5 && destination_value!==1)$fatal(1,"failed store committed");
                cycles=attempts;repeat(4)tick;if(attempts!=cycles)$fatal(1,"fault did not stop");
            end
        end
        $display("PASS EA directed: MOV/CMP/ADD demand I/O, odd source/pointer, store errors preserve flags and memory");
        $finish;
    end
endmodule
