# Implementation status, 2026-09-08

**Малый milestone M0 выполнен: работающий ISA subset, differential tests,
benchmarks и полный HC1200 synthesis baseline. Исходная цель 50 MHz открыта;
финальный constraint 40 MHz проходит. Полный PDP-11/J-11 ещё не реализован.**

**CP6 также выполнен:** SPI FRAM + sequential READ + однословный prefetch,
843 LUT4 / 392 FF / 4 EBR, nominal board clock 29,56 MHz PASS, Fmax 30,292 MHz.
Scope: M0 + transport + probe; UART/таймер/панель/SD/RK пока не входят в top.
RR loop: 39,078125 clocks/instruction, расчётно 756,433 instr/s при 29,56 MHz.
Это simulation + synthesis, не запуск платы. [Протокол и карта I/O](fram-peripherals.md).

| Требование M0 | Состояние |
|---|---|
| Анализ microcpu/microasm/AM4/emulator/tests | выполнен до RTL; 22 historical raw MAP reports индексированы |
| previous_experiments.md с конкретными цифрами | выполнен; paths и SHA-256 в previous_reports.json |
| Microarchitecture и 36-bit format | реализованы, текущий encoding v3; v1/v2 сохранены с отчётами |
| Microsequencer | NEXT/PAGE/JUMP/CJUMP/CALL/RETURN, dispatch и OR_MS/MD/RR/BT/R67 |
| Microstore | 1024×36, четыре vendor DP8KC, ROM/listing/labels/stats из assembler |
| RF/Q/ALU/IR/PSW/MDR | RF16×16 dual-read/one-write, Q16, ALU16, IR16, PSW16, MDR16 |
| Memory | 16-bit addr, request/read/write/byte/data, ACK/error, stalls и odd-word protection |
| ISA | FETCH; word MOV/ADD/CMP только mode0; BR, включая PC wrap/PC operands |
| Microcode usage | 23/1024 words, 2.24609375%; 17 reset/control + FETCH + 4 execution + STOP |
| Differential tests | 6272 существующих DCJ11 reference cases, ENABLE_MMU=0 |
| HC1200 MAP/PAR/TRACE | 582 LUT4 / 277 FF / 4 EBR; 40 MHz PASS; Fmax 41.195 MHz |
| Performance | 2+N microclocks/instruction при N wait clocks, 1 memory cycle/instruction |
| Prefetch | CP6: одно слово FRAM instruction stream, tag, redirects/SMC, demand-only I/O |
| EA modes 1..7 / byte ISA | не реализованы; следующие checkpoints |
| Traps/interrupts/PSW ISA/HALT/WAIT/RTI | не реализованы; diagnostic STOP не заменяет trap handling |
| EIS / loop counter / J-11 banking | не реализованы; Q/one-bit shifts есть как primitives |
| MMU | полностью отсутствует, без stubs, tables, extended addresses и резервов EBR |

## Проверки финального RTL/encoding

* 7 Python test methods: encoding, conflicts, aligned control fields,
  FETCH ALU context, 1024 random 36-bit words physical packing/roundtrip.
* 4323 sequencer checks: predicates/inversion, все mode fields/OR dispatches,
  1024 external dispatch addresses, NEXT/PAGE/wrap, CALL/RETURN stalls и faults.
* 1024 ROM reads и 1024 holds; 17 ROM feedback transitions со stalls.
* 66592 независимых ALU result/NZVC checks; RF16 и 256 dual-read combinations,
  writeback, Q load/combined shifts, stalls/reset.
* PSW masks/load; word/byte RAM lanes, back-to-back requests, wait-state stability;
  READ/WRITE/MDR microprogram с 0..7 wait clocks и точными transaction counts.
* Engine reset, fetch stalls, one-cycle ADD, odd-address/bus-error/unsupported stop.
* Все 65536 opcode: ровно 448 принимаются (192 RR encodings + 256 BR offsets).
* 6272 differential cases: all 64 Rs/Rd combinations, edge operands и C,
  2048 random cases, все 256 BR offsets у трёх PC bases; сравниваются R0..R7,
  PSW, memory writes/transactions, отсутствие abort/trap у поддержанного subset.
  Задержки 0..3 clocks, всего 21952 execution/fetch clocks без reset.
* Отдельно: FETCH с 0xfffe и wrap PC, запрет MOV memory mode/MOVB/HALT.
* 15 benchmark runs по 4096 измеренных instructions, warmup исключён,
  zero/two/random wait clocks; counts portable и vendor ROM идентичны.
* Verilator --Wall без предупреждений. Vendor DP8KC functional simulations
  пройдены для control store, engine, memory microprogram, differential и benchmarks.

Логи: [tests](../tb/reports/m0-tests.log), [benchmarks](../tb/reports/m0-benchmarks.log).
Exact verified input hashes: [verification-m0.json](verification-m0.json).
Это functional simulation и vendor timing analysis; physical board execution
и внешние memory I/O timing ещё не проверены. Полная J-11 совместимость,
архитектурные traps и byte semantics этим ограниченным тестом не заявляются.

## Следующий gate

Оценка M0 закончена: RF и четыре EBR подходят; формат должен оставаться
semi-horizontal; control mux необходимо оценивать по critical path.
Timing/prefetch tradeoff измерен в CP6; далее отдельно
EA modes, basic ISA, traps/interrupts и EIS. Цель полного core ~900–1000 LUT
остаётся целью: текущие 582 LUT относятся только к M0 и его probe.

## Проверки CP6

`make test` включает прежний набор и новые тесты; assembler теперь имеет
8 test methods, включая stream READ encoding и конфликты byte/register.
Каждая из двух моделей ROM прошла 6272 DCJ11 cases через SPI FRAM
(671,104 CPU clocks), а также opcode + 3 extension words через один READ.
Transport test: 499 beats, randomized stream/data interleaving, удержание
буфера без SPI clocks, все позиции прерывания speculative word, PC redirects,
SMC, byte/word writes, odd errors, I/O boundary, STOP/reset и private-bank guard.
В integration test подключены замороженные исходники настоящих периферий
`lsi11-fpga`: 19 beats с RXBUF side effect, UART high-byte writes, KW11,
панелью и SD DATA, плюс отсутствие ACK/FRAM alias у неизвестного CSR.
Это тест внешнего I/O adapter, не перенос полного AM4 bus в uJ11 RTL.

15 FRAM benchmark runs × 512 instructions в каждой ROM-модели дали одинаковые
counts. Verilator --Wall проверяет оба новых synthesis tops без предупреждений.
Хеши исходников/логов: [verification-cp6.json](verification-cp6.json).
Детали чисел и неудачного timing варианта сохранены в synthesis/benchmarks docs.
