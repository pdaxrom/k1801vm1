# Микроархитектура M0

## Синхронный microstore без лишнего такта

`uj11_microseq` содержит uPC10, link10 и link_valid. На каждом разрешённом
фронте одновременно выполняются uPC←next_address и uword←ROM[next_address].
Поэтому uPC всегда соответствует текущему uword. ROM enable и все side
effects datapath используют один `step`; ожидание ACK сохраняет это соответствие.
Reset принудительно читает address 0 и запрещает datapath writes.

```
current uword ──► next-address logic ──► ROM address
      ▲                                 │
      └───────── next clock ─────────────┘
```

NEXT — 10-bit increment; PAGE — high2 от uPC плюс low8 из microinstruction;
JUMP/CALL — полный target. OR-dispatch использует IR bits непосредственно.
CALL имеет одну return slot; overflow/underflow ведут в diagnostic STOP.
CJUMP читает старые PSW/Q/condition inputs, возможна инверсия условия.
Loop counter в M0 отсутствует, его predicate привязан к 0.

Microstore: четыре явных DP8KC 1024×9. INITVAL содержит пары 9-bit words
в 20-bit slots; bits18/19 каждого slot нулевые. ADA12..3=address9..0,
ADA2..0=001, REGMODE=NOREG. NOREG здесь не означает asynchronous ROM:
чтение происходит по фронту CLKA. Portable model и vendor model проверены.

## Один execution cycle

RF16×16: два asynchronous reads, synchronous write по адресу B.
В MAP/Synplify он реализован четырьмя DPR16X4C и четырьмя SPR16X4C,
без EBR и без 256 FF. Reset microcode очищает 16 слов через обычный write port.
Далее JUMP на FETCH: всего 17 initialization microclocks после снятия reset.
PC хранится только в R7; mirror и третий RF port не нужны в M0.

A/B fields имеют одинаковое расположение в ALU и control words. Literal
selectors 0..15 выбирают R0..R7/T0..T7; RS/RD и RS1/RD1 используют IR.
В v3 FETCH имеет command=2, совпадающий с ALU ADD, и кодирует AD/RF/TWO
в обычных datapath fields. Поэтому отдельные override mux для operation,
pair и D-input устранены. READ/WRITE и другие control words не разрешают
RF/Q/PSW writeback, несмотря на произвольные overlapping ALU fields.

Operand selection — параллельные masked buses. Один общий 17-bit carry
chain обслуживает ADD/ADC/SUB/SBC. Carry для SUB — borrow. Нет multiplier,
divider или barrel shifter. Q16 поддерживает load и связанные RF/Q shifts.
PSW16 обновляется KEEP/NZV/NZVC/LOAD; FLAGS берутся до RFQ writeback shift.

При FETCH completion IR и MDR получают входящий opcode, ALU записывает
R7+2. `dispatch_ir` в этот момент равен входящему memory word. Decoder
выбирает execution entry прямо на том же фронте ROM; decode bubble нет.
MOV/ADD/CMP R,R и BR заканчиваются одной ALU microinstruction с seq=FETCH.
Запись R7 этим же datapath перенаправляет следующий FETCH.

Измеренный цикл при zero-wait RAM:

```
FETCH: request/ack + R7+=2 + IR/MDR + ROM dispatch
EXEC:  dual RF read + ALU + RF/PSW commit + retire + ROM[FETCH]
```

Получены 2 clocks/instruction, включая BR и PC operands. Это не prefetch:
следующий memory request появляется в следующей FETCH-микрокоманде.

## Memory и diagnostic stop

`uj11_mem` не содержит address registers или translation. Текущие uword/RF
удерживают address и data до ACK. Один request&&ack на фронте — один beat;
back-to-back beats допустимы. Byte transaction использует точный addr и
right-justified payload; primitive проверен, byte ISA пока отсутствует.

Word по нечётному адресу подавляет request и устанавливает fault_code=1.
ACK+error устанавливает code=2 и запрещает PC/IR/MDR/PSW/Q/RF side effects.
Неподдержанный opcode выбирает STOP, code=3; его FETCH уже увеличил PC на 2,
но execution effects нет. STOP не является PDP-11 HALT или архитектурным trap.
Reset очищает fault. `retire` — registered pulse после execution commit.

IR16, MDR16, PSW16, Q16, sequencer21, fault2 и retire1 дают 88 state bits.
В финальном probe дополнительно 18 input и 171 observation FF: всего 277 FF,
совпадающих с MAP. LUT count указан только для полного измеренного probe.
Выходы debug показывают RF write port и state; дополнительного RF read port нет.

## Что измерения говорят о конструкции

Формат/ROM занимают ровно четыре EBR. RF обеспечивает нужные два чтения и
одну запись за execution cycle. Decoder не является critical path.
Control-field mux были дорогими: выравнивание selectors и ALU-поля FETCH
дали измеренное уменьшение LUT и рост Fmax. Оптимальность всего datapath
не доказана: сохраняется путь EBR → RF selector/read → ALU → RF/PSW.
Подробные timings, сохранённые неудачные варианты и следующий gate —
[synthesis.md](synthesis.md). Усложнений ради будущего MMU нет.

## CP6: FRAM stream

Core M0 не менялся; `uj11_fram_system` добавляет внешний memory unit.
MEMORY_MODE=0 — замороженный legacy `lsi11-fpga` контроллер, 1 — retained
sequential READ, 2 — тот же транспорт с однословным prefetch (по умолчанию).
FPGA адрес 16-bit; SPI header имеет high byte=0. I/O page выделяется до FRAM.

`uj11_fram_transport` получен из существующего небольшого byte FSM с тремя
дополнительными входами keep/resume/close. READ сохраняет CS после word,
resume начинает следующие два data bytes без повторных command/address.
Writes используют обычные WREN+WRITE и завершают CS. Закрытие обычного
pending read происходит только после полного слова; reset отдельно отменяет
текущую передачу. Внешняя FRAM не имеет ACK/CRC: отсутствие микросхемы этим
протоколом не диагностируется. Core bus_error остаётся отдельным контрактом.

`uj11_prefetch` хранит 15-bit aligned tag следующего слова, prediction-valid,
owner (idle/demand/speculative), PF_VALID и сохранённую ошибку. Слово PF_DATA
использует rdata16 транспорта. Пока буфер полон, следующий SPI transfer
запрещён. Matching demand может получить ACK непосредственно на готовом
speculative response или из parked buffer. Нет сдвига IR/PC при speculative
чтении. READ stream qualifier позволяет брать extension в MDR.

При PC write совпадающий tag сохраняется, остальные predictions сбрасываются.
Сравнение ALU result с tag управляет только registered validity. На любом
PC-write edge новый prefetch не стартует; SPI close видит сброс validity
следующим тактом. Это убрало failed 35.176 ns / 25-level ALU→compare→CS path.
Data read/write и весь I/O page сбрасывают prediction, SMC не оставляет
устаревшее слово. Завершённое отменённое чтение не даёт архитектурного ACK.

Final CP6: 843 LUT4, 392 FF, 4 EBR; 19 stimulus + 176 observation FF входят
в probe. Отдельного bare-core+FRAM fitted LUT result нет. Периферия проверена
в testbench с настоящим legacy RTL, но не включена в этот synthesis top.
