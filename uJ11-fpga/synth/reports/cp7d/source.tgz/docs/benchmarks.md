# Benchmarks M0 и SPI FRAM

## CP6: память существующей платы

MR45V100A, CPU **29,56 MHz nominal**, `CLK_DIV=1`, SPI **14,78 MHz**.
Это расчёт throughput из RTL counts; FPGA не программировалась.
Все конфигурации исполняют один M0 microcode image (23 слова).

| Workload | Legacy CPI | Sequential READ CPI | Sequential + prefetch CPI | Memory beats/instruction | Prefetch instr/s at 29.56 MHz |
|---|---:|---:|---:|---:|---:|
| MOV_RR_loop | 107 | 40.0625 | 39.078125 | 1 | 756,433 |
| ADD_RR_loop | 107 | 40.0625 | 39.078125 | 1 | 756,433 |
| CMP_RR_loop | 107 | 40.0625 | 39.078125 | 1 | 756,433 |
| mixed_RR_loop | 107 | 40.0625 | 39.078125 | 1 | 756,433 |
| BR_self | 107 | 107 | 107 | 1 | 276,262 |

Каждый run: 64 warmup, затем 512 retirements. RR loops включают BR назад
после 63 RR words. Legacy: 54,784 CPU clocks, 512 CS transactions, 24,576
SCK rises. Sequential: 20,512 / 8 / 8,448. Prefetch: 20,008 / 8 / 8,448.
Cold fetch остаётся 107 clocks; следующий RR instruction без заголовка
стоит 39 clocks в sequential mode и 38 с prefetch. В BR_self заголовок
нужен каждый раз; спекуляция блокируется на фронте записи PC.

Основной выигрыш **2,738×** относительно прежнего контроллера даёт сохранение
SPI READ. Дополнительный prefetch ускоряет этот loop на **2,52%** относительно
sequential-only (737,847 → 756,433 instr/s). В финальном одинаковом RTL это
стоит **42 LUT4 + 2 FF**, без EBR. Буфер оставлен переключаемым параметром
`MEMORY_MODE` для следующих EA/EIS measurements, где есть больше ALU работы
между словами. Глубокий cache на этом этапе не добавлен.

Проверка stream microprogram: opcode + immediate/displacement/absolute test
words, один READ, 226 CPU clocks до STOP; 112 SPI clocks после drain включают
ещё одно отброшенное speculative слово. Это проверка transport semantics,
не реализация addressing-mode ISA. В unit test уже заполненный PF даёт ACK
на первом demand edge и не читает дальше, пока слово не потреблено.

Portable и vendor DP8KC ROM дали идентичные counts. Источник всех чисел:
[benchmarks-fram.json](benchmarks-fram.json), логи
[portable](../tb/reports/cp6-benchmarks-portable.log) и
[vendor](../tb/reports/cp6-benchmarks-vendor.log).
Воспроизведение: `make benchmark-fram`, `make vendor-fram-benchmark`.
Final synthesis scopes: sequential 801 LUT4/390 FF/4 EBR, Fmax 31.219 MHz;
prefetch 843/392/4, 30.292 MHz; оба проходят 29.56 MHz.
Полная периферия, boot и RK сюда не включены. Сопоставимого AM4 RR-on-FRAM
benchmark пока нет; ускорение относительно AM4 не заявляется.

## Исторический M0: идеальная RAM

Измеряется один и тот же final encoding v3 core: **582 LUT4 / 277 FF / 4 EBR**
с synthesis probe, **40 MHz constraint PASS**, TRACE Fmax **41.195 MHz**.
Источник counts — RTL functional simulation; portable synchronous ROM и
Diamond DP8KC дали идентичный JSON. Частота из TRACE не подменяет board test.

## Циклы и пропускная способность

| Workload | Zero-wait microclocks / instruction | Two-wait microclocks / instruction | Random 0..3 waits microclocks / instruction | Memory cycles / instruction | Zero-wait instr/s at 40 MHz |
|---|---:|---:|---:|---:|---:|
| MOV_RR_loop | 2.0000 | 4.0000 | 3.5237 | 1.0000 | 20,000,000 |
| ADD_RR_loop | 2.0000 | 4.0000 | 3.5029 | 1.0000 | 20,000,000 |
| CMP_RR_loop | 2.0000 | 4.0000 | 3.5283 | 1.0000 | 20,000,000 |
| mixed_RR_loop | 2.0000 | 4.0000 | 3.5083 | 1.0000 | 20,000,000 |
| BR_self | 2.0000 | 4.0000 | 3.5093 | 1.0000 | 20,000,000 |

20 млн instr/s — расчёт **40 MHz / measured CPI 2** при zero-wait memory,
а не измерение на плате. При двух wait clocks — 10 млн instr/s. Нет prefetch;
два такта получены FETCH+decode на одном фронте и одной ALU execution word.
При N wait clocks получается 2+N microclocks/instruction.

Каждая строка измеряет 4096 instructions после 64 warmup retirements.
MOV/ADD/CMP loops содержат 63 указанные RR instructions и BR назад —
64 слова на итерацию. Mixed loop повторяет MOV R1,R2; ADD R3,R2;
CMP R1,R2; ADD R4,R1, последняя позиция заменена BR. BR_self — BR на себя.
Начальные R0..R6=0..6, R7=0, PSW=0. Reset/initialization не входят в counts.
Это небольшие synthetic loops; реальную программу для полной ISA M0 ещё
не исполняет. Число register ALU cycles отдельно подтверждено ISA tests.

Zero-wait: **8192 clocks / 4096 instructions / 4096 bus transactions**.
Two-wait: **16384 / 4096 / 4096**. В random режиме LCG seed 0x00111801,
wait states выбираются из bits25:24 после retirement и сохраняются до ACK.
`wait_mode=0` в JSON означает 0 waits, `1` — 2 waits, `2` — random 0..3;
это номера сценариев, а не буквальное количество wait states.
Все 15 runs проверяют `clocks = 2*instructions + wait_clocks`, отсутствие
writes и ровно одну accepted transaction на instruction.

Raw counts: [benchmarks-m0.json](benchmarks-m0.json).
Полный лог: [m0-benchmarks.log](../tb/reports/m0-benchmarks.log).
Воспроизведение: `make benchmark`, затем `make vendor-benchmark` при
доступных vendor models. Результат — `build/benchmarks.json`.
Testbench использует условный период 10 ns для functional simulation;
physical timing определяется отдельным MAP/PAR/TRACE, SDF/board execution нет.

## Корректность до измерения CPI

Existing `../core/core.c` DCJ11 собран с ENABLE_MMU=0 и вызывается один раз
на fixture через core_step. 6272 fixtures сравнивают R0..R7, PSW, memory
side effects и отсутствие abort/trap для поддержанного subset. MOV сохраняет C;
CMP считает Rs−Rd с C=borrow; PC operands видят PC после FETCH increment.
Особые тесты проверяют odd word, error ACK, 16-bit wrap и unsupported encoding.
PSW/MMU mode architecture, byte ISA, addressing modes и trap frames пока
не входят в этот differential coverage. Exact sources/log hashes находятся
в [verification-m0.json](verification-m0.json).

## Сравнение с предыдущими экспериментами

| Design / scope | LUT4 | FF | EBR | TRACE Fmax MHz | Сопоставимый RR CPI |
|---|---:|---:|---:|---:|---|
| uJ11 M0 + serial probe, four ISA classes | 582 | 277 | 4 | 41.195 at 40 MHz constraint | 2 with zero-wait RAM |
| microcpu Stable, whole board | 1095 | 431 | 7 | 37.627 | нет; 6 clocks относятся к native microcpu instruction |
| microcpu horizontal 36-bit experiment | 1036 | 433 | 4 | 39.798 | сопоставимые counts не найдены |
| AM4 direct minimal board, гораздо более полная ISA | 902 | 284 | 7 | 31.206 | сопоставимые counts не найдены |

Источники исторических чисел: [previous_experiments.md](previous_experiments.md).
Разные scopes/ISA/память не позволяют объявить speedup относительно AM4
или fit полного будущего uJ11. FRAM/SD/RK clocks — board workloads, не RR CPI.

## Оставшиеся workloads

Memory→register, register→memory, memory→memory, conditional branch loop,
JSR/RTS, stack-intensive code, MUL/DIV/ASH/ASHC и реальная PDP-11 программа
ожидают соответствующих ISA stages. Для них значения не выдумываются.
CP6 выше отдельно измеряет opcode/extension stream, PC redirects и SPI FRAM.
