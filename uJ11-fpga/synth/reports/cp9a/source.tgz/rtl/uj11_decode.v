`timescale 1ns/1ps
// Word ALU classes use direct instruction bits; mode zero bypasses shared EA.
module uj11_decode(input wire [15:0] ir,output wire [9:0] entry);
    wire rr = {ir[11:9],ir[5:3]}==6'b0;
    wire supported = (!ir[15] && ir[14:12]!=3'd0 && ir[14:12]!=3'd7) ||
                     ir[15:12]==4'he;
    wire single_operand = ir[15:9]==7'h05 || ir[15:8]==8'h0c;
    assign entry = supported ? {2'b01,ir[15:12],!rr,3'b0} :
                   single_operand ? {2'b00,ir[11:6],(|ir[5:3]),1'b0} :
                   ir[15:8]==8'h01 ? 10'h180 : 10'h3ff;
    wire unused_register_bits = ^ir[2:0];
endmodule
