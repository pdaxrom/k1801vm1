`timescale 1ns/1ps
// Microcoded execution engine. Dispatch is an external, separately measured
// combinational function of dispatch_ir (incoming data during FETCH).
module uj11_engine (
    input wire clk, reset,
    input wire [9:0] dispatch_address,
    output wire [15:0] dispatch_ir,
    output wire [15:0] mem_addr, mem_write_data,
    output wire mem_request, mem_read, mem_write, mem_byte,
    input wire mem_ack, mem_error,
    input wire [15:0] mem_read_data,
    output wire stopped,
    output wire [1:0] fault_code,
    output reg retire,
    output wire [9:0] debug_upc,
    output wire [35:0] debug_uword,
    output reg [15:0] ir, mdr,
    output wire [15:0] psw, q,
    output wire debug_rf_write,
    output wire [3:0] debug_rf_address,
    output wire [15:0] debug_rf_data
);
    wire [35:0] uword;
    wire [9:0] next_address;
    wire control = uword[35];
    wire [3:0] command = uword[34:31];
    wire fetching = control && command==4'd2;
    wire reading = control && command==4'd11;
    wire writing = control && command==4'd12;
    wire stopping = control && command==4'd13;
    wire memory_op = fetching || reading || writing;
    wire [4:0] a_select = uword[30:26];
    wire [4:0] b_select = uword[25:21];
    function [3:0] select_register;
        input [4:0] selector;
        input [5:0] registers;
        begin
            if (selector[4])
                select_register = {1'b0, selector[0] ? registers[2:0] : registers[5:3]} |
                                  {3'b0,selector[1]};
            else select_register = selector[3:0];
        end
    endfunction
    wire [3:0] a = select_register(a_select,{ir[8:6],ir[2:0]});
    wire [3:0] b = select_register(b_select,{ir[8:6],ir[2:0]});
    wire [15:0] read_a, read_b, result;
    wire [3:0] nzvc;
    reg [15:0] d;
    reg [1:0] fault_latched;
    wire [1:0] bus_fault;
    wire complete;
    wire step = !reset && !stopped && bus_fault==0 && (!memory_op || complete);
    // v3 FETCH encodes ADD/AD/RF/TWO directly. Other control words do not
    // commit datapath results, so their overlapping ALU fields are don't-care.
    wire [3:0] operation = uword[34:31];
    wire [2:0] pair = uword[20:18];
    wire [2:0] destination = (control && !fetching) ? 3'd0 : uword[17:15];
    wire [1:0] flags = control ? 2'd0 : uword[14:13];
    // Only word ISA is enabled at M0. IR[15] is NOT a general byte bit:
    // it also selects word SUB/branches. A later predecoder supplies this.
    wire byte_instruction = 1'b0;
    always @* begin
        case (uword[12:10])
            3'd0: d = 0;
            3'd1: d = 1;
            3'd2: d = 2;
            3'd3: d = (byte_instruction && a<4'd6) ? 16'd1 : 16'd2;
            3'd4: d = mdr;
            3'd5: d = {{7{ir[7]}},ir[7:0],1'b0};
            3'd6: d = {8'b0,uword[7:0]};
            3'd7: d = psw;
        endcase
    end
    uj11_datapath dp(.clk(clk),.reset(reset),.enable(step),.a(a),.b(b),
        .operation(operation),.pair(pair),.destination(destination),.d(d),
        .carry(psw[0]),.byte_mode(1'b0),.read_a(read_a),.read_b(read_b),.result(result),.q(q),
        .nzvc(nzvc),.rf_write(debug_rf_write),.writeback(debug_rf_data));
    uj11_psw status(.clk(clk),.reset(reset),.enable(step),.update(flags),
        .nzvc(nzvc),.value(result),.psw(psw));
    uj11_mem memory(.active(memory_op && !reset && !stopped),
        .writing(writing),.byte_access(control && uword[6] && !fetching),
        .address(read_a),.data(read_b),.ack(mem_ack),.error(mem_error),
        .request(mem_request),.read(mem_read),.write(mem_write),.byte_word(mem_byte),
        .addr(mem_addr),.write_data(mem_write_data),.complete(complete),.fault(bus_fault));
    uj11_microseq seq(.clk(clk),.reset(reset),.enable(step),.uword(uword),.ir(ir),
        .nzvc(psw[3:0]),.dispatch_address(dispatch_address),.address_odd(read_a[0]),
        .byte_instruction(byte_instruction),.selected_a(a),.q0(q[0]),
        .loop_zero(1'b0),.bus_error(bus_fault!=0),.upc(debug_upc),.next_address(next_address));
`ifdef UJ11_VENDOR_ROM
    uj11_rom rom(.clk(clk),.enable(reset || step),.address(next_address),.data(uword));
`else
    uj11_rom #(.IMAGE("microcode/generated/m0.mem")) rom(
        .clk(clk),.enable(reset || step),.address(next_address),.data(uword));
`endif
    assign dispatch_ir = fetching ? mem_read_data : ir;
    assign stopped = (fault_latched!=0) || stopping;
    assign fault_code = fault_latched!=0 ? fault_latched : stopping ? 2'd3 : 2'd0;
    assign debug_uword = uword;
    assign debug_rf_address = b;
    always @(posedge clk) begin
        if (reset) begin
            ir <= 0;
            mdr <= 0;
            fault_latched <= 0;
            retire <= 0;
        end else begin
            retire <= step && !control && uword[9:8]==2'd2;
            if (bus_fault!=0) fault_latched <= bus_fault;
            if (step && (fetching || reading)) mdr <= mem_read_data;
            if (step && fetching) ir <= mem_read_data;
        end
    end
endmodule
