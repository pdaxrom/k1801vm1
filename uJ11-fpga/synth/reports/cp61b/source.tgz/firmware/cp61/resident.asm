; CP61 cold-start gate. This PDP-11 program is copied from ROM into HALT RAM.
; Calling convention: R4=125061, R5=USER source, R1=HALT destination,
; R2=1..64 words. Clobbers R0/R1/R2/R3/R5; preserves R4/SP and saved PSW.
; R0 result: 0 success, 1 bad range, 2 bus error, 3 readback mismatch.
; Whole ranges must be even, below the shared I/O page, destination >=001000.
; No RT-11 calls, no stack, no UJRD/UJWR and no implicit module enable.
	cpu dcj-11
	org 000200
resident_entry
	cmp r4, #0125061
	bne idle
	tst r2
	beq invalid
	cmp r2, #000100
	bhi invalid
	mov r5, r0
	bis r1, r0
	bit #1, r0
	bne invalid
	cmp r1, #001000
	bcs invalid
	mov r2, r3
	asl r3
	add r5, r3
	bcs invalid
	cmp r3, #0160000
	bhi invalid
	mov r2, r3
	asl r3
	add r1, r3
	bcs invalid
	cmp r3, #0160000
	bhi invalid
copy
	dw 000021               ; MFUS: R0=USER[R5], R5+=2
	mov r0, (r1)
	cmp r0, (r1)+
	bne mismatch
	sob r2, copy
	clr r0
return
	dw 000010               ; START: restore guest CPC/CPSW and USER bank
invalid
	mov #1, r0
	br return
fault
	mov #2, r0
	br return
mismatch
	mov #3, r0
	br return
idle
	br idle                 ; Full ODT is a separately loaded future module.
initialize
; Executed only after the ROM has copied AND read back this entire payload.
	mov #000200, @#000170
	mov #000340, r0
	mov r0, @#000172
	mov r0, @#000006
	mov #fault, @#000004
	mov #004000, @#000100   ; CPC: original USER SD bootstrap
	clr @#000102            ; CPSW
	dw 000010               ; START, not RTI
resident_end
