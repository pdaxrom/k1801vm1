`timescale 1ns/1ps
// DEC DCJ11 User's Guide 4.7.4: six writable bits, INIT/RESET clears.
// CP43 CSR storage only. Consumers of map22, split I/D, CSM and MAP are
// deliberately absent from the experimental CPU until separately verified.
module uj11_mmr3 (
    input wire clk, reset, request, writing, low_byte_enable,
    input wire [5:0] write_data,
    output reg [5:0] value,
    output wire ready
);
    // Same immediate acknowledgement as the board's simple CSRs. The master
    // holds request/controls/data stable until the accepting edge. Holding
    // an accepted write repeats only the identical, idempotent assignment.
    assign ready = request && !reset;
    always @(posedge clk) begin
        if (reset) value <= 6'b0;
        else if (request && writing && low_byte_enable) value <= write_data;
    end
endmodule
