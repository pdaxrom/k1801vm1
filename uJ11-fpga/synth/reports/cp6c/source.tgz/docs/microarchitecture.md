# Микроархитектура M0

## Синхронный microstore без лишнего такта

`uj11_microseq` содержит uPC10, link10 и link_valid. На каждом разрешённом
фронте одновременно выполняются uPC←next_address и uword←ROM[next_address].
Поэтому uPC всегда соответствует текущему uword. ROM enable и все side
effects datapath используют один `step`; ожидание ACK сохраняет это соответствие.
Reset принудительно читает address 0 и запрещает datapath writes.

```
current uword ──► next-address logic ──► ROM address
      ▲                                 │
      └───────── next clock ─────────────┘
```

NEXT — 10-bit increment; PAGE — high2 от uPC плюс low8 из microinstruction;
JUMP/CALL — полный target. OR-dispatch использует IR bits непосредственно.
CALL имеет одну return slot; overflow/underflow ведут в diagnostic STOP.
CJUMP читает старые PSW/Q/condition inputs, возможна инверсия условия.
Loop counter в M0 отсутствует, его predicate привязан к 0.

Microstore: четыре явных DP8KC 1024×9. INITVAL содержит пары 9-bit words
в 20-bit slots; bits18/19 каждого slot нулевые. ADA12..3=address9..0,
ADA2..0=001, REGMODE=NOREG. NOREG здесь не означает asynchronous ROM:
чтение происходит по фронту CLKA. Portable model и vendor model проверены.

## Один execution cycle

RF16×16: два asynchronous reads, synchronous write по адресу B.
В MAP/Synplify он реализован четырьмя DPR16X4C и четырьмя SPR16X4C,
без EBR и без 256 FF. Reset microcode очищает 16 слов через обычный write port.
Далее JUMP на FETCH: всего 17 initialization microclocks после снятия reset.
PC хранится только в R7; mirror и третий RF port не нужны в M0.

A/B fields имеют одинаковое расположение в ALU и control words. Literal
selectors 0..15 выбирают R0..R7/T0..T7; RS/RD и RS1/RD1 используют IR.
В v3 FETCH имеет command=2, совпадающий с ALU ADD, и кодирует AD/RF/TWO
в обычных datapath fields. Поэтому отдельные override mux для operation,
pair и D-input устранены. READ/WRITE и другие control words не разрешают
RF/Q/PSW writeback, несмотря на произвольные overlapping ALU fields.

Operand selection — параллельные masked buses. Один общий 17-bit carry
chain обслуживает ADD/ADC/SUB/SBC. Carry для SUB — borrow. Нет multiplier,
divider или barrel shifter. Q16 поддерживает load и связанные RF/Q shifts.
PSW16 обновляется KEEP/NZV/NZVC/LOAD; FLAGS берутся до RFQ writeback shift.

При FETCH completion IR и MDR получают входящий opcode, ALU записывает
R7+2. `dispatch_ir` в этот момент равен входящему memory word. Decoder
выбирает execution entry прямо на том же фронте ROM; decode bubble нет.
MOV/ADD/CMP R,R и BR заканчиваются одной ALU microinstruction с seq=FETCH.
Запись R7 этим же datapath перенаправляет следующий FETCH.

Измеренный цикл при zero-wait RAM:

```
FETCH: request/ack + R7+=2 + IR/MDR + ROM dispatch
EXEC:  dual RF read + ALU + RF/PSW commit + retire + ROM[FETCH]
```

Получены 2 clocks/instruction, включая BR и PC operands. Это не prefetch:
следующий memory request появляется в следующей FETCH-микрокоманде.

## Memory и diagnostic stop

`uj11_mem` не содержит address registers или translation. Текущие uword/RF
удерживают address и data до ACK. Один request&&ack на фронте — один beat;
back-to-back beats допустимы. Byte transaction использует точный addr и
right-justified payload; primitive проверен, byte ISA пока отсутствует.

Word по нечётному адресу подавляет request и устанавливает fault_code=1.
ACK+error устанавливает code=2 и запрещает PC/IR/MDR/PSW/Q/RF side effects.
Неподдержанный opcode выбирает STOP, code=3; его FETCH уже увеличил PC на 2,
но execution effects нет. STOP не является PDP-11 HALT или архитектурным trap.
Reset очищает fault. `retire` — registered pulse после execution commit.

IR16, MDR16, PSW16, Q16, sequencer21, fault2 и retire1 дают 88 state bits.
В финальном probe дополнительно 18 input и 171 observation FF: всего 277 FF,
совпадающих с MAP. LUT count указан только для полного измеренного probe.
Выходы debug показывают RF write port и state; дополнительного RF read port нет.

## Что измерения говорят о конструкции

Формат/ROM занимают ровно четыре EBR. RF обеспечивает нужные два чтения и
одну запись за execution cycle. Decoder не является critical path.
Control-field mux были дорогими: выравнивание selectors и ALU-поля FETCH
дали измеренное уменьшение LUT и рост Fmax. Оптимальность всего datapath
не доказана: сохраняется путь EBR → RF selector/read → ALU → RF/PSW.
Подробные timings, сохранённые неудачные варианты и следующий gate —
[synthesis.md](synthesis.md). Усложнений ради будущего MMU нет.
