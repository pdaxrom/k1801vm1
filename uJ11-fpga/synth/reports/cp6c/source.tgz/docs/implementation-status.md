# Implementation status, 2026-09-08

**Малый milestone M0 выполнен: работающий ISA subset, differential tests,
benchmarks и полный HC1200 synthesis baseline. Исходная цель 50 MHz открыта;
финальный constraint 40 MHz проходит. Полный PDP-11/J-11 ещё не реализован.**

| Требование M0 | Состояние |
|---|---|
| Анализ microcpu/microasm/AM4/emulator/tests | выполнен до RTL; 22 historical raw MAP reports индексированы |
| previous_experiments.md с конкретными цифрами | выполнен; paths и SHA-256 в previous_reports.json |
| Microarchitecture и 36-bit format | реализованы, текущий encoding v3; v1/v2 сохранены с отчётами |
| Microsequencer | NEXT/PAGE/JUMP/CJUMP/CALL/RETURN, dispatch и OR_MS/MD/RR/BT/R67 |
| Microstore | 1024×36, четыре vendor DP8KC, ROM/listing/labels/stats из assembler |
| RF/Q/ALU/IR/PSW/MDR | RF16×16 dual-read/one-write, Q16, ALU16, IR16, PSW16, MDR16 |
| Memory | 16-bit addr, request/read/write/byte/data, ACK/error, stalls и odd-word protection |
| ISA | FETCH; word MOV/ADD/CMP только mode0; BR, включая PC wrap/PC operands |
| Microcode usage | 23/1024 words, 2.24609375%; 17 reset/control + FETCH + 4 execution + STOP |
| Differential tests | 6272 существующих DCJ11 reference cases, ENABLE_MMU=0 |
| HC1200 MAP/PAR/TRACE | 582 LUT4 / 277 FF / 4 EBR; 40 MHz PASS; Fmax 41.195 MHz |
| Performance | 2+N microclocks/instruction при N wait clocks, 1 memory cycle/instruction |
| Prefetch / EA modes 1..7 / byte ISA | не реализованы; следующие checkpoints |
| Traps/interrupts/PSW ISA/HALT/WAIT/RTI | не реализованы; diagnostic STOP не заменяет trap handling |
| EIS / loop counter / J-11 banking | не реализованы; Q/one-bit shifts есть как primitives |
| MMU | полностью отсутствует, без stubs, tables, extended addresses и резервов EBR |

## Проверки финального RTL/encoding

* 7 Python test methods: encoding, conflicts, aligned control fields,
  FETCH ALU context, 1024 random 36-bit words physical packing/roundtrip.
* 4323 sequencer checks: predicates/inversion, все mode fields/OR dispatches,
  1024 external dispatch addresses, NEXT/PAGE/wrap, CALL/RETURN stalls и faults.
* 1024 ROM reads и 1024 holds; 17 ROM feedback transitions со stalls.
* 66592 независимых ALU result/NZVC checks; RF16 и 256 dual-read combinations,
  writeback, Q load/combined shifts, stalls/reset.
* PSW masks/load; word/byte RAM lanes, back-to-back requests, wait-state stability;
  READ/WRITE/MDR microprogram с 0..7 wait clocks и точными transaction counts.
* Engine reset, fetch stalls, one-cycle ADD, odd-address/bus-error/unsupported stop.
* Все 65536 opcode: ровно 448 принимаются (192 RR encodings + 256 BR offsets).
* 6272 differential cases: all 64 Rs/Rd combinations, edge operands и C,
  2048 random cases, все 256 BR offsets у трёх PC bases; сравниваются R0..R7,
  PSW, memory writes/transactions, отсутствие abort/trap у поддержанного subset.
  Задержки 0..3 clocks, всего 21952 execution/fetch clocks без reset.
* Отдельно: FETCH с 0xfffe и wrap PC, запрет MOV memory mode/MOVB/HALT.
* 15 benchmark runs по 4096 измеренных instructions, warmup исключён,
  zero/two/random wait clocks; counts portable и vendor ROM идентичны.
* Verilator --Wall без предупреждений. Vendor DP8KC functional simulations
  пройдены для control store, engine, memory microprogram, differential и benchmarks.

Логи: [tests](../tb/reports/m0-tests.log), [benchmarks](../tb/reports/m0-benchmarks.log).
Exact verified input hashes: [verification-m0.json](verification-m0.json).
Это functional simulation и vendor timing analysis; physical board execution
и внешние memory I/O timing ещё не проверены. Полная J-11 совместимость,
архитектурные traps и byte semantics этим ограниченным тестом не заявляются.

## Следующий gate

Оценка M0 закончена: RF и четыре EBR подходят; формат должен оставаться
semi-horizontal; control mux необходимо оценивать по critical path.
Перед расширением ISA измерить timing/prefetch tradeoff, затем отдельно
EA modes, basic ISA, traps/interrupts и EIS. Цель полного core ~900–1000 LUT
остаётся целью: текущие 582 LUT относятся только к M0 и его probe.
