# Synthesis checkpoints

Все результаты ниже — реальные Diamond **3.14.0.75.2 / Synplify**
Synthesis → Translate → MAP → PAR → TRACE на `sash@192.168.1.108`,
**LCMXO2-1200HC-4SG32C**, area strategy, no retiming, 2026-09-08.
Ни один failed run не представлен как проходящий 50 MHz.

**Принят M0 v3: 582 LUT4, 277 FF, 4 EBR; 40 MHz PASS, Fmax 41.195 MHz.**
50 MHz остаётся целью: v3 при constraint 50 MHz даёт Fmax 42.902 MHz и
setup failure. Результаты при разных constraints имеют разный placement;
нельзя переносить Fmax одного placement на другой без нового TRACE.

## Измерения

LUT4 здесь — MAP total, включая distributed RAM и carry/ripple logic.
FF и LUT включают указанный probe. Words — явно assembled microinstructions,
а не физическая глубина ROM и не число execution clocks.

| Revision / input SHA-256 prefix | Features | LUT4 | FF | EBR | Fmax MHz | Constraint / result | Words | Notes |
|---|---|---:|---:|---:|---:|---|---:|---|
| [cp1](../synth/reports/cp1/inputs.json) / `b7d860d0a264` | ROM + sequencer, format v1 | 133 | 62 | 4 | 54.885 | 50 MHz / PASS | 45 | 41 harness FF; diagnostic image |
| [cp2](../synth/reports/cp2/inputs.json) / `db079aeaf5ce` | RF/Q/ALU, XOR before observation FF | 399 | 57 | 0 | 44.895 | 50 MHz / FAIL | — | Rejected probe: checksum in critical path |
| [cp2r1](../synth/reports/cp2r1/inputs.json) / `22cd87c1f03c` | RF/Q/ALU, raw observation FF | 382 | 135 | 0 | 53.453 | 50 MHz / PASS | — | Same datapath, corrected observer |
| [cp3](../synth/reports/cp3/inputs.json) / `393da452f8c5` | Engine + IR/PSW/MDR/memory, v1 | 661 | 303 | 4 | 36.682 | 50 MHz / FAIL | 23 | EBR→selector→RF→ALU→RF bottleneck |
| [cp3r1](../synth/reports/cp3r1/inputs.json) / `93c2985871de` | Parallel operand/writeback buses | 625 | 303 | 4 | 38.389 | 50 MHz / FAIL | 23 | −36 LUT4; keep change |
| [cp3r2](../synth/reports/cp3r2/inputs.json) / `3073ca340b14` | Aligned A/B fields, format v2 | 610 | 303 | 4 | 39.228 | 50 MHz / FAIL | 23 | −15 LUT4; keep change |
| [cp3r2-35](../synth/reports/cp3r2-35/inputs.json) / `f9bacc6b3ada` | Same v2 engine, 35 MHz constraint | 610 | 303 | 4 | 38.037 | 35 MHz / PASS | 23 | First integrated passing baseline |
| [cp4](../synth/reports/cp4/inputs.json) / `d2e79c663ea5` | Direct-bit M0 opcode decoder | 13 | 22 | 0 | 150.150 | 50 MHz / PASS | — | All 65536 encodings tested |
| [cp5-50](../synth/reports/cp5-50/inputs.json) / `156c84476ba5` | Full M0 v2, 50 MHz | 639 | 277 | 4 | 38.806 | 50 MHz / FAIL | 23 | 639 LUT baseline; timing fail |
| [cp5-35](../synth/reports/cp5-35/inputs.json) / `b60cedb16bb5` | Full M0 v2, 35 MHz | 639 | 277 | 4 | 36.642 | 35 MHz / PASS | 23 | setup/hold pass |
| [cp5v3-50](../synth/reports/cp5v3-50/inputs.json) / `2bbbef62d091` | FETCH uses ordinary ALU fields, v3 | 582 | 277 | 4 | 42.902 | 50 MHz / FAIL | 23 | −57 LUT4; +4.096 MHz vs v2 at 50 MHz |
| [cp5v3-40](../synth/reports/cp5v3-40/inputs.json) / `849914189671` | Final M0 v3, 40 MHz | 582 | 277 | 4 | 41.195 | 40 MHz / PASS | 23 | Accepted M0 baseline; margin 0.725 ns |

Индекс с hashes: [synthesis-results.json](synthesis-results.json).
Каждый каталог `synth/reports/<revision>/` содержит `source.tgz`, `inputs.json`,
полные `design.mrp/.srr/.par/.twr` и build log; у всех успешно разобранных
runs есть первоначальный `result.json`. CP2 завершил toolchain, но старый
parser не распознал TRACE `Warning:` вместо `Report:`; его действительные
цифры извлечены из сохранённых raw reports исправленным parser. Все 12
source archives проверены против input hashes. Generated ROM включён в archives.

## Что потребляло ресурсы и ограничивало частоту

CP1: 40 stimulus FF + 1 checksum FF, 21 sequencer FF = 62 FF. Его 54.885 MHz
ограничивались путём ROM→predicate/next→checksum FF; это не bare ROM limit.
Actual ROM count — 4 EBR; vendor sweep всех слов и hold/feedback tests прошли.

CP2: сначала длинный XOR стоял после datapath перед observation FF. Он
искусственно ограничил probe до 44.895 MHz. После регистрации raw outputs
XOR вынесен за эти FF: 53.453 MHz, 382 LUT4. RF при этом не менялся.
Тестовая обвязка объявляет 36 input + 85 observation bits, Q — 16;
часть одинаковых observation bits была объединена, MAP показывает 135 FF.

CP3: интеграция добавила EBR clock-to-output (4.979 ns в critical path),
выбор literal/dynamic RF и control mux. 27.536 ns path в первой версии:
EBR→A field mux→dynamic selector→RF→operand selection→ALU→writeback→RF.
Реальный regression исследован до добавления opcode decoder.

Параллельные masked buses дали 661→625 LUT4; одинаковые позиции A/B в
ALU/control words — 625→610. Последний вариант прошёл отдельный fit 35 MHz.
В v2 core критическим стал EBR→FETCH override→operand mux→adder→Z→PSW.
В v3 сам FETCH кодирует ADD/AD/RF/TWO: override operation/pair/D устранены.
Это дало **639→582 LUT4** и **38.806→42.902 MHz** при том же 50 MHz target,
без изменения microcode word count, architectural state или CPI.

## Финальный scope и ограничения измерения

`uj11_probe_core`: clk/reset/serial_in/serial_out, 18 input и 171 observation
FF, raw outputs регистрируются до XOR. Это делает пути через core наблюдаемыми
на SG32 без pinout на сотню внешних сигналов. Engine имеет 88 state bits;
MAP total FF=277. RF — 4 DPR16X4C + 4 SPR16X4C, **48 MAP LUT4** distributed
RAM. Whole-probe MAP: 504 logic + 48 distributed RAM + 30 ripple = 582 LUT4,
4 EBR. Нет отдельного bare-core fitted LUT result: арифметическое вычитание
checksum LUT из общего MAP его не заменяет.

Финальный 40 MHz [TRACE](../synth/reports/cp5v3-40/design.twr):
setup errors=0, hold errors=0, cumulative negative slack=0; full routing.
Худший путь EBR lane2→dynamic selector/RF→ALU/writeback→RF, delay 24.550 ns,
18 logic levels, margin **0.725 ns**. 50 MHz variant ограничен путём к
PSW Z: delay 22.970 ns, violation **3.309 ns**.

Timing coverage финального probe **86.95%**. Внешние input/output delays
не заданы, reset/asynchronous paths исключены согласно LPF; internal
synchronous paths проверены. Это не board-level memory timing closure и
не физический тест частоты. Подключение реальной SRAM/controller потребует
своих I/O constraints и повторного MAP/PAR/TRACE. Доступно 698 из 1280 LUT4
и 3 из 7 EBR относительно данного probe; они не зарезервированы под MMU.
M0 содержит лишь четыре ISA classes, поэтому fit всей будущей ISA не доказан.

## Оценка архитектурных гипотез

* **RF16×16:** дешёвая distributed RAM и нужный один execution cycle
  подтверждены. Причины переходить к 24/32-word multiport RF нет.
  FF/EBR RF alternative пока не синтезировалась: глобальная оптимальность
  RF не доказана, но измеренный вариант подходит для продолжения.
* **ALU/Q:** shared carry chain и shift-by-one достаточны для M0;
  selectors/operand/writeback/flags, а не multiplier/divider, остаются
  timing bottleneck. EIS ещё не реализован и не входит в CPI.
* **36 bits:** физические четыре EBR подтверждены. Контекстное переиспользование
  полей помогает только при отсутствии дополнительных mux; v1→v3 это показал.
  Сокращать ширину до 32 при тех же четырёх EBR оснований нет.
* **Sequencer:** synchronous next-address feedback работает без sequencing
  bubbles, 21 state FF; page8 и full control targets сочетаются. Глубина CALL
  ограничена одним уровнем и может потребовать изменения для будущих routines.
* **Decoder:** isolated 13 LUT4/22 FF probe, 150.150 MHz; direct opcode bits
  эффективны для четырёх classes. Полную PLM/distributed ROM сравнить позже,
  когда ISA станет шире. Сейчас она не определяет critical path.

Это обоснованный baseline, а не доказательство максимально возможных 50 MHz.
Дальше отдельно измерить упрощение selector/flags path и instruction-stream
prefetch; не покупать частоту автоматическим добавлением microclock к каждой
инструкции без сравнения throughput. ISA остаётся M0 до следующего gate.

## Воспроизводимый запуск

В свежей копии проекта на Linux с установленным Diamond:

```
make all
make vendor-test vendor-engine vendor-memory-engine vendor-core
make synthesis                 # full M0, SYNTH_MHZ=40 by default
```

Для другого constraint использовать отдельную свежую копию:

```
make synthesis SYNTH_MHZ=50
```

Для отдельных текущих blocks: `python3 tools/checkpoint.py cp2`, `cp3`,
`cp4` или `cp5 --mhz 40`. Сначала `make microcode-m0` для CP3/CP5.
Исторический exact checkpoint воспроизводится из его source.tgz; текущие
assembler/RTL уже отличаются от v1/v2. `make synthesis-seq` — отдельный CP1.
Каждый runner отвергает существующую implementation directory, проверяет
actual clock preference и сохраняет новые source/ROM/report hashes.
`python3 tools/summarize_reports.py` перечитывает архивированные raw reports.
FPGA programming, Programmer и board image deployment не выполнялись.
