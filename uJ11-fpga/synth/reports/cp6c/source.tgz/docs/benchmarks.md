# Benchmarks M0

Измеряется один и тот же final encoding v3 core: **582 LUT4 / 277 FF / 4 EBR**
с synthesis probe, **40 MHz constraint PASS**, TRACE Fmax **41.195 MHz**.
Источник counts — RTL functional simulation; portable synchronous ROM и
Diamond DP8KC дали идентичный JSON. Частота из TRACE не подменяет board test.

## Циклы и пропускная способность

| Workload | Zero-wait microclocks / instruction | Two-wait microclocks / instruction | Random 0..3 waits microclocks / instruction | Memory cycles / instruction | Zero-wait instr/s at 40 MHz |
|---|---:|---:|---:|---:|---:|
| MOV_RR_loop | 2.0000 | 4.0000 | 3.5237 | 1.0000 | 20,000,000 |
| ADD_RR_loop | 2.0000 | 4.0000 | 3.5029 | 1.0000 | 20,000,000 |
| CMP_RR_loop | 2.0000 | 4.0000 | 3.5283 | 1.0000 | 20,000,000 |
| mixed_RR_loop | 2.0000 | 4.0000 | 3.5083 | 1.0000 | 20,000,000 |
| BR_self | 2.0000 | 4.0000 | 3.5093 | 1.0000 | 20,000,000 |

20 млн instr/s — расчёт **40 MHz / measured CPI 2** при zero-wait memory,
а не измерение на плате. При двух wait clocks — 10 млн instr/s. Нет prefetch;
два такта получены FETCH+decode на одном фронте и одной ALU execution word.
При N wait clocks получается 2+N microclocks/instruction.

Каждая строка измеряет 4096 instructions после 64 warmup retirements.
MOV/ADD/CMP loops содержат 63 указанные RR instructions и BR назад —
64 слова на итерацию. Mixed loop повторяет MOV R1,R2; ADD R3,R2;
CMP R1,R2; ADD R4,R1, последняя позиция заменена BR. BR_self — BR на себя.
Начальные R0..R6=0..6, R7=0, PSW=0. Reset/initialization не входят в counts.
Это небольшие synthetic loops; реальную программу для полной ISA M0 ещё
не исполняет. Число register ALU cycles отдельно подтверждено ISA tests.

Zero-wait: **8192 clocks / 4096 instructions / 4096 bus transactions**.
Two-wait: **16384 / 4096 / 4096**. В random режиме LCG seed 0x00111801,
wait states выбираются из bits25:24 после retirement и сохраняются до ACK.
`wait_mode=0` в JSON означает 0 waits, `1` — 2 waits, `2` — random 0..3;
это номера сценариев, а не буквальное количество wait states.
Все 15 runs проверяют `clocks = 2*instructions + wait_clocks`, отсутствие
writes и ровно одну accepted transaction на instruction.

Raw counts: [benchmarks-m0.json](benchmarks-m0.json).
Полный лог: [m0-benchmarks.log](../tb/reports/m0-benchmarks.log).
Воспроизведение: `make benchmark`, затем `make vendor-benchmark` при
доступных vendor models. Результат — `build/benchmarks.json`.
Testbench использует условный период 10 ns для functional simulation;
physical timing определяется отдельным MAP/PAR/TRACE, SDF/board execution нет.

## Корректность до измерения CPI

Existing `../core/core.c` DCJ11 собран с ENABLE_MMU=0 и вызывается один раз
на fixture через core_step. 6272 fixtures сравнивают R0..R7, PSW, memory
side effects и отсутствие abort/trap для поддержанного subset. MOV сохраняет C;
CMP считает Rs−Rd с C=borrow; PC operands видят PC после FETCH increment.
Особые тесты проверяют odd word, error ACK, 16-bit wrap и unsupported encoding.
PSW/MMU mode architecture, byte ISA, addressing modes и trap frames пока
не входят в этот differential coverage. Exact sources/log hashes находятся
в [verification-m0.json](verification-m0.json).

## Сравнение с предыдущими экспериментами

| Design / scope | LUT4 | FF | EBR | TRACE Fmax MHz | Сопоставимый RR CPI |
|---|---:|---:|---:|---:|---|
| uJ11 M0 + serial probe, four ISA classes | 582 | 277 | 4 | 41.195 at 40 MHz constraint | 2 with zero-wait RAM |
| microcpu Stable, whole board | 1095 | 431 | 7 | 37.627 | нет; 6 clocks относятся к native microcpu instruction |
| microcpu horizontal 36-bit experiment | 1036 | 433 | 4 | 39.798 | сопоставимые counts не найдены |
| AM4 direct minimal board, гораздо более полная ISA | 902 | 284 | 7 | 31.206 | сопоставимые counts не найдены |

Источники исторических чисел: [previous_experiments.md](previous_experiments.md).
Разные scopes/ISA/память не позволяют объявить speedup относительно AM4
или fit полного будущего uJ11. FRAM/SD/RK clocks — board workloads, не RR CPI.

## Оставшиеся workloads

Memory→register, register→memory, memory→memory, conditional branch loop,
JSR/RTS, stack-intensive code, MUL/DIV/ASH/ASHC и реальная PDP-11 программа
ожидают соответствующих ISA stages. Для них значения не выдумываются.
Следующий prefetch checkpoint должен отдельно измерять opcode/extension
stream consumption, invalidation при PC redirects и эффект реальных ACK delays.
