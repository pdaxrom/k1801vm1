`timescale 1ns/1ps
// One synchronous EBR holds mode-0 entries. Existing IR supplies the few
// low-bit exceptions after the fetch edge; no second opcode register.
module uj11_decode_rom(input wire clk, enable,
    input wire [15:0] incoming, ir, output reg [9:0] entry);
    wire [8:0] base;
    wire memory_mode=|ir[5:3];
    reg [9:0] extra;
    uj11_decode_table table_rom(.clk(clk),.enable(enable),.address(incoming[15:6]),.data(base));
    always @* begin
        extra=0;
        case(ir[15:12])
            1,2,3,4,5,6,9,10,11,12,13,14: extra={6'b0,memory_mode,3'b0};
            7: case(ir[11:9])
                0,1:extra={7'b0,memory_mode,2'b0};
                4:extra={8'b0,memory_mode,1'b0};
                default:extra=0;
            endcase
            0,8:case(ir[11:8])
                10,11,12:extra={8'b0,memory_mode,1'b0};
                13:if(ir[7:6]==0 && ir[15])extra={8'b0,memory_mode,1'b0};
                   else if(ir[7:6]==3)extra=ir[15] ? {8'b0,memory_mode,1'b0} : {7'b0,memory_mode,2'b0};
                default:extra=0;
            endcase
            default:extra=0;
        endcase
        entry={1'b0,base}|extra;
        if(ir[15:8]==0)begin
            entry=10'h042;
            case(ir[7:6])
                0:case(ir[5:0])
                    0:entry=10'h018; 1:entry=10'h012;
                    2,6:entry=10'h031; 3:entry=10'h024; 4:entry=10'h026;
                    5:entry=10'h021; 7:entry=10'h017;
                    default:entry=10'h042;
                endcase
                1:entry=memory_mode?10'h080:10'h040;
                2:case(ir[5:3])
                    0:entry=10'h090;
                    3:entry={6'b011111,ir[2:0],1'b0};
                    4,5,6,7:entry={3'b010,ir[3:0],3'b100};
                    default:entry=10'h042;
                endcase
                3:entry={6'b011100,memory_mode,3'b0};
            endcase
        end
        if(ir[15:9]==7'o004 && memory_mode)entry=10'h088;
        if(ir[15:6]==10'o750 && ir[5])entry=10'h042;
    end
endmodule
