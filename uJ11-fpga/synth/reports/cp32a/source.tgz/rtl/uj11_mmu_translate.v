`timescale 1ns/1ps
// DEC EK-DCJ11-UG-PRE 4.5.2, 4.7.4.3 and figures 4-11..4-13.
// Stateless translation/checking only. No CPU connection or MMR/PAR/PDR store.
module uj11_mmu_translate (
    input wire enabled, map22, writing, invalid_mode,
    input wire [15:0] virtual_address, par, pdr,
    output wire [21:0] physical_address,
    output wire [2:0] abort_flags,
    // Candidate address classes: caller MUST inhibit bus requests on abort.
    output wire ram_selected, io_selected, nxm
);
    wire unused_pdr = &{pdr[15],pdr[7:4],pdr[0]};
    // A 16-bit block sum wraps at 4 MiB; its low 12 bits also wrap at 256 KiB.
    wire [15:0] block_address = par + {9'b0,virtual_address[12:6]};
    wire io18 = &block_address[11:7];
    wire io16 = &virtual_address[15:13];
    wire [15:0] mapped_block = {
        map22 ? block_address[15:12] : {4{io18}},block_address[11:0]};
    // Canonical PA22: legacy 16/18-bit I/O windows become the top 8 KiB.
    // map22 has no effect when relocation is disabled.
    assign physical_address = {enabled ? mapped_block :
        {{6{io16}},virtual_address[15:6]},virtual_address[5:0]};
    wire [7:0] length_delta = {1'b0,virtual_address[12:6]} - {1'b0,pdr[14:8]};
    assign abort_flags[2] = enabled && (!pdr[1] || invalid_mode);
    assign abort_flags[1] = enabled && (pdr[3] ? length_delta[7] :
        (!length_delta[7] && (|length_delta[6:0])));
    assign abort_flags[0] = enabled && writing && pdr[2:1] == 2'b01;
    assign ram_selected = !(|physical_address[21:17]);
    assign io_selected = &physical_address[21:13];
    assign nxm = !ram_selected && !io_selected;
endmodule
