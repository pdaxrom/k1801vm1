`timescale 1ns/1ps
module tb_decode;
    reg [15:0] ir;
    wire [9:0] entry;
    reg [9:0] expected;
    integer i,accepted=0;
    uj11_decode dut(.*);
    initial begin
        for(i=0;i<65536;i=i+1) begin
            ir=i[15:0];
            expected=10'h3ff;
            // Independent octal masks for the exact PDP-11 encodings.
            if((i & 'o177400)>='o000400 && (i & 'o177400)<='o003400)
                expected='h40+((i >> 8)*4);
            if((i & 'o177400)>='o100000 && (i & 'o177400)<='o103400)
                expected='h60+(((i & 'o3400)>>8)*4);
            if((i & 'o170000)=='o010000) expected='h118;
            if((i & 'o170000)=='o020000) expected='h128;
            if((i & 'o170000)=='o060000) expected='h168;
            if((i & 'o170000)=='o030000) expected='h138;
            if((i & 'o170000)=='o040000) expected='h148;
            if((i & 'o170000)=='o050000) expected='h158;
            if((i & 'o170000)=='o160000) expected='h1e8;
            if((i & 'o177070)=='o010000) expected='h110;
            if((i & 'o177070)=='o020000) expected='h120;
            if((i & 'o177070)=='o060000) expected='h160;
            if((i & 'o177070)=='o030000) expected='h130;
            if((i & 'o177070)=='o040000) expected='h140;
            if((i & 'o177070)=='o050000) expected='h150;
            if((i & 'o177070)=='o160000) expected='h1e0;
            if((i & 'o177000)=='o005000 || (i & 'o177400)=='o006000)
                expected=(((i & 'o7700)>>6)*4) + ((i & 'o70)!=0 ? 2 : 0);
            if((i & 'o170000)=='o110000)expected=((i & 'o7070)==0)?'h110:'h118;
            #1;
            if(entry!==expected) $fatal(1,"decoder opcode%06o got%h expected%h",i,entry,expected);
            if(entry!=10'h3ff) accepted=accepted+1;
        end
        if(accepted!=37376) $fatal(1,"accepted opcode count %0d",accepted);
        $display("PASS decoder: all 65536 opcodes, exactly 37376 supported encodings");
        $finish;
    end
endmodule
