`timescale 1ns/1ps
// Control bit 4 pauses speculative launches, preserving sequential READ state.
// ALU words inherit the last control policy; their immediate/page bits are free.
module uj11_prefetch_control(input wire clk,reset,input wire [35:0] uword,output wire allow);
    reg inherited;
    always @(posedge clk) begin
        if(reset) inherited<=0;
        else if(uword[35]) inherited<=!uword[4];
    end
    assign allow=uword[35] ? !uword[4] : inherited;
    wire unused_fields=^{uword[34:5],uword[3:0]};
endmodule
