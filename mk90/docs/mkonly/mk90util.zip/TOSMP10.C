/* The program converts a list of BASIC programs to the memory image of
 an MK-90 memory cartridge, BASIC 1.0 version.
 Potential portability issues:
 - little endian order of bytes required
*/

#include <stdio.h>
#include <string.h>	/* memset, memcpy */
#include <ctype.h>	/* islower, toupper */

typedef unsigned short word;
typedef unsigned char byte;

/* Structure of directory entry */
typedef struct {
  word attribute;
  word name[3];		/* file name+extension, Radix-50 encoded */
  word sectors;		/* Number of sectors assigned to the directory entry */
  word unknown[2];
} DIR_ENTRY;

#define DIR_ENTRY_SIZE sizeof(DIR_ENTRY)


/* SMP initialisation blocks: destination address, number of bytes */
word initblocks[] = {
  0x0400, 0x001A,
  0x0000, 0x003C,
  0x0200, 0x0002,
  0x03D2, 0x0025
};

/* SMP initialisation data */
byte initdata[] = {
/* directory */
  0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,
  0x04, 0x00, 0x00, 0x02, 0x20, 0x20, 0x20, 0x20,
  0x20, 0x20, 0x10, 0x00, 0x20, 0x20, 0x20, 0x20,
  0x00, 0x08,

/* boot loader code */
  0xA0, 0x00, 0xDF, 0x09, 0xC0, 0xD7, 0xDF, 0x09,
  0x5E, 0xA1, 0xDF, 0x17, 0x12, 0x38, 0x00, 0xE8,
  0xDF, 0x15, 0xC6, 0x88, 0x02, 0xE8, 0x37, 0x08,
  0x18, 0x00, 0x0E, 0x0D, 0x0A, 0x20, 0x73, 0x6D,
  0x70, 0x20, 0x42, 0x45, 0x5A, 0x20, 0x5A, 0x41,
  0x47, 0x52, 0x55, 0x5A, 0x5E, 0x49, 0x4B, 0x41,
  0x00, 0xFF, 0x02, 0x94, 0xFF, 0x03, 0xDF, 0x09,
  0x62, 0x9D, 0xFB, 0x01,

  0x00, 0x00,

  0x01, 0x00, 0x06, 0x00, 0x4F, 0x8E, 0x42, 0x41,
  0x53, 0x49, 0x43, 0x20, 0x20, 0x20, 0x20, 0x20,
  0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
  0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
  0x20, 0x20, 0x20, 0x20, 0x20
};


/* Cyrillic character conversion table Windows-1251 -> MK90, codes 0xC0-0xFF.
   Characters "jo" aren't included and have to be handled separately. */
char chartab[] = {
  '\141', '\142', '\167', '\147', '\144', '\145', '\166', '\172',
  '\151', '\152', '\153', '\154', '\155', '\156', '\157', '\160',
  '\162', '\163', '\164', '\165', '\166', '\150', '\143', '\176',
  '\173', '\175', '\137', '\171', '\170', '\174', '\140', '\161',
  '\101', '\102', '\127', '\107', '\104', '\105', '\126', '\132',
  '\111', '\112', '\113', '\114', '\115', '\116', '\117', '\120',
  '\122', '\123', '\124', '\125', '\106', '\110', '\103', '\136',
  '\133', '\135', '\137', '\131', '\130', '\134', '\100', '\121'
};


#define SECTORSIZE 512

#define MAXLINE 256
char input_line[MAXLINE];	/* buffer for the input line */

#define BUFSIZE 10240
byte buffer[BUFSIZE+1024];	/* reserve, less space checking needed */


int isendline (char c)
{
  return (c == '\r' || c == '\n' || c == '\0') ? 1 : 0;
}


byte whichcharset (char c)
{
  if (c == '\250' || c == '\270' ||
	(unsigned char) c >= (unsigned char) '\300')
  {
    return 0x0E;	/* Cyrillic character */
  }
  if (isalpha (c) != 0 || c == '\"')
  {
    return 0x0F;	/* Latin character */
  }
  return 0;		/* any */
}


/* returns the MK-90 code of a Windows-1251 character */
char convchar (char c)
{
  if (c == '\250')	/* JO */
  {
    return '\145';
  }
  if (c == '\270')	/* jo */
  {
    return '\105';
  }
  if ((unsigned char) c >= (unsigned char) '\300')
  {
    return chartab[(int) ((unsigned char) c - (unsigned char) '\300')];
  }
  return c;
}


/* convert a string of three characters to Radix-50 */
word toradix50 (char *s)
{
  static char chset[] = " ABCDEFGHIJKLMNOPQRSTUVWXYZ$./0123456789";
  word result = 0;
  word y;
  int i;
  int c;

  for (i=0; i<3; i++)
  {
    c = (int) s[i];
    if (islower(c) != 0)
    {
      c = toupper(c);
    }
    for (y=0; y<40; y++)
    {
      if (c == (int) chset[y])
      {
        break;
      }
    }
    if (y >= 40)	/* unsupported character */
    {
      y = 27;		/* $ */
    }
    result = result*40 + y;
  }
  return result;
}


/* expand the file name to the "input_line" buffer,
   output format 8+3 characters, padded with spaces */
void expand_fname (char *s)
{
  int i = 0;
  char *ptr = s;

  memset (input_line, 0x20, (size_t) (8+3));
  for (i=0; i<8; i++)
  {
    if (*ptr == '\0') return;
    if (*ptr == '.') break;
    input_line[i] = *ptr++;
  }
  while (*ptr != '.')
  {
    if (*ptr++ == '\0') return;
  }
  for (i=8; i<8+3; i++)
  {
    if (*++ptr == '\0') return;
    input_line[i] = *ptr;
  }
}


int main (int argc, char **argv)
{
  word i;
  byte x;
  word y;
  FILE *fp;
  char *ptr;
  byte charset;
  DIR_ENTRY *dirptr;

/* initialise the SMP buffer */
  memset (buffer, 0x20, (size_t) BUFSIZE);
  y=0;
  for (i=0; i<8; i+=2)
  {
    memcpy (&buffer[initblocks[i]], &initdata[y], (size_t) initblocks[i+1]);
    y += initblocks[i+1];
  }

  i = 0x0800;			/* start of the SMP data space */
  dirptr = (DIR_ENTRY*) &buffer[0x040A];

/* process the BASIC programs */
  while (--argc > 0 && i < BUFSIZE)
  {
    if ((fp = fopen(*++argv, "rt")) == NULL)
    {
      fprintf (stderr, "\nCannot open the file %s\n",*argv);
    }
    else
    {

/* copy the file contents to the SMP data space */
      y = i;
      charset = 0x0F;		/* Latin */
      buffer[i++] = 0x0D;
      buffer[i++] = 0x0A;
      while (fgets (input_line, MAXLINE, fp) != NULL &&
		*input_line != '\032' && i < BUFSIZE)
      {
        ptr = input_line;
/* skip empty lines */
        if (isendline(*ptr) != 0)
        {
          continue;
        }
        while (isendline(*ptr) == 0)
        {
/* optional language control character */
          x = whichcharset(*ptr);
          if (x != 0 && charset != x)
          {
            buffer[i++] = charset = x;
          }
          buffer[i++] = convchar(*ptr++);
        }
/* restore the Latin character set before the end of the line */
        if (charset == 0x0E)
        {
          buffer[i++] = charset = 0x0F;
        }
        buffer[i++] = 0x0D;
        buffer[i++] = 0x0A;
      }
      buffer[i++] = 0x00;
      i = (i + SECTORSIZE-1) & (-SECTORSIZE);	/* align the data pointer */

      (void) fclose (fp);

/* update the SMP directory */
      expand_fname (*argv);
      dirptr->name[0] = toradix50 (&input_line[0]);
      dirptr->name[1] = toradix50 (&input_line[3]);
      dirptr->name[2] = toradix50 (&input_line[8]);
      dirptr->attribute = 0x0400;	/* occupied directory entry */
      dirptr->sectors = (i - y) / SECTORSIZE;
      dirptr->unknown[0] = 0x0000;
      dirptr->unknown[1] = 0x8936;

      dirptr++;
    }
  }

  if (i > BUFSIZE)
  {
    printf ("\nOut of SMP data space\n");
    return 1;
  }

/* closing directory entries */
  memcpy (dirptr, &initdata[0x000A], (size_t) (DIR_ENTRY_SIZE+2));
  dirptr->sectors = (BUFSIZE - i) / SECTORSIZE;		/* free sectors */

/* save the SMP buffer to a file */
  if ((fp = fopen("SMP0.BIN", "wb")) == NULL)
  {
    fprintf (stderr, "\nCannot open the output file SMP0.BIN\n");
    return 1;
  }
  if (fwrite (buffer, sizeof (byte), (size_t) BUFSIZE, fp) != (size_t) BUFSIZE)
  {
    fprintf (stderr, "\nFile write error, disk full?\n");
    (void) fclose (fp);
    return 1;
  }
  (void) fclose (fp);

  return 0;
}
