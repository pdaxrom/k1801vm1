object MainForm: TMainForm
  Left = 236
  Top = 154
  HorzScrollBar.Visible = False
  VertScrollBar.Visible = False
  BorderStyle = bsNone
  Caption = 'MK85'
  ClientHeight = 330
  ClientWidth = 760
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  Visible = True
  OnClose = FormClose
  OnCreate = FormCreate
  OnDeactivate = FormDeactivate
  OnKeyDown = FormKeyDown
  OnKeyPress = FormKeyPress
  OnKeyUp = FormKeyUp
  OnMouseDown = FormMouseDown
  OnMouseMove = FormMouseMove
  OnMouseUp = FormMouseUp
  OnPaint = FormPaint
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object RefreshTimer: TTimer
    Enabled = False
    Interval = 32
    OnTimer = OnRefreshTimer
    Left = 32
    Top = 8
  end
  object CursorTimer: TTimer
    Enabled = False
    Interval = 400
    OnTimer = OnCursorTimer
    Left = 32
    Top = 64
  end
  object RunTimer: TThreadedTimer
    Interval = 10
    OnTimer = OnRunTimer
    Left = 32
    Top = 120
  end
end
