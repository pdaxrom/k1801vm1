/* common functions supporting MK-90 card communication */

#include <stdio.h>
#include "typedefs.h"
#include "bool.h"
#include "timers.h"
#include "common.h"

uint dataportmirror;		/* actual status of the printer data port */


void ClrBit (uint bit)
{
  dataportmirror |= (1<<bit);
}


void SetBit (uint bit)
{
  dataportmirror &= ~(1<<bit);
}


/* sends byte "x" through the bus */
void SendByte (uint x)
{
  uint mask;

  for (mask=0x80; mask!=0; mask>>=1)
  {
    if ((x & mask) != 0)
    {
      SetBit (DATA);		/* DATA=1 */
    }
    else
    {
      ClrBit (DATA);		/* DATA=0 */
    }
    SetBit (CLOCK);		/* CLOCK=1 */
    DataOut (dataportmirror);
    ctc_delay (DELAY_VALUE);
    ClrBit (CLOCK);		/* CLOCK=0 */
    DataOut (dataportmirror);
    ctc_delay (DELAY_VALUE);
  }
}


/* reads byte from the bus, expects DATA=input */
uint ReadByte (void)
{
  uint mask, x;

  x = 0;
  for (mask=0x80; mask!=0; mask>>=1)
  {
    ClrBit (CLOCK);		/* CLOCK=0 */
    DataOut (dataportmirror);
    ctc_delay (DELAY_VALUE);
    SetBit (CLOCK);		/* CLOCK=1 */
    DataOut (dataportmirror);
    ctc_delay (DELAY_VALUE);
    if (!BusyIn())
    {
      x |= mask;
    }
  }
  return x;
}


/* sends the "Address" command A0 and 16-bit address */
void SendAddr (uint address)
{
  ClrBit (DATA);		/* DATA=0 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  ClrBit (SELECT);		/* SELECT=0 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  SendByte ((uint) 0xA0);
  SendByte (address/256);
  SendByte (address%256);
  ClrBit (DATA);		/* DATA=0 */
  ClrBit (CLOCK);		/* CLOCK=0 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  SetBit (CLOCK);		/* CLOCK=1 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  SetBit (SELECT);		/* SELECT=1 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  SetBit (DATA);		/* DATA=1 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
}


/* sends the "Read" command D0 and reads "count" bytes to "ptr" */
void ReadBytes (uchar *ptr, uint count)
{
  ClrBit (DATA);		/* DATA=0 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  ClrBit (SELECT);		/* SELECT=0 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  SendByte ((uint) 0xD0);
  SetBit (DATA);		/* DATA=input */
  SetBit (CLOCK);		/* CLOCK=1 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
/* read data */
  while (count-- != 0)
  {
    *ptr++ = (uchar) ReadByte();
  }
  SetBit (SELECT);		/* SELECT=1 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
}


/* sends the "Write" command C0 and "count" bytes from "ptr" */
void WriteBytes (uchar *ptr, uint count)
{
  ClrBit (DATA);		/* DATA=0 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  ClrBit (SELECT);		/* SELECT=0 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  SendByte ((uint) 0xC0);
/* write data */
  while (count-- != 0)
  {
    SendByte((uint) *ptr++);
  }
  ClrBit (DATA);		/* DATA=0 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  SetBit (CLOCK);		/* CLOCK=1 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  SetBit (DATA);		/* DATA=1 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
  SetBit (SELECT);		/* SELECT=1 */
  DataOut (dataportmirror);
  ctc_delay (DELAY_VALUE);
}


void Init (void)
{
  get_ctc_ch0_mode();
  dataportmirror = (uint) 0xFF;
  SetBit (SELECT);		/* SELECT=1 */
  SetBit (DATA);		/* DATA=1 */
  SetBit (CLOCK);		/* CLOCK=1 */
  DataOut (dataportmirror);
  timer_delay (10);
}
