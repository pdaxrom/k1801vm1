/* reads the MK-90 RAM card to the "MK90.BIN" file */

#include <stdio.h>
#include "typedefs.h"
#include "bool.h"
#include "timers.h"
#include "common.h"

#define CARDSTART 0x0000
#define CARDSIZE 0x2800

uchar buf[CARDSIZE];


int main (void)
{
  FILE *fp;

  Init ();
  SendAddr ((uint) CARDSTART);
  ReadBytes (buf, (uint) CARDSIZE);

  if ((fp = fopen("MK90.BIN", "wb")) == NULL)
  {
    printf ("\nCannot open output file MK90.BIN\n");
    return 1;
  }
  if (fwrite (buf, sizeof(uchar), (size_t) CARDSIZE, fp) != (size_t) CARDSIZE)
  {
    printf ("\nFile write error, disk full?\n");
    (void) fclose (fp);
    return 1;
  }
  (void) fclose (fp);
  return 0;
}
