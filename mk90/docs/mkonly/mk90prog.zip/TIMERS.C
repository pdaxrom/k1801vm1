/* The timer routines have been put into separate file because they
   aren't portable, and cannot be checked by the Splint. */

#include <stdio.h>
#include <dos.h>	/* inportb, outportb */
#include "typedefs.h"
#include "bool.h"
#include "timers.h"

volatile uint far *timer_low = (uint far *) 0x0040006CL; /* BIOS variable */

uint channel0_mode = 2;			/* = 1 if mode 2, = 2 if mode 3 */


/* This function reads the 16-bit counter of the CTC 8254, channel 0. It is
   important that the returned value is defined as unsigned, because integer
   operations using this value must give correct results if an overflow or
   underflow occurs. */
uint counter0 (void)
{
  asm pushf;
  asm cli;
  asm mov al,0;
  asm out 43h,al;		/* latch count */
  asm in al,40h;
  asm xchg al,ah;		/* lo-byte of count */
  asm in al,61h;		/* waste some time */
  asm in al,40h;		/* hi-byte of count */
  asm xchg al,ah;
  asm popf;
  return _AX;
}


/* This function determines the operating mode of the CTC channel 0. It is
   assummed that the channel 0 is operating either in mode 3 or in mode 2,
   with a divisor of 65536. Thus the counter is decremented (in steps of two
   in mode 3) on every 0.838 us. */
void get_ctc_ch0_mode (void)
{
  uint x, i;

/* wait until timer_low changes */
  x = *timer_low;
  while (*timer_low == x)
    ;

/* count CTC counter 0 rollovers needed to increment timer_low */
  i = 0;
  x = *timer_low;
  while (*timer_low == x)
  {
    while (counter0() > 32767)
      ;
    while (counter0() <= 32767)
      ;
    i++;
  }

  channel0_mode = i;
}


/* This function waits x * 0.838 us, x must be in range (0,32767). */
void ctc_delay (uint x)
{
  x = counter0() - x * channel0_mode;
  while ((int)(counter0() - x) > 0)
    ;
}


/* This function waits x * 55 ms. */
void timer_delay (uint x)
{
  x += *timer_low;
  while ((int)(x - *timer_low) > 0)
    ;
}


/* send a byte to the printer data port */
void DataOut (uint x)
{
  outportb (PORT_BASE, (uchar) x);
}


/* read the Busy signal from the printer status port */
bool BusyIn (void)
{
  return (((uint) inportb (PORT_BASE+1) & 0x80) == 0);
}
