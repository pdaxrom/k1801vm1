/* writes the the "MK90.BIN" file to the MK-90 RAM card */

#include <stdio.h>
#include "typedefs.h"
#include "bool.h"
#include "timers.h"
#include "common.h"

#define CARDSTART 0x0000
#define CARDSIZE 0x2800

uchar buf[CARDSIZE];


int main (void)
{
  FILE *fp;

  if ((fp = fopen("MK90.BIN", "rb")) == NULL)
  {
    printf ("\nCannot open input file MK90.BIN\n");
    return 1;
  }
  if (fread (buf, sizeof(uchar), (size_t) CARDSIZE, fp) != (size_t) CARDSIZE)
  {
    printf ("\nPremature end of input file MK90.BIN\n");
    (void) fclose (fp);
    return 1;
  }
  (void) fclose (fp);

  Init ();
  SendAddr ((uint) CARDSTART);
  WriteBytes (buf, (uint) CARDSIZE);

  return 0;
}
