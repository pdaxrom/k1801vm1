EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L MCU_ST_STM32F1:STM32F103C8Tx U1
U 1 1 5EDCA288
P 4850 3700
F 0 "U1" H 5350 5400 50  0000 C CNN
F 1 "STM32F103C8Tx" H 5400 5300 50  0000 C CNN
F 2 "Package_QFP:LQFP-48_7x7mm_P0.5mm" H 4250 2300 50  0001 R CNN
F 3 "http://www.st.com/st-web-ui/static/active/en/resource/technical/document/datasheet/CD00161566.pdf" H 4850 3700 50  0001 C CNN
	1    4850 3700
	1    0    0    -1  
$EndComp
$Comp
L 4xxx:4053 U2
U 1 1 5EDCBB3F
P 7800 4400
F 0 "U2" H 8150 5300 50  0000 C CNN
F 1 "74HCT4053" H 8150 5200 50  0000 C CNN
F 2 "Package_SO:TSSOP-16_4.4x5mm_P0.65mm" H 7800 4400 50  0001 C CNN
F 3 "http://www.intersil.com/content/dam/Intersil/documents/cd40/cd4051bms-52bms-53bms.pdf" H 7800 4400 50  0001 C CNN
	1    7800 4400
	1    0    0    -1  
$EndComp
$Comp
L Transistor_FET:2N7002 Q2
U 1 1 5EDCCAFE
P 6950 5550
F 0 "Q2" H 6800 5850 50  0000 L CNN
F 1 "2N7002" H 6700 5750 50  0000 L CNN
F 2 "Package_TO_SOT_SMD:SOT-23" H 7150 5475 50  0001 L CIN
F 3 "https://www.fairchildsemi.com/datasheets/2N/2N7002.pdf" H 6950 5550 50  0001 L CNN
	1    6950 5550
	1    0    0    -1  
$EndComp
$Comp
L Connector_Generic:Conn_01x16 J2
U 1 1 5EDF36E2
P 3800 6900
F 0 "J2" V 3925 6846 50  0000 C CNN
F 1 "Conn_01x16" V 4016 6846 50  0000 C CNN
F 2 "Connector_PinHeader_1.00mm:PinHeader_1x16_P1.00mm_Vertical" H 3800 6900 50  0001 C CNN
F 3 "~" H 3800 6900 50  0001 C CNN
	1    3800 6900
	0    -1   1    0   
$EndComp
NoConn ~ 5050 1050
NoConn ~ 4950 1050
NoConn ~ 4850 1050
NoConn ~ 4750 1050
NoConn ~ 4650 1050
NoConn ~ 4550 1050
NoConn ~ 4450 1050
NoConn ~ 4350 1050
NoConn ~ 4250 1050
NoConn ~ 4150 1050
NoConn ~ 4050 1050
NoConn ~ 3950 1050
NoConn ~ 3850 1050
NoConn ~ 3750 1050
NoConn ~ 3650 1050
$Comp
L Connector_Generic:Conn_01x16 J1
U 1 1 5EDEB5E0
P 1400 4100
F 0 "J1" H 1318 5017 50  0000 C CNN
F 1 "Conn_01x16" H 1318 4926 50  0000 C CNN
F 2 "Connector_PinHeader_1.00mm:PinHeader_1x16_P1.00mm_Vertical" H 1400 4100 50  0001 C CNN
F 3 "~" H 1400 4100 50  0001 C CNN
	1    1400 4100
	-1   0    0    -1  
$EndComp
NoConn ~ 3550 1050
$Comp
L Connector_Generic:Conn_01x16 J4
U 1 1 5EDE79CD
P 4350 850
F 0 "J4" V 4600 850 50  0000 C CNN
F 1 "Conn_01x16" V 4500 850 50  0000 C CNN
F 2 "Connector_PinHeader_1.00mm:PinHeader_1x16_P1.00mm_Vertical" H 4350 850 50  0001 C CNN
F 3 "~" H 4350 850 50  0001 C CNN
	1    4350 850 
	0    1    -1   0   
$EndComp
$Comp
L Connector_Generic:Conn_01x16 J3
U 1 1 5EE97480
P 9900 3400
F 0 "J3" H 9818 2375 50  0000 C CNN
F 1 "Conn_01x16" H 9818 2466 50  0000 C CNN
F 2 "Connector_PinHeader_1.00mm:PinHeader_1x16_P1.00mm_Vertical" H 9900 3400 50  0001 C CNN
F 3 "~" H 9900 3400 50  0001 C CNN
	1    9900 3400
	1    0    0    1   
$EndComp
Text Label 3900 6600 1    50   ~ 0
ADO1
Wire Wire Line
	8300 4400 8650 4400
Wire Wire Line
	8650 4400 8650 6150
Wire Wire Line
	8650 6150 3900 6150
NoConn ~ 4000 6700
NoConn ~ 4600 6700
NoConn ~ 9700 4100
NoConn ~ 9700 3500
NoConn ~ 9700 2800
NoConn ~ 9700 2900
NoConn ~ 9700 3200
Text Label 9600 3400 2    50   ~ 0
OV1
Text Label 9600 3300 2    50   ~ 0
OV2
Wire Wire Line
	7050 5350 7050 4400
Wire Wire Line
	7300 4100 7050 4100
Connection ~ 7050 4100
Wire Wire Line
	7050 4100 7050 3800
Wire Wire Line
	7300 4400 7050 4400
Connection ~ 7050 4400
Wire Wire Line
	7050 4400 7050 4100
$Comp
L stmk85_pcb-rescue:TPS62745DSSR-SamacSys_Parts IC3
U 1 1 5EDD07B2
P 7400 1500
F 0 "IC3" H 8500 600 50  0000 C CNN
F 1 "TPS62745DSSR" H 8550 500 50  0000 C CNN
F 2 "SON50P200X300X80-13N" H 8650 1600 50  0001 L CNN
F 3 "http://www.ti.com/lit/gpn/tps62745" H 8650 1500 50  0001 L CNN
F 4 "3.3V-10V input, 300mA Ultra Low Iq step-down converter with VSEL and input voltage switch" H 8650 1400 50  0001 L CNN "Description"
F 5 "0.8" H 8650 1300 50  0001 L CNN "Height"
F 6 "Texas Instruments" H 8650 1200 50  0001 L CNN "Manufacturer_Name"
F 7 "TPS62745DSSR" H 8650 1100 50  0001 L CNN "Manufacturer_Part_Number"
F 8 "TPS62745DSSR" H 8650 1000 50  0001 L CNN "Arrow Part Number"
F 9 "https://www.arrow.com/en/products/tps62745dssr/texas-instruments" H 8650 900 50  0001 L CNN "Arrow Price/Stock"
F 10 "595-TPS62745DSSR" H 8650 800 50  0001 L CNN "Mouser Part Number"
F 11 "https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS62745DSSR?qs=cGEy3R83DS9Bx52nwzd43Q%3D%3D" H 8650 700 50  0001 L CNN "Mouser Price/Stock"
	1    7400 1500
	1    0    0    -1  
$EndComp
Text Label 9600 3900 2    50   ~ 0
SHIFT1
Text Label 9600 3800 2    50   ~ 0
WR
Wire Wire Line
	8300 3800 9700 3800
Wire Wire Line
	9700 3900 8650 3900
Wire Wire Line
	8650 3900 8650 4100
Wire Wire Line
	8650 4100 8300 4100
Wire Wire Line
	7300 3800 7050 3800
Connection ~ 7050 3800
Wire Wire Line
	7050 3800 7050 3300
Wire Wire Line
	7300 3900 7200 3900
Wire Wire Line
	7200 3900 7200 3500
Wire Wire Line
	7200 3900 7200 4200
Wire Wire Line
	7200 4500 7300 4500
Connection ~ 7200 3900
Wire Wire Line
	7300 4200 7200 4200
Connection ~ 7200 4200
Wire Wire Line
	7200 4200 7200 4500
Wire Wire Line
	4650 5200 4650 5750
Wire Wire Line
	4650 5750 4750 5750
Wire Wire Line
	9700 3400 8750 3400
Wire Wire Line
	8750 3400 8750 5750
Wire Wire Line
	8750 5750 7900 5750
Connection ~ 7050 5750
Wire Wire Line
	7800 5300 7800 5750
Connection ~ 7800 5750
Wire Wire Line
	7800 5750 7200 5750
Wire Wire Line
	7900 5300 7900 5750
Connection ~ 7900 5750
Wire Wire Line
	7900 5750 7800 5750
Wire Wire Line
	4750 5200 4750 5750
Connection ~ 4750 5750
Wire Wire Line
	4750 5750 4850 5750
Wire Wire Line
	4850 5200 4850 5750
Connection ~ 4850 5750
Wire Wire Line
	4850 5750 4950 5750
Wire Wire Line
	4950 5200 4950 5750
Text Label 3800 6600 1    50   ~ 0
PP2
Text Label 3700 6600 1    50   ~ 0
PP1
Text Label 3600 6600 1    50   ~ 0
PP3
Text Label 3300 6600 1    50   ~ 0
KB10
Text Label 3200 6600 1    50   ~ 0
KB9
Text Label 3100 6600 1    50   ~ 0
KB8
Text Label 1700 4900 0    50   ~ 0
KB7
Text Label 1700 4800 0    50   ~ 0
KB6
Text Label 1700 4600 0    50   ~ 0
KB4
Text Label 1700 4500 0    50   ~ 0
KB3
Text Label 1700 4400 0    50   ~ 0
KB2
Text Label 1700 4300 0    50   ~ 0
KB1
Text Label 1700 4200 0    50   ~ 0
KB0
Text Label 1700 4100 0    50   ~ 0
U
Wire Wire Line
	1600 4800 4150 4800
Wire Wire Line
	1600 4600 4150 4600
Wire Wire Line
	1600 4500 4150 4500
Wire Wire Line
	1600 4400 4150 4400
Wire Wire Line
	3100 6700 3100 5000
Wire Wire Line
	3100 5000 4150 5000
Wire Wire Line
	3300 6700 3300 6150
Wire Wire Line
	3300 3500 4150 3500
Wire Wire Line
	3200 6700 3200 6150
Wire Wire Line
	3200 6150 3300 6150
Connection ~ 3300 6150
Wire Wire Line
	3300 6150 3300 3500
NoConn ~ 3400 6700
NoConn ~ 3500 6700
Wire Wire Line
	3600 6700 3600 4300
Wire Wire Line
	3600 4300 4150 4300
Wire Wire Line
	3800 6700 3800 4200
Wire Wire Line
	3800 4200 4150 4200
Wire Wire Line
	3700 6700 3700 4100
Wire Wire Line
	3700 4100 4150 4100
Wire Wire Line
	5450 4000 6800 4000
Wire Wire Line
	6800 4000 6800 4900
Wire Wire Line
	6800 4900 7300 4900
Wire Wire Line
	5450 3900 6900 3900
Wire Wire Line
	6900 3900 6900 4800
Wire Wire Line
	6900 4800 7300 4800
Wire Wire Line
	5450 4200 6700 4200
Wire Wire Line
	6700 4200 6700 5000
Wire Wire Line
	6700 5000 7300 5000
Wire Wire Line
	7300 4700 7200 4700
Wire Wire Line
	7200 4700 7200 5750
Connection ~ 7200 5750
Wire Wire Line
	7200 5750 7050 5750
$Comp
L Device:L L1
U 1 1 5EF2A6EC
P 6800 1600
F 0 "L1" V 6990 1600 50  0000 C CNN
F 1 "4.7uH" V 6899 1600 50  0000 C CNN
F 2 "Inductor_SMD:L_Taiyo-Yuden_MD-3030" H 6800 1600 50  0001 C CNN
F 3 "~" H 6800 1600 50  0001 C CNN
	1    6800 1600
	0    -1   -1   0   
$EndComp
Wire Wire Line
	6950 1600 7400 1600
Wire Wire Line
	6650 1600 6550 1600
Wire Wire Line
	6550 1600 6550 1900
Wire Wire Line
	6550 1900 7400 1900
Wire Wire Line
	4650 2200 4650 1900
Wire Wire Line
	4650 1900 4750 1900
Connection ~ 6550 1900
Wire Wire Line
	4750 2200 4750 1900
Connection ~ 4750 1900
Wire Wire Line
	4750 1900 4850 1900
Wire Wire Line
	4850 2200 4850 1900
Connection ~ 4850 1900
Wire Wire Line
	4850 1900 4950 1900
Wire Wire Line
	4950 2200 4950 1900
Connection ~ 4950 1900
Wire Wire Line
	4950 1900 5050 1900
Wire Wire Line
	5050 2200 5050 1900
Wire Wire Line
	7400 1500 7200 1500
Wire Wire Line
	7200 1500 7200 1200
Wire Wire Line
	7200 1200 1900 1200
Wire Wire Line
	1900 1200 1900 4100
Wire Wire Line
	1900 4100 1600 4100
Wire Wire Line
	7200 1500 7200 2100
Connection ~ 7200 1500
Wire Wire Line
	8800 1500 9000 1500
Wire Wire Line
	9000 1500 9000 1200
Wire Wire Line
	9000 1200 7200 1200
Connection ~ 7200 1200
Wire Wire Line
	8800 1800 9000 1800
Wire Wire Line
	9000 1800 9000 1700
Connection ~ 9000 1500
Wire Wire Line
	8800 1700 9000 1700
Connection ~ 9000 1700
Wire Wire Line
	9000 1700 9000 1600
Wire Wire Line
	8800 1600 9000 1600
Connection ~ 9000 1600
Wire Wire Line
	9000 1600 9000 1500
Wire Wire Line
	8800 1900 9000 1900
Wire Wire Line
	9000 1900 9000 2750
Wire Wire Line
	7300 2750 7300 1800
Wire Wire Line
	7300 1700 7400 1700
NoConn ~ 7400 2000
NoConn ~ 8800 2000
Wire Wire Line
	7400 1800 7300 1800
Connection ~ 7300 1800
Wire Wire Line
	7300 1800 7300 1700
Wire Wire Line
	8100 2500 8100 2750
Connection ~ 8100 2750
Wire Wire Line
	8100 2750 7300 2750
$Comp
L Device:C C1
U 1 1 5EF86D00
P 6250 2400
F 0 "C1" H 6365 2446 50  0000 L CNN
F 1 "10uF" H 6365 2355 50  0000 L CNN
F 2 "Capacitor_SMD:C_1206_3216Metric" H 6288 2250 50  0001 C CNN
F 3 "~" H 6250 2400 50  0001 C CNN
	1    6250 2400
	1    0    0    -1  
$EndComp
$Comp
L Device:C C2
U 1 1 5EF87BB5
P 6750 2400
F 0 "C2" H 6865 2446 50  0000 L CNN
F 1 "10uF" H 6865 2355 50  0000 L CNN
F 2 "Capacitor_SMD:C_1206_3216Metric" H 6788 2250 50  0001 C CNN
F 3 "~" H 6750 2400 50  0001 C CNN
	1    6750 2400
	1    0    0    -1  
$EndComp
Wire Wire Line
	6750 2250 6750 2100
Wire Wire Line
	6750 2100 7200 2100
Wire Wire Line
	6250 2250 6250 1900
Wire Wire Line
	6250 1900 6550 1900
Wire Wire Line
	7300 2750 6750 2750
Wire Wire Line
	6250 2750 6250 2550
Connection ~ 7300 2750
Wire Wire Line
	6750 2550 6750 2750
Connection ~ 6750 2750
Wire Wire Line
	6750 2750 6250 2750
Wire Wire Line
	5700 4900 5450 4900
Wire Wire Line
	5800 4800 5450 4800
Text Label 5700 5450 1    50   ~ 0
SWCLK
Text Label 5800 5450 1    50   ~ 0
SWDIO
Wire Wire Line
	7200 3500 7800 3500
Wire Wire Line
	7050 3300 9700 3300
Wire Wire Line
	8100 2750 8750 2750
Wire Wire Line
	7200 2100 7200 3500
Connection ~ 7200 2100
Connection ~ 7200 3500
Wire Wire Line
	8750 3400 8750 2750
Connection ~ 8750 3400
Connection ~ 8750 2750
Wire Wire Line
	8750 2750 9000 2750
Text Label 3700 3500 0    50   ~ 0
STOP_KEY
Text Label 3700 3600 0    50   ~ 0
OFF_SW
Wire Wire Line
	1600 4200 1950 4200
Wire Wire Line
	3400 4200 3400 3600
Wire Wire Line
	3400 3600 4150 3600
Wire Wire Line
	1600 4300 1950 4300
Wire Wire Line
	1950 4300 1950 4200
NoConn ~ 1600 3400
NoConn ~ 1600 3500
NoConn ~ 1600 3600
NoConn ~ 1600 3700
NoConn ~ 1600 3800
NoConn ~ 1600 3900
NoConn ~ 1600 4000
Text Label 5200 1900 0    50   ~ 0
VDD_2.5V
Text Label 3700 3700 0    50   ~ 0
BOOT1
$Comp
L Device:R R1
U 1 1 5EE3BC31
P 3050 3700
F 0 "R1" V 3257 3700 50  0000 C CNN
F 1 "10k" V 3166 3700 50  0000 C CNN
F 2 "Resistor_SMD:R_0805_2012Metric" V 2980 3700 50  0001 C CNN
F 3 "~" H 3050 3700 50  0001 C CNN
	1    3050 3700
	0    -1   -1   0   
$EndComp
Wire Wire Line
	3200 3700 4150 3700
Wire Wire Line
	4150 2600 2300 2600
$Comp
L Device:R R4
U 1 1 5EE5B2F3
P 3700 2150
F 0 "R4" H 3770 2196 50  0000 L CNN
F 1 "47k" H 3770 2105 50  0000 L CNN
F 2 "Resistor_SMD:R_0805_2012Metric" V 3630 2150 50  0001 C CNN
F 3 "~" H 3700 2150 50  0001 C CNN
	1    3700 2150
	1    0    0    -1  
$EndComp
$Comp
L Device:R R2
U 1 1 5EE5D651
P 2950 2150
F 0 "R2" H 3020 2196 50  0000 L CNN
F 1 "1M" H 3020 2105 50  0000 L CNN
F 2 "Resistor_SMD:R_0805_2012Metric" V 2880 2150 50  0001 C CNN
F 3 "~" H 2950 2150 50  0001 C CNN
	1    2950 2150
	1    0    0    -1  
$EndComp
Wire Wire Line
	3700 2400 3700 2300
$Comp
L Device:C C3
U 1 1 5EE8241B
P 3350 2400
F 0 "C3" V 3650 2350 50  0000 L CNN
F 1 "0.1uF" V 3550 2300 50  0000 L CNN
F 2 "Capacitor_SMD:C_1206_3216Metric" H 3388 2250 50  0001 C CNN
F 3 "~" H 3350 2400 50  0001 C CNN
	1    3350 2400
	0    -1   -1   0   
$EndComp
Wire Wire Line
	2950 2000 2950 1900
Wire Wire Line
	2950 1900 3700 1900
Wire Wire Line
	3700 2000 3700 1900
Connection ~ 3700 1900
Wire Wire Line
	3700 1900 4650 1900
NoConn ~ 4150 2800
NoConn ~ 4150 2900
NoConn ~ 4150 3200
NoConn ~ 4150 3300
NoConn ~ 4150 3800
NoConn ~ 4150 3900
Wire Wire Line
	5450 4100 6600 4100
Wire Wire Line
	6600 4100 6600 5550
Wire Wire Line
	6600 5550 6750 5550
NoConn ~ 5450 3500
NoConn ~ 5450 3600
NoConn ~ 5450 3700
NoConn ~ 5450 3800
NoConn ~ 5450 4300
NoConn ~ 5450 4400
NoConn ~ 5450 4500
NoConn ~ 5450 5000
Wire Wire Line
	2400 2400 2950 2400
Text Label 2550 2400 0    50   ~ 0
ON_SW
Text Label 5450 3900 0    50   ~ 0
SYNC
Text Label 5450 4000 0    50   ~ 0
SHIFT
Text Label 5450 4200 0    50   ~ 0
ADO
Text Label 5450 4100 0    50   ~ 0
PWR
Wire Wire Line
	4950 5750 7050 5750
Wire Wire Line
	5050 1900 6250 1900
Connection ~ 4650 1900
Wire Wire Line
	2950 2300 2950 2400
Connection ~ 2950 2400
Wire Wire Line
	2950 2400 3200 2400
Wire Wire Line
	3500 2400 3700 2400
Wire Wire Line
	3700 2400 4150 2400
Connection ~ 3700 2400
Text Label 1700 4700 0    50   ~ 0
KB5
Wire Wire Line
	1600 4700 4150 4700
Wire Wire Line
	1600 4900 4150 4900
Wire Wire Line
	5800 4800 5800 5850
Wire Wire Line
	4500 5850 5700 5850
Wire Wire Line
	9700 3600 8650 3600
Wire Wire Line
	8650 3600 8650 3200
Wire Wire Line
	8650 3200 5850 3200
Wire Wire Line
	5850 3200 5850 1600
Wire Wire Line
	5850 1600 2300 1600
Wire Wire Line
	2300 1600 2300 2600
Wire Wire Line
	9700 2700 9200 2700
Wire Wire Line
	9200 2700 9200 3000
Wire Wire Line
	9200 3000 6050 3000
Wire Wire Line
	6050 3000 6050 1400
Wire Wire Line
	6050 1400 2100 1400
Wire Wire Line
	2100 1400 2100 3700
Wire Wire Line
	2100 3700 2900 3700
Wire Wire Line
	6550 1900 6550 2900
Wire Wire Line
	6550 2900 9100 2900
Wire Wire Line
	9100 2900 9100 2600
Wire Wire Line
	9100 2600 9700 2600
$Comp
L Diode:BAS316 D1
U 1 1 5EF3F710
P 3050 4200
F 0 "D1" H 3050 4417 50  0000 C CNN
F 1 "BAS316" H 3050 4326 50  0000 C CNN
F 2 "Diode_SMD:D_SOD-323" H 3050 4025 50  0001 C CNN
F 3 "https://assets.nexperia.com/documents/data-sheet/BAS16_SER.pdf" H 3050 4200 50  0001 C CNN
	1    3050 4200
	1    0    0    -1  
$EndComp
Wire Wire Line
	3200 4200 3400 4200
Wire Wire Line
	2900 4200 1950 4200
Connection ~ 1950 4200
Wire Wire Line
	5700 5850 5700 4900
Wire Wire Line
	5450 4700 5900 4700
Wire Wire Line
	5900 4700 5900 5950
Wire Wire Line
	5900 5950 4200 5950
Wire Wire Line
	4200 5950 4200 6700
Wire Wire Line
	5450 4600 6000 4600
Wire Wire Line
	6000 4600 6000 6050
Wire Wire Line
	6000 6050 4100 6050
Wire Wire Line
	4100 6050 4100 6700
Wire Wire Line
	3900 6150 3900 6700
Wire Wire Line
	5800 5850 8850 5850
Wire Wire Line
	8850 5850 8850 4000
Wire Wire Line
	8850 4000 9700 4000
Wire Wire Line
	4500 5850 4500 6700
NoConn ~ 4400 6700
NoConn ~ 4300 6700
Connection ~ 4950 5750
Connection ~ 6250 1900
Connection ~ 5050 1900
Wire Wire Line
	4150 3100 2200 3100
Wire Wire Line
	2200 3100 2200 1500
Wire Wire Line
	2200 1500 5950 1500
Wire Wire Line
	5950 1500 5950 3100
NoConn ~ 9700 3100
Wire Wire Line
	5950 3100 9300 3100
Wire Wire Line
	9300 3100 9300 3000
Wire Wire Line
	9300 3000 9700 3000
Text Label 3700 3100 0    50   ~ 0
LED
Text Label 5900 5450 1    50   ~ 0
SPARE1
Text Label 6000 5450 1    50   ~ 0
SPARE2
Wire Wire Line
	9700 3700 8550 3700
Wire Wire Line
	8550 3700 8550 3400
Wire Wire Line
	8550 3400 5750 3400
Wire Wire Line
	5750 3400 5750 1300
Wire Wire Line
	5750 1300 2000 1300
Wire Wire Line
	2000 1300 2000 4000
Wire Wire Line
	4150 4000 2000 4000
Text Label 3700 4000 0    50   ~ 0
SPARE3
Text Label 9600 2600 2    50   ~ 0
VDD_2.5V
Text Label 9600 3000 2    50   ~ 0
LED
Text Label 9600 3700 2    50   ~ 0
SPARE3
Text Label 4200 6600 1    50   ~ 0
SPARE1
Text Label 4100 6600 1    50   ~ 0
SPARE2
Text Label 4500 6600 1    50   ~ 0
SWCLK
Text Label 9600 4000 2    50   ~ 0
SWDIO
$EndSCHEMATC
