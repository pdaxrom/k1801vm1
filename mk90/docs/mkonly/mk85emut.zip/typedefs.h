#ifndef _TYPEDEFS_H
#define _TYPEDEFS_H

typedef unsigned int uint;
typedef unsigned short ushort;
typedef unsigned long ulong;
typedef unsigned char uchar;

#endif
