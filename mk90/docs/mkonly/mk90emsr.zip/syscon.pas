{ System controller KA1835VG5 }

unit SysCon;

interface

  procedure SysConInit;
  procedure SysConClose;
  function SysWrPtr (index: word) : pointer;
  function WrRam (address: word) : boolean;
  function RdRam (address: word) : boolean;
  function RdRom (address: word) : boolean;

implementation

uses Def;

var
  sysdata: array [0..3] of word;	{ sysdata[1] = RG1, sysdata[2] = RG2 }


procedure SysConInit;
begin
  sysdata[1] := 0;
  sysdata[2] := 0;
end {SysConInit};


procedure SysConClose;
begin
end {SysConClose};


function SysWrPtr (index: word) : pointer;
begin
  SysWrPtr := @sysdata[(index shr 1) and $03];
end {SysWrPtr};


function WrRam (address: word) : boolean;
const
  endaddr: array [0..3] of word = ( $DFFF, $7FFF, $3FFF, $1FFF );
begin
  WrRam :=
	(address <= endaddr[(sysdata[1] shr 9) and 3])
	or
	( (address >= $E800) and (address <= $EBFF) );
end {WrRam};


{ When a real microprocessor performs a byte read operation, it reads a word
 from an even address, then picks the upper or lower 8 bits. The emulated one
 actually reads a byte, even from an odd address. Therefore, the emulated
 system controller (unlike the real one) cannot prevent read accesses to odd
 memory locations. }

function RdRam (address: word) : boolean;
const
  endaddr: array [0..3] of word =
	( $DFFF, $7FFF, $3FFF, $1FFF {instead of $DFFE, $7FFE, $3FFE, $1FFE} );
var
  i: word;
begin
  i := (sysdata[1] shr 11) and 7;
  RdRam :=
	( (i < 4 {bit 13 cleared}) and (address <= endaddr[i and 3]) )
	or
	( (address >= $E800) and (address <= $EBFF {instead of $EBFE}) );
end {RdRam};


function RdRom (address: word) : boolean;
const
  startaddr: array [0..7] of word =
	( $FFFF, $8000, $4000, $2000, 0, 0, 0, 0 );
begin
  RdRom := ((sysdata[2] and $2000) = 0) and
  (
	( ((address >= startaddr[(sysdata[1] shr 11) and 7])) and
		(address <= $DFFF {instead of $DFFE}) )
	or
	( ((sysdata[2] and $0200) <> 0) and
		(address >= $E000) and (address <= $E7FF) )
	or
	( (address >= $EC00) and (address <= $FDFF {instead of $FDFE}) )
  );
end {RdRom};


end.
